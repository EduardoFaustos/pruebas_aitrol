<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

//consulta máster

Route::get('contable/empresas', 'contable\FacturaController@empresas')->name('empresa.index');
Route::get('contable/empresas/editar/{id}', 'contable\FacturaController@empresa_editar')->name('empresa.editar');
Route::get('contable/empresas/facturacion/{id}', 'contable\FacturaController@facturas')->name('factura.index');
Route::get('contable/empresas/facturacion/crear/{id}/{id_cliente}/{id_empresa}/{id_suc}/{id_caj}/{id_factura}', 'contable\FacturaController@factura_crear')->name('factura.crear');
Route::post('contable/empresas/facturacion/crear/store', 'contable\FacturaController@factura_store')->name('factura.store_contable');

//Route::get('contable/paciente/crear/{id}', 'contable\FacturaController@crear');
//Route::get('contable/paciente/crear/', 'contable\FacturaController@crear')->name('paciente.crear');
Route::get('contable/paciente/crear/{id}/{id_cliente}/{id_empresa}/{id_suc}/{id_caj}/{id_factura}', 'contable\FacturaController@crear')->name('paciente.crear');

Route::get('contable/paciente_cliente/crear/{id}/{id_cliente}/{id_empresa}/{id_suc}/{id_caj}/', 'contable\FacturaController@crear')->name('paciente.crear');

//Buscador Factura
Route::post('contable/empresas/facturacion/busqueda', 'contable\FacturaController@factura_buscar')->name('factura.busqueda');

Route::get('contable/facturacion/agenda/{id}', 'contable\Factura_AgendaController@facturar')->name('factura.agenda');

Route::get('contable/facturacion/verificar/seguro/{id}', 'contable\Factura_AgendaController@verificar_seguro');
Route::get('contable/facturacion/verificar/pago/{id_seguro}/{id_doctor}', 'contable\Factura_AgendaController@verificar_pago');

//obtener el valor del facturero, con el seguro
Route::post('contable/facturacion/valores', 'contable\Factura_AgendaController@valores_seguro')->name('facturacion.valores_seguro');
//Nueva Fucionalidad
//Obtener sucursales de la Empresa Seleccionada
Route::post('contable/facturacion/sucursal', 'contable\Factura_AgendaController@obtener_sucursal_empresa')->name('sucursal.empresa');

//Obtener caja de la sucursal Seleccionada
Route::post('contable/facturacion/caja', 'contable\Factura_AgendaController@obtener_caja_sucursal')->name('caja.sucursal');

//Obtener Secuencia Numero de Factura
Route::get('contable/facturacion/consulta/num_factura', 'contable\Factura_AgendaController@obtener_numero_factura')->name('num_fact.consulta');

//Guardado de Factura
Route::post('contable/facturacion/guardado/consulta/', 'contable\Factura_AgendaController@guardar_factura')->name('facturacion.consulta_guardar');

Route::post('contable/orden/venta/guardado/consulta/', 'contable\Factura_AgendaController@guardar_orden')->name('facturacion.guardar_orden');
Route::post('contable/orden/venta/buscar/cliente/', 'contable\Factura_AgendaController@buscar_cliente')->name('facturacion.buscar_cliente');
Route::post('contable/orden/venta/cliente/', 'contable\Factura_AgendaController@cliente')->name('facturacion.cliente');

Route::get('comprobante/orden/venta/{id_orden}', 'contable\Factura_AgendaController@imprimir_ride')->name('facturacion.imprimir_ride');

//Nueva ruta
Route::get('contable/modal/recibo/cobro/{id_orden}', 'contable\Factura_AgendaController@obtener_modal')->name('facturacion.modal_recibo');

Route::post('contable/recibo/cobro/anular', 'contable\Factura_AgendaController@anular_recibo_cobro')->name('recibo_cobro.anular');


//Reporte Cierre Caja
Route::match(['get', 'post'], 'reporte/cierre_caja', 'contable\CierreCajaController@index_cierre')->name('reporte.index_cierre');

Route::post('reporte/exportar/cierre', 'contable\CierreCajaController@reporte')->name('cierrecaja.reporte');

Route::post('reporte/imprimir_excel', 'contable\CierreCajaController@imprimir_excel')->name('cierrecaja.imprimir_excel');

//editar comprobante pago
Route::get('contable/facturacion/agenda/editar/{id}', 'contable\Factura_AgendaController@facturar_editar')->name('factura.editar_cp');
Route::get('contable/facturacion/agenda/editar/listado/{id}', 'contable\Factura_AgendaController@facturar_listado')->name('factura.listado');
Route::post('contable/facturacion/agenda/actualizar/', 'contable\Factura_AgendaController@facturar_actualizar')->name('factura.actualizar');
