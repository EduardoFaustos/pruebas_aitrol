<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */
Route::match(['get', 'post'], 'contable/contabilidad/libro/diario', 'contable\LibroDiarioController@index')->name('librodiario.index');

Route::get('contable/contabilidad/libro/revision/{id}', 'contable\LibroDiarioController@revisar')->name('librodiario.revisar');
Route::get('contable/contabilidad/libro/diario/buscador', 'contable\LibroDiarioController@buscador_secuencia')->name('librodiario.buscador');
Route::get('contable/contabilidad/libro/crear/asiento', 'contable\LibroDiarioController@crear')->name('librodiario.crear');
Route::post('contable/contabilidad/libro/guardar/asiento', 'contable\LibroDiarioController@store')->name('librodiario.store');
Route::post('contable/contabilidad/libro/buscar/asiento', 'contable\LibroDiarioController@buscar')->name('librodiario.buscar_asiento');
Route::get('contable/contabilidad/libro/buscar/proveedor', 'contable\LibroDiarioController@buscar_proveedor')->name('librodiario.buscar_proveedor');
Route::get('contable/contabilidad/libro/buscar/buscar', 'contable\LibroDiarioController@search')->name('libro_contable_search');
Route::get('contable/contabilidad/libro/buscar/fecha', 'contable\LibroDiarioController@buscador_fecha')->name('librodiario.buscador_fecha');
Route::get('contable/contabilidad/libro/diario/buscar_empresa', 'contable\LibroDiarioController@buscar_empresa')->name('librodiario.buscar_empresa');
Route::get('contable/contabilidad/libro/diario/anular/asiento/{id}', 'contable\LibroDiarioController@anular_asiento')->name('librodiario.anular_asiento');
