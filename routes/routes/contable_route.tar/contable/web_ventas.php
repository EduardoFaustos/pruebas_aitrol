<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */
//Route::match(['get', 'post'], 'contable/Banco/notadebito', 'contable\NotaDebitoController@index')->name('notadebito.index');

//Route::get('contable/Banco/notadebito/crear/', 'contable\NotaDebitoController@crear')->name('notadebito.crear');
Route::get('contable/ventas', 'contable\VentasController@index')->name('venta_index');
Route::get('contable/ventas2', 'contable\VentasController@index2')->name('venta_index2');
Route::get('contable/ventas/crear', 'contable\VentasController@crear')->name('ventas_crear');
Route::get('contable/ventas/crear_factura', 'contable\VentasController@crear_factura')->name('ventas_crear');
Route::post('contable/ventas/store', 'contable\VentasController@store')->name('ventas_store');
Route::match(['get', 'post'], 'contable/ventas/buscar', 'contable\VentasController@search')->name('ventas_search');
Route::post('contable/ventas/precio_producto', 'contable\VentasController@precios')->name('precios');

Route::get('contable/ventas/crear_orden', 'contable\VentasController@crear_orden')->name('orden_crear');
Route::post('contable/ventas/actualiza_orden', 'contable\VentasController@updateorden')->name('orden_update');

Route::post('contable/ventas/storeConsolidado', 'contable\VentasController@store_varios')->name('ventas_storeVarios');

Route::match(['get', 'post'], 'contable/ventas/buscarCliente', 'contable\VentasController@buscarCliente')->name('ventas.buscarcliente');
Route::match(['get', 'post'], 'contable/ventas/buscarClienteXId', 'contable\VentasController@buscarClientexId')->name('ventas.buscarclientexid');

Route::match(['get', 'post'], 'contable/ventas/buscarPaciente', 'contable\VentasController@buscarPaciente')->name('ventas.buscarpaciente');

Route::match(['get', 'post'], 'contable/ventas/buscarPaciente_Nombre', 'contable\VentasController@buscarPaciente_nombre')->name('ventas.buscarpaciente_nombre');

Route::match(['get', 'post'], 'contable/ventas/reporte_caja', 'contable\VentasController@index_cierre')->name('ventas.index_cierre');
Route::get('contable/venta/orden/{id_orden}', 'contable\VentasController@factura_caja')->name('venta.factura_orden');

Route::match(['get', 'post'], 'contable/ventas/facturas_omni', 'contable\VentasController@facturas_omni')->name('ventas.omni');
Route::post('contable/ventas/viewOmni', 'contable\VentasController@view_omni')->name('ventas_viewOmni');
Route::post('contable/ventas/store_omni', 'contable\VentasController@store_omni')->name('ventas_storeOmni');

Route::get('contable/venta/excel/{id}', 'contable\VentasController@excel')->name('venta.excel');

Route::get('contable/venta/previewExcell/{fecha}/{fechafin}/{seguro}/{tipo}/{id_empresa}', 'contable\VentasController@excelPreview')->name('venta.previewx');
Route::post('contable/venta/previewExcel/', 'contable\VentasController@previewData')->name('venta.preview');

//orden de venta
Route::get('contable/ventas/ordenes', 'contable\VentasController@ordenes')->name('orden_venta');
Route::get('contable/ventas/ordenes/editar/{id}', 'contable\VentasController@crear_facturaOrden')->name('orden_editar');
Route::get('contable/ventas/ordenes/crear', 'contable\VentasController@crear_ordenes')->name('ventas.crear_ordenes');
Route::post('contable/ventas/ordenes/store_ordenes', 'contable\VentasController@store_ordenes')->name('ventas.store_ordenes');
Route::get('contable/ventas/ordenes/eliminar/{id}', 'contable\VentasController@eliminar')->name('venorden.eliminar');

//facturas de insumos
Route::match(['get','post'],'contable/ventas/insumos', 'contable\VentasController@insumos')->name('insumos');
Route::match(['get','post'],'contable/ventas/insumos/search', 'contable\VentasController@searchInsumos')->name('insumos_search');

//Productos
//Route ::get('contable/productos', 'contable\VentasController@index')->name('venta_index');

//stock
Route::post('contable/ventas/consulta/stock', 'contable\VentasController@validarStock')->name('ventas.stock');
Route::post('contable/ventas/consulta/inventariable', 'contable\VentasController@esInventariable')->name('ventas.inventariable');
