<?php
Route::match(['get', 'post'],'contable/productos/productos_tarifario', 'contable\ProductosController@productos_tarifario')->name('productos.productos_tarifario');

Route::match(['get', 'post'],'contable/productos/crear', 'contable\ProductosController@crear')->name('productos.crear');

Route::match(['get', 'post'],'contable/productos/guardar', 'contable\ProductosController@guardar')->name('productos.guardar');

Route::match(['get', 'post'],'contable/productos/edit/{id_producto}', 'contable\ProductosController@edit')->name('productos.edit');

Route::match(['get', 'post'],'contable/productos/nivel', 'contable\ProductosController@nivel')->name('productos.nivel');

Route::match(['get', 'post'],'contable/productos/precios', 'contable\ProductosController@precios')->name('productos.precios');

Route::match(['get', 'post'],'contable/productos/update/{id_producto}', 'contable\ProductosController@update')->name('productos.update');

Route::match(['get', 'post'],'contable/productos/edit2/{id_producto}/{id_seguro}', 'contable\ProductosController@edit2')->name('productos.edit2');

Route::match(['get', 'post'],'contable/productos/buscar', 'contable\ProductosController@buscar')->name('productos.buscar');

//Mantenimiento Bodegas
Route::match(['get', 'post'], 'contable/bodegas', 'contable\BodegasController@index')->name('bodegas.index');
Route::get('contable/bodegas/crear', 'contable\BodegasController@crear')->name('bodegas.crear');
Route::post('contable/bodegas/guardar', 'contable\BodegasController@store')->name('bodegas.store');
Route::get('contable/bodegas/editar/{id}/{id_empresa}', 'contable\BodegasController@editar')->name('bodegas.editar');
Route::post('contable/bodegas/update', 'contable\BodegasController@update')->name('bodegas.update');
Route::match(['get', 'post'], 'contable/bodegas/buscar', 'contable\BodegasController@buscar')->name('bodegas.buscar');