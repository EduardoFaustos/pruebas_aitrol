<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

/*Nomina*/
Route::match(['get', 'post'], 'contable/nomina', 'contable\NominaController@index')->name('nomina.index');
Route::get('contable/nomina/crear/', 'contable\NominaController@crear')->name('nomina.crear');
Route::post('contable/nomina/buscarIdentificacion/', 'contable\NominaController@identificacion')->name('nomina.identificacion');
Route::get('contable/nomina/anular/{id}', 'contable\NominaController@anular')->name('nomina.anular');
//Route::post('contable/nomina/guardar', 'contable\NominaController@store')->name('nomina.store');
Route::match(['get', 'post'],'contable/nomina/guardar', 'contable\NominaController@store')->name('nomina.store');
Route::get('contable/nomina/revisar/{id}', 'contable\NominaController@revisar')->name('nomina.revisar');
Route::match(['get', 'post'],'contable/nomina/actualizar/', 'contable\NominaController@update')->name('nomina.actualizar');
Route::match(['get', 'post'],'contable/nomina/buscar', 'contable\NominaController@buscar')->name('nomina.buscar');
Route::get('contable/nomina/egresos/empleado/{id}', 'contable\NominaController@crear_egresos')->name('nomina.crear_egresos');
Route::post('contable/nomina/egresos/empleado/guardar', 'contable\NominaController@store_egresos')->name('nomina.store_egresos');

/*Rol de Pago*/
Route::get('contable/rol/pago/create/{id}', 'contable\RolPagoController@crear_rol_pago')->name('rol_pago.create');
Route::post('contable/rol/pago/store','contable\RolPagoController@store_rol_pago')->name('rol_pago.store');
Route::post('contable/rol/pago/update','contable\RolPagoController@update_rol_pago')->name('rol_pago.update');
Route::get('comprobante/rol/pago/{id_rolpag}', 'contable\RolPagoController@imprimir_rol_pago')->name('rol_pago.imprimir');
Route::get('contable/rol/pago/index/{id}/{id_empresa}', 'contable\RolPagoController@index')->name('rol_pago.index');
Route::get('contable/rol/pago/anular/{id}', 'contable\RolPagoController@anular')->name('rol_pago.anular');
Route::match(['get', 'post'],'contable/rol/pago/buscar', 'contable\RolPagoController@buscar')->name('rol_pago.buscar');
Route::post('contable/rol/pago/existe_anticipo','contable\RolPagoController@existe_valor')->name('rol_pago.existe_anticipo');
Route::post('contable/rol/pago/existe_prestamos','contable\RolPagoController@verifica_existe_prestamos')->name('rol_pago.existe_prestamos');
Route::post('contable/rol/pago/empleado/buscar_anticipo','contable\RolPagoController@verifica_existe_anticipo')->name('existe_anticipo.empleado');
Route::get('contable/rol/pago/editar/{id}', 'contable\RolPagoController@editar_rol')->name('rol_pago.editar');


/*Rol de Provisiones Sociales*/
Route::match(['get', 'post'], 'contable/rol/provisiones/sociales', 'contable\ProvisionesSocialesController@index')->name('rol_provisiones.index');
Route::match(['get', 'post'],'contable/rol/provisiones/sociales/buscar', 'contable\ProvisionesSocialesController@buscar')->name('rol_provisiones.buscar');

/*Configuraciones Valores*/
Route::match(['get', 'post'], 'contable/configuracion/valores', 'contable\NominaConfiguracionController@index')->name('config_valor.index');

Route::get('contable/configuracion/valores/create', 'contable\NominaConfiguracionController@crear_configuracion_valores')->name('configuracion_valores.create');

Route::post('contable/configuracion/valores/guardar', 'contable\NominaConfiguracionController@store')->name('config_valor.store');

Route::get('contable/configuracion/valores/editar/{id}', 'contable\NominaConfiguracionController@edit')->name('configuracion_valores.editar');

Route::post('contable/configuracion/valores/actualizar', 'contable\NominaConfiguracionController@update')->name('configuracion_valores.update');

Route::get('contable/configuracion/valores/anular/{id}', 'contable\NominaConfiguracionController@anular')->name('configuracion_valores.anular');

Route::match(['get', 'post'],'contable/configuracion/valores/buscar', 'contable\NominaConfiguracionController@buscar')->name('config_valor.buscar');

/*Lista Roles de Pago*/
Route::match(['get', 'post'], 'contable/buscador/rol/pago', 'contable\RolPagoController@buscador_index')->name('buscador_rol.index');
Route::post('contable/buscador/rol/pago/search', 'contable\RolPagoController@buscador_roles')->name('buscador_roles.pago');
//Route::match(['get', 'post'], 'contable/buscador/rol/pago/search', 'contable\RolPagoController@buscador_search')->name('buscador_rol.search');

/*Modal Editar Tipo de Pago*/
Route::get('contable/modal/edit/pago/{id}', 'contable\RolPagoController@obtener_edit_pago')->name('editar_pago.modal');

/*Prestamos Recibidos Empleados*/
Route::match(['get', 'post'], 'contable/nomina/prestamos/empleados', 'contable\PrestamosEmpleadosController@index')->name('prestamos_empleado.index');
Route::get('contable/nomina/prestamos/empleados/crear/{id_nomina}', 'contable\PrestamosEmpleadosController@crear')->name('prestamos_empleado.crear');
Route::post('contable/nomina/prestamos/store','contable\PrestamosEmpleadosController@store_prestamos_empl')->name('prestamos_empleado.store');
Route::match(['get', 'post'],'contable/nomina/prestamo/empleado/buscar', 'contable\PrestamosEmpleadosController@search_prestamo')->name('prestamo_empleado.search');


/*Anticipo Recibido Empleado*/
Route::match(['get', 'post'], 'contable/nomina/anticipos/empleados', 'contable\NominaAnticiposController@index_anticipos')->name('anticipos_empleado.index');
Route::get('contable/nomina/anticipos/empleados/crear/{id_nomina}', 'contable\NominaAnticiposController@crear_anticipo_empleado')->name('anticipo_empleado.crear');
Route::post('contable/nomina/anticipos/empleados/store','contable\NominaAnticiposController@store_anticipo_empleado')->name('anticipo_empleado.store');
Route::match(['get', 'post'],'contable/nomina/anticipo/empleado/buscar', 'contable\NominaAnticiposController@search_anticipo')->name('anticipo_empleado.search');

/*Otros Anticipos Empleados 25-10-2020*/
Route::get('contable/nomina/otros_anticipos/empleados/crear/{id_nomina}', 'contable\OtrosAnticiposEmpleadosController@crear_otros_anticipo_empleado')->name('otros_anticipo_empleado.crear');
Route::post('contable/nomina/otros_anticipos/empleados/store','contable\OtrosAnticiposEmpleadosController@store_otros_anticipo_empleado')->name('otros_anticipo_empleado.store');
Route::post('contable/rol/pago/empleado/buscar_otro_anticipo','contable\RolPagoController@verifica_existe_otros_anticipo')->name('existe_otros_anticipo.empleado');

/*Calculo Anticipo Quincena*/
Route::match(['get', 'post'], 'contable/nomina/anticipo/quincena', 'contable\NominaAnticiposController@index')->name('nomina_anticipos.index');

Route::post('contable/nomina/anticipo/search', 'contable\NominaAnticiposController@buscar_anticipos_quincena')->name('anticipos_quincena.buscar');

Route::post('contable/nomina/anticipo/calculo', 'contable\NominaAnticiposController@obtener_anticipo_quincena')->name('anticipos_quincena.valor');

Route::post('contable/nomina/anticipo/reporte', 'contable\NominaAnticiposController@obtener_reporte_quincena')->name('anticipos_quincena.reporte');

Route::get('contable/nomina/anticipo/editar/{id}/{idempleado}/{idempresa}', 'contable\NominaAnticiposController@edit_anticipo')->name('anticipos_quincena.editar');

Route::post('contable/nomina/anticipo/actualizar', 'contable\NominaAnticiposController@update')->name('anticipos_quincena.update');

/*Reportes Generales*/ 
Route::match(['get', 'post'], 'contable/nomina/reportes/empleados/crear', 'contable\NominaReporteEmpleadoController@index')->name('reportes_empl.index');
Route::match(['get', 'post'], 'contable/nomina/reportes/datos/empleados', 'contable\NominaReporteEmpleadoController@reporte_datos_empleados')->name('reporte_datos_empl');
Route::match(['get', 'post'], 'contable/nomina/reportes/roles/pago', 'contable\NominaReporteRolController@index')->name('reportes_rol.index');
Route::match(['get', 'post'], 'contable/nomina/reportes/datos/rol', 'contable\NominaReporteRolController@reporte_datos_rol_pago')->name('reporte_datos.rol');
Route::match(['get', 'post'], 'contable/nomina/reportes/banco', 'contable\NominaReporteBancoController@index')->name('reportes_banco.index');
Route::match(['get', 'post'], 'contable/nomina/reportes/datos/banco', 'contable\NominaReporteBancoController@reporte_datos_banco')->name('reporte_datos.banco');


//Visualizar Pdf Curriculum 
Route::get('contable/nomina/mostrar_foto_curriculum/{id}', 'contable\NominaController@obtener_imagen_curriculum')->name('nomina_imagen_curr.modal');

//Descargar Archivo Pdf Curriculum
Route::get('descarga_archivo_curriculum/{id}', 'contable\NominaController@descarga_archivo_curriculum');

//Visualizar Pdf Ficha Tecnica
Route::get('contable/nomina/mostrar_foto_ficha/{id}', 'contable\NominaController@obtener_imagen_ficha')->name('nomina_imagen_ficha.modal');

//Descargar Archivo Pdf Ficha Tecnica
Route::get('descarga_archivo_ficha/{id}', 'contable\NominaController@descarga_archivo_ficha');

//Visualizar Pdf Ficha Ocupacional
Route::get('contable/nomina/mostrar_foto_ocupacional/{id}', 'contable\NominaController@obtener_imagen_ocupacional')->name('nomina_imagen_ocupacional.modal');

//Descargar Archivo Pdf Ficha Ocupacional
Route::get('descarga_archivo_ocupacional/{id}', 'contable\NominaController@descarga_arch_ocupacional');

//Registro de Asientos de Diario-Rol Pago Empleados por Mes y Año
Route::post('contable/rol/pago/asientos_diario/store', 'contable\RolPagoController@store_asientos_diario')->name('asientos_rolpago.store');

//Carga Tabla Quirografario
Route::get('contable/rol_pago/carga_listado/quirografario/{id}', 'contable\RolPagoController@listado_cuota_quirografario')->name('carga_listado.quirografario');

//Carga Tabla Hipotecario
Route::get('contable/rol_pago/carga_listado/hipotecario/{id}', 'contable\RolPagoController@listado_cuota_hipotecario')->name('carga_listado.hipotecario');

/*Pdf Prestamos*/
Route::get('contable/nomina/prestamos/empleados/pdf_prestamos/{id}', 'contable\PrestamosEmpleadosController@pdfprestamos')->name('pdf_prestamos_egreso');

/*Pdf Anticipos 1ERA Quincena*/
Route::get('contable/nomina/anticipo_quincena/empleados/pdf_anticipo/{id}', 'contable\NominaAnticiposController@pdf_anticipo_quincena')->name('pdf_anticipo_egreso');

/*Pdf Otros Anticipos*/
Route::get('contable/nomina/otros_anticipos/empleados/pdf_otros_anticipo/{id}', 'contable\OtrosAnticiposEmpleadosController@pdf_otros_anticipo')->name('pdf_otros_anticipo_egreso');













