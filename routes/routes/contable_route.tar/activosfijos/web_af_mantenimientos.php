<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

//tipo
Route::resource('afTipo', 'activosfijos\TipoController');
Route::match(['get', 'post'],'activosfijos/tipo/search', 'activosfijos\TipoController@search')->name('activofjo.tipo.search');
//grupo
Route::resource('afGrupo', 'activosfijos\GrupoController');
Route::match(['get', 'post'],'activosfijos/grupo/search', 'activosfijos\GrupoController@search')->name('activofjo.grupo.search');
Route::match(['get', 'post'],'activosfijos/grupo/info', 'activosfijos\GrupoController@info')->name('activofjo.grupo.info');
Route::match(['get', 'post'],'activosfijos/grupo/nuevo', 'activosfijos\GrupoController@nuevo')->name('activofjo.grupo.nuevo');
Route::match(['get', 'post'],'activosfijos/grupo/reload', 'activosfijos\GrupoController@reload')->name('activofjo.grupo.reload');
//activo fijo
Route::resource('afActivo', 'activosfijos\ActivoFijoController');
Route::match(['get', 'post'],'activosfijos/activofijo/search', 'activosfijos\ActivoFijoController@search')->name('activofjo.activofijo.search');