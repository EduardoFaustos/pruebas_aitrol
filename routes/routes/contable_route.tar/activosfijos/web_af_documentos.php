<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

//Documento Factura
Route::resource('afDocumentoFactura', 'activosfijos\DocumentoFacturaController');
Route::match(['get', 'post'],'activojifos/documentofactura/buscar', 'activosfijos\DocumentoFacturaController@search')->name('activosfijos.documentofactura.search');
Route::match(['get', 'post'],'activojifos/documentofactura/anular/{id}', 'activosfijos\DocumentoFacturaController@anular')->name('activosfijos.documentofactura.anular');