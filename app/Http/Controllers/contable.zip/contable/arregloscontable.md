# ARREGLOS URG CONTABLE

* [X] EL SALDO EN EL KARDEX
* [X] ESTADO DE CUENTA DE BANCOS ## modificacion aun pendiente
* [X] Necesito hacer un masivo con las retenciones de clientes en la cual esta con la fecha que se creó y crear el nuevo campo
* [X] crear nuevo campo en retenciones clientes
* [X] arreglar base imponible en retecnion clientes
* [X] Cruce de cuentas en ventas
* [X] Funcion de precio /cantidad en factura de venta manual
* [X] conciliacion bancaria no funciona

Arreglos en los valores de las tablas
