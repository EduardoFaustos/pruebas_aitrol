<?php

namespace Sis_medico\Http\Controllers\contable;

use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Sis_medico\Ct_Nomina;
use Sis_medico\Ct_Rh_Valores;
use Sis_medico\Ct_Rol_Pagos;
use Sis_medico\Ct_Rh_Prestamos;
use Sis_medico\Ct_Rh_Prestamos_Detalle;
use Sis_medico\Http\Controllers\Controller;
//Nueva Forma de Pago
use Sis_medico\User;

class Nuevo_RolController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    private function rol()
    {
        $rolUsuario = Auth::user()->id_tipo_usuario;
        $id_auth    = Auth::user()->id;
        if (in_array($rolUsuario, array(1, 4, 5, 20, 22)) == false) {
            return true;
        }
    }

    public function index(Request $request, $id)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }

        $anio = $request->anio;
        $mes  = $request->mes;
        if ($anio == null) {
            $anio = date('Y');
        }
        if ($mes == null) {
            $mes = 0;
        }

        $empleado = Ct_Nomina::find($id);

        $roles = $empleado->roles->where('estado', 1)->where('anio', $anio)->sortByDesc('fecha_elaboracion');

        if ($mes > 0) {
            $roles = $roles->where('mes', $mes);
        }

        return view('contable/nuevo_rol_pago/index', ['empleado' => $empleado, 'roles' => $roles, 'anio' => $anio, 'mes' => $mes]);
    }

    public function crear($id)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }

        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;

        $nomina = Ct_Nomina::findorfail($id);
        /*$val_aport_pers = Ct_Rh_Valores::where('id_empresa', $registro->id_empresa)
        ->where('tipo', 1)->where('id', $registro->aporte_personal)->first();*/

        $val_fond_reserv = Ct_Rh_Valores::where('id_empresa', $nomina->id_empresa)
            ->where('tipo', 4)->first();//dd($val_fond_reserv);
        $val_sal_basico = Ct_Rh_Valores::where('id_empresa', $nomina->id_empresa)
            ->where('tipo', 3)->first();
        $anio = date('Y');
        $mes  = date('m');
        $rol = Ct_Rol_Pagos::where('ct_rol_pagos.estado', '1')
            ->where('ct_rol_pagos.anio', $anio)
            ->where('ct_rol_pagos.mes', $mes)
            ->where('ct_rol_pagos.id_nomina', $nomina->id)
            ->first();

        $prestamos = Ct_Rh_Prestamos::where('id_empl', $nomina->id_user)
            ->where('id_empresa', $nomina->id_empresa)
            ->where('estado','1')
            ->where('prest_cobrad','0')
            ->get();   

        foreach($prestamos as $prestamo){

            $cuotas = $prestamo->detalles()->where('estado',1)->where('estado_pago',1)->count();//dd($cuotas);
            $anio   = $prestamo->anio_inicio_cobro;
            $mes    = $prestamo->mes_inicio_cobro;
            $mes    = $mes + $cuotas;
            if($mes > 12){
                $mes = 1;
                $año ++;
            }
            $cuotas++;

            Ct_Rh_Prestamos_Detalle::create([
                'id_ct_rh_prestamos' => $prestamo->id,
                'anio'               => $anio,
                'mes'                => $mes,
                'fecha'              => date('Y-m-d H:i:s'),
                'cuota'              => $cuotas,
                'valor_cuota'        => $prestamo->valor_cuota,
                //'id_ct_rol_pagos',
                'estado'             => '1',
                'estado_pago'        => '1',
                'fecha_pago'         => date('Y-m-d H:i:s'),
                'id_usuariocrea'     => $idusuario,
                'id_usuariomod'      => $idusuario,
                'ip_crea'            => $ip_cliente,
                'ip_modificacion'    => $ip_cliente,
            ]);
            $saldo_prestamo = $prestamo->saldo_total;
            $saldo_prestamo -= $prestamo->valor_cuota;
            $prestamo->update([
                'saldo_total' => $saldo_prestamo, 
            ]);
            if($cuotas >= $prestamo->num_cuotas){
                $prestamo->update([
                    'prest_cobrad' => '1', 
                ]);    
            }

        }     

        dd($prestamos_empleado);

        if (is_null($rol)) {
            /*AUN NO CREAR
            $id_rol = Ct_Rol_Pagos::insertGetId([
                'id_nomina'         => $nomina->id,
                'id_user'           => $nomina->id_user,
                'id_empresa'        => $nomina->id_empresa,
                'anio'              => $anio,
                'mes'               => $mes,
                'id_tipo_rol'       => '1',
                //'neto_recibido'     => ,
                'fecha_elaboracion' => $fecha,
                'estado'            => '1',
                'id_usuariocrea'    => $idusuario,
                'id_usuariomod'     => $idusuario,
                'ip_creacion'       => $ip_cliente,
                'ip_modificacion'   => $ip_cliente,

            ]);
            */

            //VERIFICAR ESTA CARGADA LA VARIABLE NOMINA Y VALOR DEL FONDO DE RESERVA;
            $dias_laborados = 30;$sobre_tiempo_50 = 0;$sobre_tiempo_100 = 0;$cantidad_horas50 = 0;$cantidad_horas100 = 0;
            $bonificacion = 0;$transporte = 0;$exam_laboratorio = 0;$fondo_reserva = 0;$decimo_tercero = 0;$decimo_cuarto = 0;

            $sueldo_mensual     = $nomina->sueldo_neto;
            $bono_imputable     = $nomina->bono_imputable;
            $alimentacion       = $nomina->alimentacion;
            $fecha_ingreso      = $nomina->fecha_ingreso;
            $tipo_fondo_reserva = $nomina->pago_fondo_reserva;
            $tipo_decimo_cuarto      = $nomina->decimo_cuarto;
            $tipo_decimo_tercero     = $nomina->decimo_tercero;
            $aporte_personal         = $nomina->aportepersonal->valor;
            $seguro_privado          = $nomina->seguro_privado;

            $pct_fondo_reserva   = $val_fond_reserv->valor;
            $valor_sueldo_basico = $val_sal_basico->valor; 


            //SUELDO_MENSUAL = SUELDO_NOMINA / 30 * DIAS_LABORADOS
            $sueldo_mensual = $sueldo_mensual / 30;
            $sueldo_mensual = $sueldo_mensual * $dias_laborados;
            $sueldo_mensual = round($sueldo_mensual,2);
            
            //BASE_IESS = SUELDO MES + VALOR_EXTRAS50 + VALOR_EXTRAS100 + BONO_IMPUTABLE
            $base_iess = $sueldo_mensual + $sobre_tiempo_50 + $sobre_tiempo_100 + $bono_imputable;

            //FONDO DE RESERVA
            $fecha         = date("Y-m-d");
            $fec           = new DateTime($fecha);
            $fec2          = new DateTime($fecha_ingreso);
            $diff          = $fec->diff($fec2); //dd($diff);
            $intervalMeses = $diff->format("%m");
            $intervalAnos  = $diff->format("%y") * 12; //dd($intervalMeses,$intervalAnos);
            $añosAhora    = $diff->format("%y"); //dd($añosAhora);
            $intervalDias  = $diff->format("%d");
            $diaActual     = $fec->format("d");
            $meses_totales = $intervalMeses + $intervalAnos; //dd($meses_totales);
            if ($añosAhora > 0) {
                if ($tipo_fondo_reserva == 2) { //mensualiza
                    $fondo_reserva = $base_iess * ($pct_fondo_reserva / 100);
                } 
            }
            $fondo_reserva = round($fondo_reserva,2);

            //DECIMO TERCER
            if($tipo_decimo_tercero == 2){
                $decimo_tercero = $base_iess / 12;    
            }
            $decimo_tercero = round($decimo_tercero,2);

            //DECIMO CUARTO
            if($tipo_decimo_cuarto == 2){
                $decimo_cuarto = $valor_sueldo_basico / 12;    
            }
            $decimo_cuarto = round($decimo_cuarto,2);

            //PORCENTAJE IESS
            $porcentaje_iess = $base_iess * $aporte_personal / 100;

            dd($sueldo_mensual, $base_iess, $tipo_fondo_reserva, $pct_fondo_reserva, $fondo_reserva, $decimo_tercero, $decimo_cuarto, $porcentaje_iess);

            //Guardado en la Tabla Ct_Detalle_Rol
            Ct_Detalle_Rol::create([
                'id_rol'                    => $id_rol,
                'dias_laborados'            => $dias_laborados,
                'base_iess'                 => $base_iess,
                'sueldo_mensual'            => $sueldo_mensual,
                'cantidad_horas50'          => $cantidad_horas50,
                'sobre_tiempo50'            => $sobre_tiempo_50,
                'cantidad_horas100'         => $cantidad_horas100,
                'sobre_tiempo100'           => $sobre_tiempo_100,
                'bonificacion'              => $bonificacion,
                'alimentacion'              => $alimentacion,
                'transporte'                => $transporte,
                'bono_imputable'            => $bono_imputable,
                'exam_laboratorio'          => $exam_laboratorio,
                'fondo_reserva'             => $fondo_reserva,
                'decimo_tercero'            => $decimo_tercero,
                'decimo_cuarto'             => $decimo_cuarto,
                'porcentaje_iess'           => $porcentaje_iess,
                'seguro_privado'            => $seguro_privado,
                //'impuesto_renta'            => $request['impuesto_renta'],
                //'multa'                     => $request['valor_multa'],
                //'fond_reserv_cobrar'        => $request['fond_res_cobrar_trab'],
                //'otros_egresos'             => $request['otros_egresos_trab'],
                'prestamos_empleado'        => $request['prestamo_empleado'],
                'saldo_inicial_prestamo'    => $request['saldo_inicial'],
                'anticipo_quincena'         => $request['anticipo_quincena'],
                'observacion_bono'          => $request['observacion_bono'],
                'observacion_alimentacion'  => $request['observacion_alimentacion'],
                'observ_seg_privado'        => $request['observacion_seg_priv'],
                'observ_imp_renta'          => $request['observacion_imp_rent'],
                'otro_anticipo'             => $request['otro_anticipo'],
                'observacion_multa'         => $request['observ_multa'],
                'observacion_fondo_cobrar'  => $request['obs_fond_cob_trab'],
                'observacion_prestamo'      => $request['concepto_prestamo'],
                'observacion_saldo_inicial' => $request['obser_saldo_inicial'],
                'observacion_anticip_quinc' => $request['concepto_quincena'],
                'observacion_otro_anticip'  => $request['concep_otros_anticipos'],
                'observacion_transporte'    => $request['observacion_transporte'],
                'observacion_bonoimp'       => $request['observacion_bonoimp'],
                'observ_examlaboratorio'    => $request['observ_examlaboratorio'],
                'observacion_otro_egreso'   => $request['obs_otros_egres_trab'],
                'total_ingresos'            => $total_ingreso,
                'total_egresos'             => $total_egreso,
                'neto_recibido'             => $neto_recibir,
                'total_quota_quirog'        => $request['total_val_quot_quir'],
                'total_quota_hipot'         => $request['total_val_quot_hip'],
                'id_usuariocrea'            => $idusuario,
                'id_usuariocrea'            => $idusuario,
                'id_usuariomod'             => $idusuario,
                'ip_creacion'               => $ip_cliente,
                'ip_modificacion'           => $ip_cliente,
            ]);

        }

        if (!is_null($existe_rol)) {
            return redirect()->route('rol_pago.editar', ['id' => $existe_rol->id]);
        } else {
            return view('contable/rol_pago/create_rol', ['empresa' => $empresa, 'usuario' => $usuario, 'registro' => $registro, 'ct_tipo_rol' => $ct_tipo_rol, 'val_aport_pers' => $val_aport_pers, 'tipo_pago_rol' => $tipo_pago_rol, 'val_fond_reserv' => $val_fond_reserv, 'val_sal_basico' => $val_sal_basico, 'tipo_cuenta' => $tipo_cuenta, 'lista_banco' => $lista_banco, 'prestam_empl' => $prestam_empl, 'anio' => $anio, 'mes' => $mes, 'monto_fondo_reserva' => $monto_fondo_reserva, 'pago_fondo' => $pago_fondo]);
        }

        //Guia Forma de Pago Factura de Venta
        //$tipo_pago = Ct_Tipo_Pago::where('estado', '1')->get();
        //$tipo_tarjeta = Ct_Tipo_Tarjeta::all();

        /*return view('contable/rol_pago/create', ['empresa' => $empresa,'usuario' => $usuario,'registro' => $registro,'ct_tipo_rol' => $ct_tipo_rol,'val_aport_pers' => $val_aport_pers]);*/

    }

}
