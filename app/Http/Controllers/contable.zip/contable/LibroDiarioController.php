<?php

namespace Sis_medico\Http\Controllers\contable;

use Excel;
use Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Session;
use Sis_medico\Ct_Asientos_Cabecera;
use Sis_medico\Ct_Asientos_Detalle;
use Sis_medico\Ct_Comprobante_Egreso;
use Sis_medico\Ct_Comprobante_Egreso_Varios;
use Sis_medico\Ct_Comprobante_Ingreso;
use Sis_medico\Ct_Comprobante_Ingreso_Varios;
use Sis_medico\Ct_Credito_Acreedores;
use Sis_medico\Ct_Cruce_Valores;
use Sis_medico\Ct_Cruce_Valores_Cliente;
use Sis_medico\Ct_Debito_Acreedores;
use Sis_medico\Ct_Nota_Debito_Cliente;
use Sis_medico\Empresa;
use Sis_medico\Http\Controllers\Controller;
use Sis_medico\Plan_Cuentas;
use Sis_medico\UsuarioEspecial;

class LibroDiarioController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    private function rol()
    {
        $rolUsuario = Auth::user()->id_tipo_usuario;
        $id_auth    = Auth::user()->id;
        if (in_array($rolUsuario, array(1, 4, 5, 20, 22)) == false) {
            return true;
        }
    }

    public function index(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        if (!is_null($request['fecha']) && !is_null($request['fecha_hasta'])) {
            $fecha       = $request['fecha'];
            $fecha_hasta = $request['fecha_hasta'];
        } else {
            $fecha       = date('Y-m-d');
            $fecha_hasta = date('Y-m-d');
        }
        $id_empresa = $request->session()->get('id_empresa');
        $empresa    = Empresa::where('id', $id_empresa)->first();
        $registros  = DB::table('ct_asientos_cabecera as ct_c')
            ->leftjoin('empresa as p', 'p.id', 'ct_c.id_empresa')
            ->select('ct_c.id', 'ct_c.fecha_asiento', 'ct_c.observacion', 'ct_c.valor', 'p.nombrecomercial', 'ct_c.estado', 'ct_c.id_usuariocrea')
            ->where('ct_c.id_empresa', $id_empresa)
            ->orderby('id', 'desc')
            ->paginate(15);

        return view('contable/diario/index', ['registros' => $registros, 'fecha' => $fecha, 'fecha_hasta' => $fecha_hasta, 'empresa' => $empresa]);
    }

    public function buscar(Request $request)
    {
        $id       = $request['nombre'];
        $contador = $request['contador'];
        $cuenta   = plan_cuentas::find($id);
        return view('contable/diario/unico', ['cuenta' => $cuenta, 'contador' => $contador]);
    }

    public function revisar(Request $request, $id)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $registro = Ct_Asientos_Cabecera::findorfail($id);
        $detalle  = Ct_Asientos_Detalle::where('id_asiento_cabecera', $id)
            ->groupBy('id_plan_cuenta')
            ->select('id_plan_cuenta', 'descripcion')
            ->select(DB::raw('id_plan_cuenta, descripcion, SUM(debe) as debe, SUM(haber) as haber'))
            ->get();

        $id_empresa = $request->session()->get('id_empresa');

        //$empresa = Empresa::where('id', '0992704152001')->first();
        //$empresa = Empresa::where('id', '0992704152001')->first();

        $empresa = Empresa::where('id', $id_empresa)
            ->where('estado', '1')
            ->first();
        $cuentas = Plan_Cuentas::all();

        return view('contable/diario/asiento', ['registro' => $registro, 'empresa' => $empresa, 'detalle' => $detalle, 'cuentas' => $cuentas]);
    }
    public function edit(Request $request, $id)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $registro = Ct_Asientos_Cabecera::findorfail($id);
        $detalle  = Ct_Asientos_Detalle::where('id_asiento_cabecera', $id)
            ->groupBy('id_plan_cuenta')
            ->select('id_plan_cuenta', 'descripcion', 'id')
            ->select(DB::raw('id_plan_cuenta,id, descripcion, SUM(debe) as debe, SUM(haber) as haber'))
            ->get();
        //dd($registro);

        $id_empresa = $request->session()->get('id_empresa');

        //$empresa = Empresa::where('id', '0992704152001')->first();
        //$empresa = Empresa::where('id', '0992704152001')->first();

        $empresa = Empresa::where('id', $id_empresa)
            ->where('estado', '1')
            ->first();
        $cuentas  = Plan_Cuentas::all();
        $id_auth  = Auth::user()->id;
        $especial = UsuarioEspecial::where('id_usuario', $id_auth)->where('id_empresa', $id_empresa)->first();

        return view('contable/diario/edit', ['registro' => $registro, 'empresa' => $empresa, 'detalle' => $detalle, 'cuentas' => $cuentas, 'especial' => $especial]);
    }
    public function update(Request $request, $id)
    {
        $asientos = Ct_Asientos_Detalle::where('id_asiento_cabecera', $id);
        //dd($asientos);
        $contador = 0;
        $sri      = $request['aparece_sri'];
        //dd($sri);
        if ($sri == 'on') {
            $sri = 1;
        } elseif (is_null($sri)) {
            $sri = 0;
        }
        //dd($sri);
        $cabecera   = Ct_Asientos_Cabecera::find($id);
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $asientos->delete();
        foreach ($request['id_asiento'] as $f) {
            //hacer update
            Ct_Asientos_Detalle::create([
                'id_asiento_cabecera' => $cabecera->id,
                'id_plan_cuenta'      => $request['id_plan_cuenta'][$contador],
                'descripcion'         => $request['descripcion'][$contador],
                'fecha'               => $cabecera->fecha_asiento,
                'debe'                => $request['debe'][$contador],
                'haber'               => $request['haber'][$contador],
                'estado'              => '1',
                'ip_creacion'         => $ip_cliente,
                'ip_modificacion'     => $ip_cliente,
                'id_usuariocrea'      => $idusuario,
                'id_usuariomod'       => $idusuario,
            ]);
            $contador++;
        }
        if (isset($request['especial'])) {
            $especial = $request['especial'];
            //dd($sri);
            if ($especial == 'on') {
                $especial = 1;
            } elseif (is_null($especial)) {
                $especial = 0;
            }
            $cabecera->especial = $especial;
        }
        if ($request['totaldebe'] > 0 && $request['totalhaber'] > 0) {
            $total = $request['totaldebe'];
            //dd($cabecera->aparece_sri);
            if (!is_null($cabecera)) {
                $cabecera->aparece_sri     = $sri;
                $cabecera->valor           = $total;
                $cabecera->observacion     = $request['observacion'];
                $cabecera->id_usuariomod   = $idusuario;
                $cabecera->fecha_asiento   = $request['fecha_asiento'];
                $cabecera->ip_modificacion = $ip_cliente;
                //dd($cabecera->aparece_sri);
                $cabecera->save();
            }
        }
        return redirect()->route('librodiario.edit', ['id' => $id]);
    }
    public function crear(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $id_empresa = $request->session()->get('id_empresa');
        $empresa    = Empresa::where('id', $id_empresa)->where('estado', '1')->first();
        $cuentas    = plan_cuentas::all();
        return view('contable/diario/create', ['cuentas' => $cuentas, 'empresa' => $empresa]);
    }

    public function search(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }

        $id_empresa = $request->session()->get('id_empresa');

        $empresa = Empresa::where('id', $id_empresa)->first();

        $constraints = [
            'ct_c.id'             => $request['id'],
            'nombrecomercial'     => $request['empresa'],
            'observacion'         => $request['detalle'],
            'ct_c.fact_numero'    => $request['secuencia_f'],
            'ct_c.fecha_asiento'  => $request['fecha'],
            'ct_c.id_usuariocrea' => $request['ct_c.id_usuariocrea'],
            'ct_c.aparece_sri'    => $request['sri'],
        ];
        //dd($request);
        //dd($constraints);
        $registros = $this->doSearchingQuery($constraints, $request);
        return view('contable/diario/index', ['request' => $request, 'registros' => $registros, 'searchingVals' => $constraints, 'empresa' => $empresa]);
    }

    /*************************************************
     ******************CONSULTA QUERY******************
    /*************************************************/
    private function doSearchingQuery($constraints, Request $request)
    {
        $id_empresa = $request->session()->get('id_empresa');
        $query      = DB::table('ct_asientos_cabecera as ct_c')
            ->join('empresa as p', 'p.id', 'ct_c.id_empresa')
            ->where('ct_c.id_empresa', $id_empresa)
            ->select('ct_c.id', 'p.nombrecomercial', 'ct_c.fecha_asiento', 'ct_c.observacion', 'ct_c.valor', 'ct_c.estado', 'ct_c.fact_numero', 'ct_c.id_usuariocrea');
        $fields = array_keys($constraints);

        $index = 0;

        foreach ($constraints as $constraint) {
            if ($constraint != null) {
                $query = $query->where($fields[$index], 'like', '%' . $constraint . '%');
                if ($fields[$index] == "ct_c.id") {
                    $query = $query->where($fields[$index], $constraint);
                }
            }

            $index++;
        }

        return $query->orderBy('ct_c.id', 'desc')->paginate(15);
    }
    public function buscar_empresa(Request $request)
    {

        $codigo       = $request['term'];
        $data         = null;
        $nuevo_nombre = explode(' ', $codigo);
        $seteo        = "%";
        foreach ($nuevo_nombre as $value) {
            $seteo = $seteo . $value . '%';
        }
        $query = "SELECT CONCAT_WS(' ',nombrecomercial) as completo
                  FROM `empresa`
                  WHERE CONCAT_WS(' ',nombrecomercial) like '" . $seteo . "'
                  ";
        $nombres = DB::select($query);
        foreach ($nombres as $product) {
            $data[] = array('value' => $product->completo);
        }
        if (count($data)) {
            return $data;
        } else {
            return ['value' => 'No se encontraron resultados'];
        }
    }

    public function store(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $check = 0;
        if (isset($request['aparece_sri'])) {
            $check = 1;
        }
        //dd($request);
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $id_empresa = $request->session()->get('id_empresa');

        $id_asiento = Ct_Asientos_Cabecera::insertGetId([
            'observacion'     => $request['observacion'],
            'fecha_asiento'   => $request['fecha_asiento'] . ' ' . date('H:i:s'),
            'valor'           => $request['total'],
            'id_empresa'      => $id_empresa,
            'aparece_sri'     => $check,
            'ip_creacion'     => $ip_cliente,
            'ip_modificacion' => $ip_cliente,
            'id_usuariocrea'  => $idusuario,
            'id_usuariomod'   => $idusuario,
        ]);
        if (isset($request->final)) {
            //dd($request->all());
            //ingresos va en el debe
            // gastos va en el haber
            for ($i = 0; $i < count($request->input("debe")); $i++) {
                Ct_Asientos_Detalle::create([
                    'id_asiento_cabecera' => $id_asiento,
                    'id_plan_cuenta'      => $request->input('id_plan_cuenta')[$i],
                    'debe'                => $request->input('debe')[$i],
                    'haber'               => $request->input('haber')[$i],
                    'fecha'               => $request['fecha_asiento'],
                    'ip_creacion'         => $ip_cliente,
                    'ip_modificacion'     => $ip_cliente,
                    'id_usuariocrea'      => $idusuario,
                    'id_usuariomod'       => $idusuario,
                ]);

            }
        } else {
            for ($i = 1; $i <= $request['contador']; $i++) {
                if (!is_null($request['debe' . $i]) && !is_null($request['haber' . $i])) {
                    Ct_Asientos_Detalle::create([
                        'id_asiento_cabecera' => $id_asiento,
                        'id_plan_cuenta'      => $request['id_plan' . $i],
                        'debe'                => $request['debe' . $i],
                        'haber'               => $request['haber' . $i],
                        'fecha'               => $request['fecha_asiento'],
                        'ip_creacion'         => $ip_cliente,
                        'ip_modificacion'     => $ip_cliente,
                        'id_usuariocrea'      => $idusuario,
                        'id_usuariomod'       => $idusuario,
                    ]);
                }
            }
        }

        return redirect()->route('librodiario.index');
    }

    public function __libro_mayor(Request $request)
    {
        $id_empresa = Session::get('id_empresa');
        if (isset($request['fecha'])) {
            $fecha = $request['fecha'];
        } else {
            $fecha = date('Y-m-d');
        }

        if (isset($request['fecha_hasta'])) {
            $fecha_hasta = $request['fecha_hasta'];
        } else {
            $fecha_hasta = date('Y-m-d');
        }

        if (isset($request['cuenta'])) {
            $filcuenta = $request['cuenta'];
        } else {
            $filcuenta = '[]';
        }

        $conditions = array();
        if ($filcuenta != '[]') {
            foreach ($filcuenta as $field) {
                // $conditions[] = ['id', 'like', '%' . $field . '%'];
                $conditions[] = $field;
            }
        }

        $id_empresa = $request->session()->get('id_empresa');
        $empresa    = Empresa::where('id', $id_empresa)->where('estado', '1')->first();
        $scuentas   = plan_cuentas::where('estado', '=', 2)->get();

        //$cuentas = Plan_Cuentas::where('id', 'like', '_.__.__')->orwhere('id', 'like', '_._.__')->orwhere('id', 'like', '_.__.___')->get();
        if (count($conditions) > 0) {
            // $cuentas = Plan_Cuentas::where('id', 'like', $filcuenta)->get();
            $cuentas = Plan_Cuentas::whereIn('id', $conditions)->get();
        } else {
            //$cuentas = Plan_Cuentas::where('id', 'like', '_.__.__')->orwhere('id', 'like', '_._.__')->orwhere('id', 'like', '_.__.___')->get();
            $cuentas = array();
        }

        if (!isset($request['imprimir'])) {
            // return view('contable/libro_mayor/index', ['cuentas' => $cuentas, 'fecha' => $fecha, 'fecha_hasta' => $fecha_hasta,
            // 'empresa' => $empresa, 'scuentas' => $scuentas, 'filcuenta' => $filcuenta, 'id_empresa'=>$id_empresa]);

            return view('contable/libro_mayor/index', compact('cuentas', 'fecha', 'fecha_hasta', 'empresa', 'scuentas', 'filcuenta', 'id_empresa'));
        } else {
            if (isset($request['filfecha'])) {
                $fecha = $request['filfecha'];
            } else {
                $fecha = date('Y-m-d');
            }

            if (isset($request['filfecha_hasta'])) {
                $fecha_hasta = $request['filfecha_hasta'];
            } else {
                $fecha_hasta = date('Y-m-d');
            }

            if (isset($request['filcuenta'])) {
                $filcuenta = $request['filcuenta'];
            } else {
                $filcuenta = '[]';
            }

            $conditions = array();
            if ($filcuenta != '[]' and $filcuenta != null) {
                $filcuenta = explode(",", $filcuenta);
                foreach ($filcuenta as $field) {
                    $conditions[] = ['id', 'like', '%' . $field . '%'];
                }
            }

            if (count($conditions) > 0) {
                // $cuentas = Plan_Cuentas::where('id', 'like', $filcuenta)->get();
                $cuentas = Plan_Cuentas::where($conditions)->get();
            } else {
                //$cuentas = Plan_Cuentas::where('id', 'like', '_.__.__')->orwhere('id', 'like', '_._.__')->orwhere('id', 'like', '_.__.___')->get();
                $cuentas = array();
            }

            if ($request['exportar'] == "") {
                $vistaurl = "contable/libro_mayor/print";
                $view     = \View::make($vistaurl, compact('cuentas', 'fecha', 'fecha_hasta', 'empresa', 'scuentas', 'filcuenta', 'id_empresa'))->render();

                $pdf = \App::make('dompdf.wrapper');
                $pdf->loadHTML($view);
                $pdf->setOptions(['dpi' => 150, 'isPhpEnabled' => true]);
                $pdf->setPaper('A4', 'portrait');

                return $pdf->stream('Mayor-' . $filcuenta . '.pdf');
            } else {
                $this->libro_mayor_excel($fecha, $fecha_hasta, $empresa, $cuentas);
            }

            /*  return view('contable/libro_mayor/print', ['cuentas' => $cuentas, 'fecha' => $fecha, 'fecha_hasta' => $fecha_hasta, 'empresa'=>$empresa, 'scuentas'=>$scuentas, 'filcuenta'=>$filcuenta]);*/
        }
    }

    public function libro_mayor(Request $request)
    {
        // dd($request['cuenta_hasta']);
        $filcuenta      = '';
        $filcuentahasta = '';
        $id_empresa     = Session::get('id_empresa');
        if (isset($request['fecha'])) {
            $fecha = $request['fecha'];
        } else {
            $fecha = date('Y-m-d');
        }
        //        dd($fecha);
        if (isset($request['fecha_hasta'])) {
            $fecha_hasta = $request['fecha_hasta'];
        } else {
            $fecha_hasta = date('Y-m-d');
        }

        if (isset($request['cuenta'])) {
            $filcuenta = $request['cuenta'];
        } else {
            $filcuenta = '';
        }
        //dd($filcuenta);
        if (isset($request['cuenta_hasta'])) {
            $filcuentahasta = $request['cuenta_hasta'];
        } else {
            $filcuentahasta = '';
        }
        //dd($filcuentahasta);
        $id_empresa = $request->session()->get('id_empresa');
        $empresa    = Empresa::where('id', $id_empresa)->where('estado', '1')->first();
        $scuentas   = plan_cuentas::where('estado', '=', 2)->get();

        //$cuentas = Plan_Cuentas::where('id', 'like', '_.__.__')->orwhere('id', 'like', '_._.__')->orwhere('id', 'like', '_.__.___')->get();
        if ($filcuenta != '' and $filcuentahasta != '') {
            $cuentas = Plan_Cuentas::whereBetween('id', array($filcuenta, $filcuentahasta))

                ->get();
        } elseif ($filcuenta != '') {
            $cuentas = Plan_Cuentas::where('id', '=', $filcuenta)->get();
        } else {
            $cuentas = array();
        }
        // dd($cuentas);
        if (!isset($request['imprimir'])) {
            //dd('');
            return view('contable/libro_mayor/index', compact('cuentas', 'fecha', 'fecha_hasta', 'empresa', 'scuentas', 'filcuenta', 'id_empresa', 'filcuentahasta'));
        } else {
            if (isset($request['filfecha'])) {
                $fecha = $request['filfecha'];
            } else {
                $fecha = date('Y-m-d');
            }

            if (isset($request['filfecha_hasta'])) {
                $fecha_hasta = $request['filfecha_hasta'];
            } else {
                $fecha_hasta = date('Y-m-d');
            }

            if (isset($request['filcuenta'])) {
                $filcuenta = $request['filcuenta'];
            } else {
                $filcuenta = '';
            }

            if (isset($request['filcuenta_hasta'])) {
                $filcuentahasta = $request['filcuenta_hasta'];
            } else {
                $filcuentahasta = '';
            }

            // $conditions = array();
            // if ($filcuenta != '[]' and $filcuenta != null) {
            //     $filcuenta = explode(",", $filcuenta);
            //     foreach ($filcuenta as $field) {
            //         $conditions[] = ['id', 'like', '%' . $field . '%'];
            //     }
            // }

            // dd($request);

            if ($filcuenta != '' and $filcuentahasta != '') {
                $cuentas = Plan_Cuentas::whereBetween('id', array($filcuenta, $filcuentahasta))

                    ->get();
            } elseif ($filcuenta != '') {
                $cuentas = Plan_Cuentas::where('id', '=', $filcuenta)->get();
            } else {
                $cuentas = array();
            }

            if ($request['exportar'] == "") {
                $vistaurl = "contable/libro_mayor/print";
                $view     = \View::make($vistaurl, compact('cuentas', 'fecha', 'fecha_hasta', 'empresa', 'scuentas', 'filcuenta', 'id_empresa'))->render();

                $pdf = \App::make('dompdf.wrapper');
                $pdf->loadHTML($view);
                $pdf->setOptions(['dpi' => 150, 'isPhpEnabled' => true]);
                $pdf->setPaper('A4', 'portrait');

                return $pdf->stream('Mayor-' . $filcuenta . '.pdf');
            } else {
                // dd($cuentas);
                $this->libro_mayor_excel($fecha, $fecha_hasta, $empresa, $cuentas);
            }

            /*  return view('contable/libro_mayor/print', ['cuentas' => $cuentas, 'fecha' => $fecha, 'fecha_hasta' => $fecha_hasta, 'empresa'=>$empresa, 'scuentas'=>$scuentas, 'filcuenta'=>$filcuenta]);*/
        }
    }

    public function libro_mayor_excel($fecha_desde, $fecha_hasta, $empresa, $cuentas)
    {

        Excel::create('LibroMayor-' . $fecha_desde . '-al-' . $fecha_hasta, function ($excel) use ($empresa, $fecha_desde, $fecha_hasta, $cuentas) {
            $excel->sheet('LibroMayor', function ($sheet) use ($empresa, $fecha_desde, $fecha_hasta, $cuentas) {
                $sheet->mergeCells('A1:H1');
                $sheet->cell('A1', function ($cell) use ($empresa) {
                    // manipulate the cel
                    $cell->setValue($empresa->nombrecomercial);
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('15');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', '', 'thin');
                });
                $sheet->mergeCells('A2:H2');
                $sheet->cell('A2', function ($cell) use ($empresa) {
                    // manipulate the cel
                    $cell->setValue($empresa->id);
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('15');
                    $cell->setAlignment('center');
                    $cell->setBorder('', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('A3:H3');
                $sheet->cell('A3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue("LIBRO MAYOR");
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('15');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('A4:H4');
                $sheet->cell('A4', function ($cell) use ($fecha_desde, $fecha_hasta) {
                    // manipulate the cel
                    $cell->setValue("$fecha_desde al $fecha_hasta");
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->setColumnFormat(array(
                    'F' => '0.00',
                    'G' => '0.00',
                    'H' => '0.00',
                ));

                $i = $this->cab_detalle($sheet, 5);
                // dd('Detalle');
                $i = $this->setDetalles($sheet, $i, $cuentas, $fecha_desde, $fecha_hasta, $empresa->id);

                //  CONFIGURACION FINAL
                $sheet->cells('A3:H3', function ($cells) {
                    // manipulate the range of cells
                    $cells->setBackground('#0070C0');
                    // $cells->setFontSize('10');
                    $cells->setFontWeight('bold');
                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                    $cells->setValignment('center');
                });

                $sheet->cells('A5:H5', function ($cells) {
                    // manipulate the range of cells
                    $cells->setBackground('#cdcdcd');
                    $cells->setFontWeight('bold');
                    $cells->setFontSize('12');
                });

                $sheet->setWidth(array(
                    'A' => 12,
                    'B' => 12,
                    'C' => 12,
                    'D' => 12,
                    'E' => 12,
                    'F' => 12,
                    'G' => 12,
                    'H' => 12,
                ));
            });
        })->export('xlsx');
    }

    public function cab_detalle($sheet, $i)
    {
        //$sheet->mergeCells('A4:A5');
        $sheet->cell("A$i", function ($cell) {
            // manipulate the cel
            $cell->setValue('FECHA');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        // $sheet->mergeCells('B5:E5');
        $sheet->cell("B$i", function ($cell) {
            // manipulate the cel
            $cell->setValue('ASIENTO');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        $sheet->cell("C$i", function ($cell) {
            // manipulate the cel
            $cell->setValue('CUENTA');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        $sheet->cell("D$i", function ($cell) {
            // manipulate the cel
            $cell->setValue('NOMBRE DE LA CUENTA');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        $sheet->cell("E$i", function ($cell) {
            // manipulate the cel
            $cell->setValue('DETALLE');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        $sheet->cell("F$i", function ($cell) {
            // manipulate the cel
            $cell->setValue('DEBE');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        $sheet->cell("G$i", function ($cell) {
            // manipulate the cel
            $cell->setValue('HABER');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        $sheet->cell("H$i", function ($cell) {
            // manipulate the cel
            $cell->setValue('SALDO');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        $i++;
        return $i;
    }

    public function setDetalles($sheet, $n, $cuentas, $fecha_desde, $fecha_hasta, $id_empresa)
    {
        //dd($fecha_desde);
        foreach ($cuentas as $cuenta) {

            $fi        = str_replace('/', '-', $fecha_desde);
            $ff        = str_replace('/', '-', $fecha_hasta);
            $fi        = date('Y-m-d', strtotime($fi));
            $ff        = date('Y-m-d', strtotime($ff));
            $registros = \Sis_medico\Ct_Asientos_Detalle::where('id_plan_cuenta', '=', $cuenta->id)
                ->join('ct_asientos_cabecera as c', 'c.id', 'ct_asientos_detalle.id_asiento_cabecera')
                ->join('plan_cuentas as p', 'p.id', 'ct_asientos_detalle.id_plan_cuenta')
                ->whereBetween('c.fecha_asiento', [$fi . ' 00:00:00', $ff . ' 23:59:59'])
                ->where('c.id_empresa', $id_empresa)
                ->orderBy('fecha_asiento', 'ASC')
                ->select('c.*', 'ct_asientos_detalle.*', 'p.nombre')
                ->get();

            $saldoanterior = \Sis_medico\Ct_Asientos_Detalle::where('id_plan_cuenta', '=', $cuenta->id)
                ->join('ct_asientos_cabecera as c', 'c.id', 'ct_asientos_detalle.id_asiento_cabecera')
                ->where('c.fecha_asiento', '<', $fi)
                ->where('c.id_empresa', $id_empresa)
                ->select(DB::raw('ifnull(SUM(debe-haber),0) as saldo'))
                ->first();
            // dd($registrols);

            $saldo   = 0;
            $bandera = 0;
            foreach ($registros as $value) {

                if (count($saldoanterior) > 0 and $bandera == 0) {
                    $n     = $this->cab_detalle_saldo($sheet, $n, $value->id_plan_cuenta, $value->nombre, "Saldo Anterior $fecha_desde ", $saldoanterior->saldo);
                    $saldo = $saldoanterior->saldo;
                }

                $sheet->cell("A$n", function ($cell) use ($value) {
                    // manipulate the cel
                    $cell->setValue($value->fecha_asiento);
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                // $sheet->mergeCells('B5:E5');
                $sheet->cell("B$n", function ($cell) use ($value) {
                    // manipulate the cel
                    $cell->setValue($value->cabecera->id);
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell("C$n", function ($cell) use ($value) {
                    // manipulate the cel
                    $cell->setValue($value->id_plan_cuenta);
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell("D$n", function ($cell) use ($value) {
                    // manipulate the cel
                    $cell->setValue($value->nombre);
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell("E$n", function ($cell) use ($value) {
                    // manipulate the cel
                    $cell->setValue("$value->observacion");
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell("F$n", function ($cell) use ($value) {
                    // manipulate the cel
                    $cell->setValue($value->debe);
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell("G$n", function ($cell) use ($value) {
                    // manipulate the cel
                    $cell->setValue($value->haber);
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $saldo = ($saldo + $value->debe) - $value->haber;

                $sheet->cell("H$n", function ($cell) use ($saldo) {
                    // manipulate the cel
                    $cell->setValue($saldo);
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $n++;
                $bandera = 1;
            }
            if (count($registros) > 0) {
                // $n     = $this->cab_detalle($sheet, $n);
                $n = $this->cab_detalle_saldo($sheet, $n, $value->id_plan_cuenta, $value->nombre, "Saldo de $fecha_desde a $fecha_hasta", $saldo);
            }
        }
    }

    public function cab_detalle_saldo($sheet, $i, $cuenta, $nomcuenta, $detalle, $saldo)
    {
        $sheet->mergeCells("A$i:B$i");
        $sheet->cell("A$i:B$i", function ($cell) {
            // manipulate the cel
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        $sheet->cell("C$i", function ($cell) use ($cuenta) {
            // manipulate the cel
            $cell->setValue($cuenta);
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        $sheet->cell("D$i", function ($cell) use ($nomcuenta) {
            // manipulate the cel
            $cell->setValue($nomcuenta);
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        $sheet->cell("E$i", function ($cell) use ($detalle) {
            // manipulate the cel
            $cell->setValue($detalle);
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        $sheet->mergeCells("F$i:G$i");
        $sheet->cell("F$i:G$i", function ($cell) {
            // manipulate the cel
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        $sheet->cell("H$i", function ($cell) use ($saldo) {
            // manipulate the cel
            $cell->setValue($saldo);
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        $i++;
        return $i;
    }

    public function buscador_secuencia(Request $request)
    {
        //dd($request['nombre']);
        if (($request['nombre']) != "") {

            $id_empresa = $request->session()->get('id_empresa');
            $registros  = Ct_Asientos_Cabecera::where('id_empresa', $id_empresa)->where('fact_numero', $request['nombre'])->get();
            //dd($registros);
            return view('contable/diario/resultados_tabla', ['registros' => $registros]);
        }

        return 'no datos';
    }

    public function buscar_proveedor(Request $request)
    {
        if (!is_null($request['id_proveedor'])) {
            $proveedor  = $request['id_proveedor'];
            $id_empresa = $request->session()->get('id_empresa');
            $registros  = DB::table('ct_asientos_detalle as a')
                ->join('ct_asientos_cabecera as c', 'c.id', 'a.id_asiento_cabecera')
                ->join('ct_compras as co', 'co.id', 'c.id_ct_compras')
                ->join('proveedor as p', 'p.id', 'co.proveedor')
                ->where('a.id_empresa', $id_empresa)
                ->where('p.nombrecomercial', $proveedor)
                ->select('c.*')->orderby('id', 'desc')
                ->get();
            if ($registros != '[]') {
                return view('contable/diario/resultados_tabla', ['registros' => $registros]);
            } else {
                return ['value' => 'no resultados'];
            }
        } elseif (isset($request['concepto'])) {
            $concepto   = '%' . $request['concepto'] . '%';
            $id_empresa = $request->session()->get('id_empresa');
            $registros  = Ct_Asientos_Cabecera::where('id_empresa', $id_empresa)
                ->where('observacion', 'like', $concepto)->orderby('id', 'desc')
                ->get();
            if ($registros != '[]') {
                return view('contable/diario/resultados_tabla', ['registros' => $registros]);
            } else {
                return ['value' => 'no resultados'];
            }
        }
        return ['value' => 'no resultados'];
    }

    public function buscador_fecha(Request $request)
    {
        $fecha       = $request['fechaini'];
        $fecha_hasta = $request['fecha_hasta'];
        if ($fecha != "" && $fecha_hasta != "") {
            $registros = Ct_Asientos_Cabecera::whereBetween('fecha_asiento', [$fecha . ' 00:00:00', $fecha_hasta . ' 23:59:59'])->paginate(20);
            return view('contable/diario/resultados_tabla', ['registros' => $registros]);
        }
        return 'no data';
    }

    public function buscar_cuenta_diario(Request $request)
    {
        $cuenta = plan_cuentas::find($request['nombre']);
        return view('contable/libro_mayor/unico', ['cuenta' => $cuenta, 'contador' => $request['contador']]);
    }

    public function anular_asiento($id, Request $request)
    {
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $asiento    = Ct_Asientos_Cabecera::findorfail($id);
        //dd($asiento);
        $asiento->estado        = 1;
        $asiento->id_usuariomod = $idusuario;
        $asiento->save();
        $detalles       = $asiento->detalles;
        $concepto       = $request['concepto'];
        $estado_compras = Ct_Asientos_Cabecera::where('id', $id)->first();
        if (!is_null($estado_compras)) {
            $id_asiento = Ct_Asientos_Cabecera::insertGetId([
                'observacion'     => 'ANULACION ' . $asiento->observacion,
                'fecha_asiento'   => $asiento->fecha_asiento,
                'valor'           => $asiento->valor,
                'id_empresa'      => $asiento->id_empresa,
                'aparece_sri'     => $asiento->aparece_sri,
                'ip_creacion'     => $ip_cliente,
                'ip_modificacion' => $ip_cliente,
                'id_usuariocrea'  => $idusuario,
                'id_usuariomod'   => $idusuario,
            ]);
            foreach ($detalles as $value) {
                $value->estado = 1;
                $value->save();
                Ct_Asientos_Detalle::create([
                    'id_asiento_cabecera' => $id_asiento,
                    'id_plan_cuenta'      => $value->id_plan_cuenta,
                    'debe'                => $value->haber,
                    'haber'               => $value->debe,
                    'descripcion'         => $value->descripcion,
                    'fecha'               => $asiento->fecha_asiento,
                    'ip_creacion'         => $ip_cliente,
                    'ip_modificacion'     => $ip_cliente,
                    'id_usuariocrea'      => $idusuario,
                    'id_usuariomod'       => $idusuario,
                ]);
            }
        }
        return "ok";
    }
    public function checkpass(Request $request)
    {
        $hashedPassword = Auth::user()->password;
        $ingresada      = $request['userpass'];
        if (Hash::check($ingresada, $hashedPassword)) {
            return 'ok';
        } else {
            return 'error';
        }
    }
    public function buscar_asiento(Request $request)
    {
        if (!is_null($request['id_asiento']) && !is_null($request['validacion'])) {
            switch ($request['validacion']) {
                case '9':
                    $ingresos   = Ct_Comprobante_Ingreso_Varios::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento = $ingresos->id_asiento_cabecera;
                    $id_d       = [$id_asiento, $ingresos->secuencia];
                    return $id_d;
                    break;
                case '8':
                    $ingresos   = Ct_Comprobante_Ingreso::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento = $ingresos->id_asiento_cabecera;
                    $id_d       = [$id_asiento, $ingresos->secuencia];
                    return $id_d;
                    break;
                case '10':
                    $nota_debito = Ct_Nota_Debito_Cliente::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento  = $nota_debito->id_asiento_cabecera;
                    $id_d        = [$id_asiento, $nota_debito->secuencia];
                    return $id_d;
                    break;
                case '7':
                    $comprobante_egreso = Ct_Comprobante_Egreso::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento         = $comprobante_egreso->id_asiento_cabecera;
                    $id_d               = [$id_asiento, $comprobante_egreso->secuencia];
                    return $id_d;
                    break;
                case '6':
                    $comprobante_egreso_varios = Ct_Comprobante_Egreso_Varios::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento                = $comprobante_egreso_varios->id_asiento_cabecera;
                    $id_d                      = [$id_asiento, $comprobante_egreso_varios->secuencia];
                    return $id_d;
                    break;
                case '5':
                    $nota_debito = Ct_Debito_Acreedores::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento  = $nota_debito->id_asiento_cabecera;
                    $id_d        = [$id_asiento, $nota_debito->secuencia];
                    return $id_d;
                    break;
                case '4':
                    $nota_debito = Ct_Credito_Acreedores::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento  = $nota_debito->id_asiento_cabecera;
                    $id_d        = [$id_asiento, $nota_debito->secuencia];
                    return $id_d;
                    break;
                case '3':
                    $nota_debito = Ct_Cruce_Valores_Cliente::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento  = $nota_debito->id_asiento_cabecera;
                    $id_d        = [$id_asiento, $nota_debito->secuencia];
                    return $id_d;
                    break;
                case '2':
                    $nota_debito = Ct_Cruce_Valores::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento  = $nota_debito->id_asiento_cabecera;
                    $id_d        = [$id_asiento, $nota_debito->secuencia];
                    return $id_d;
                    break;
                case '1':
                    $nota_debito = Ct_Nota_Debito_Cliente::where('estado', '1')->where('id', $request['id_asiento'])->first();
                    $id_asiento  = $nota_debito->id_asiento_cabecera;
                    $id_d        = [$id_asiento, $nota_debito->secuencia];
                    return $id_d;
                    break;
            }
        } else {
            return "error faltan campos vacios";
        }
    }
    public function modal_estado(Request $request, $id)
    {

        if (!is_null($request['fecha']) && !is_null($request['fecha_hasta'])) {
            $fecha       = $request['fecha'];
            $fecha_hasta = $request['fecha_hasta'];
        } else {
            $fecha       = date('Y-m-d');
            $fecha_hasta = date('Y-m-d');
        }
        $id_empresa = $request->session()->get('id_empresa');
        $empresa    = Empresa::where('id', $id_empresa)->where('estado', '1')->first();
        $compras    = DB::table('ct_compras as ct_c')
            ->leftjoin('proveedor as p', 'p.id', 'ct_c.proveedor')
            ->join('users as u', 'u.id', 'ct_c.id_usuariocrea')
            ->where('ct_c.estado', '1')
            ->select('ct_c.id', 'ct_c.numero', 'ct_c.fecha', 'p.nombrecomercial', 'ct_c.autorizacion', 'u.nombre1', 'u.apellido1', 'ct_c.secuencia_factura', 'ct_c.tipo_comprobante', 'ct_c.estado', 'ct_c.observacion', 'ct_c.id_asiento_cabecera')
            ->where('ct_c.id_empresa', $id_empresa)
            ->where('ct_c.tipo', 1)
            ->orderby('ct_c.id', 'desc')
            ->paginate(10);
        $registro = Ct_Asientos_Cabecera::findorfail($id);
        $detalle  = Ct_Asientos_Detalle::where('id_asiento_cabecera', $id)
            ->groupBy('id_plan_cuenta')
            ->select('id_plan_cuenta', 'descripcion')
            ->select(DB::raw('id_plan_cuenta, descripcion, SUM(debe) as debe, SUM(haber) as haber'))
            ->get();
        //dd($compras);

        //dd($edit->estado_uso);
        return view('contable/compra/modal_estado', ['compras' => $compras, 'id_empresa' => $empresa, 'registro' => $registro, 'fecha' => $fecha, 'fecha_hasta' => $fecha_hasta, 'detalle' => $detalle]);
    }
    public function cierre(Request $request)
    {
        $id_empresa = $request->session()->get('id_empresa');
        $empresa    = Empresa::find($id_empresa);
        $end        = date('Y', strtotime('-1 years'));
        //dd($end);
        $detalle = DB::table('plan_cuentas as p')->join('ct_asientos_detalle as detalle', 'detalle.id_plan_cuenta', 'p.id')->join('ct_asientos_cabecera as cabecera', 'cabecera.id', 'detalle.id_asiento_cabecera')->whereYear('detalle.fecha', $end)->whereRaw('((p.descripcion LIKE "%Gasto%") OR (p.descripcion LIKE "%Ingreso%"))')->groupBy('detalle.id_plan_cuenta')->select(DB::raw('SUM(detalle.debe) - SUM(detalle.haber) as d'), DB::raw('SUM(detalle.haber) as haber'), DB::raw('SUM(detalle.debe) as debe'), 'p.nombre', 'p.id', 'p.naturaleza as tipo', 'cabecera.id_empresa', 'p.descripcion')->where('cabecera.id_empresa', $id_empresa)->get();
        //dd(json_encode($detalle));
        //dd($detalle);
        $cuentas = Plan_Cuentas::all();
        //return response()->json($detalle);
        return view('contable/diario/fin', ['empresa' => $empresa, 'detalle' => $detalle, 'cuentas' => $cuentas]);
        //return response()->json($queryFin);
    }
}
