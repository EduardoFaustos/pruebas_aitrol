<?php

namespace Sis_medico\Http\Controllers\contable;

use Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Response;
use Session;
use Sis_medico\Ct_Configuraciones;
use Sis_medico\Empresa;
use Sis_medico\Http\Controllers\Controller;
use Sis_medico\Plan_Cuentas;

class Plan_CuentasController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    private function rol()
    {
        $rolUsuario = Auth::user()->id_tipo_usuario;
        $id_auth    = Auth::user()->id;
        if (in_array($rolUsuario, array(1, 4, 5, 20, 22)) == false) {
            return true;
        }
    }

    public function configuracion()
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $agenda        = Ct_Configuraciones::where('id', 1)->orwhere('id', 2)->orwhere('id', 27)->get();
        $configuracion = Ct_Configuraciones::where('id', '!=', 1)->orwhere('id', '!=', 2)->orwhere('id', '!=', 27)->get();
        return view('contable/configuracion/index', ['configuracion' => $configuracion, 'agenda' => $agenda]);
    }

    public function editar_configuracion($id)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $cuentas       = plan_cuentas::where('estado', '2')->get();
        $configuracion = Ct_Configuraciones::findorfail($id);
        return view('contable/configuracion/edit', ['configuracion' => $configuracion, 'cuentas' => $cuentas]);
    }

    public function guardar_configuracion(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;

        $input = [
            'id_plan'         => $request['id_plan'],
            'iva'             => $request['iva'],
            'ip_modificacion' => $ip_cliente,
            'id_usuariomod'   => $idusuario,
        ];
        Ct_Configuraciones::find($request['id'])->update($input);
        return redirect()->intended('/contable/configuraciones');
    }

    public function index()
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $principales = plan_cuentas::where('id', 'NOT LIKE', '%.%')->get();

        return view('contable/plan_cuentas/index', ['principales' => $principales]);
    }

    public function hijos($padre)
    {
        $padre    = plan_cuentas::find($padre);
        $devolver = "";
        if (count($padre->hijos()->get()) == 0) {
            $devolver = '<li>' . count($padre->hijos()->get()) . $padre->nombre . '</li>';
        } else {
            $hijos = $padre->hijos()->get();
            foreach ($hijos as $value) {
                if (count($value->hijos()->get()) == 0) {
                    $devolver = $devolver . '<li><a onclick="llamado(this)" id="' . $value->id . '">' . $value->nombre . '</a></li>';
                } else {
                    $devolver  = $devolver . '<li><a onclick="llamado(this)" id="' . $value->id . '" class="treeview"><i class="fa fa-plus elemento" aria-hidden="true"></i> <i class="fa fa-minus oculto elemento2" aria-hidden="true"></i> ' . $value->nombre . '</a><ul class="treeview-menu">';
                    $respuesta = $this->hijos($value->id);
                    $devolver  = $devolver . $respuesta;
                    $devolver  = $devolver . '</ul></li>';
                }
            }
        }
        return $devolver;

    }

    public function elementos(Request $request)
    {
        $id_plan = $request['id_plan'];
        $cuenta  = plan_cuentas::find($id_plan);
        $hijos   = $cuenta->hijos()->get();
        return view('contable/plan_cuentas/elementos', ['cuenta' => $hijos, 'general' => $cuenta]);
    }

    public function informacion(Request $request)
    {
        $id_plan = $request['id_plan'];
        $cuenta  = plan_cuentas::find($id_plan);
        return view('contable/plan_cuentas/informacion', ['cuenta' => $cuenta]);
    }

    public function guardar(Request $request)
    {
        $id           = $request['codigo'];
        $tipo         = $request['tipo'];
        $tipo2        = $request['tipo2'];
        $naturaleza   = $request['naturaleza'];
        $naturaleza_2 = $request['naturaleza_2'];
        $ip_cliente   = $_SERVER["REMOTE_ADDR"];
        $idusuario    = Auth::user()->id;
        if ($tipo2 == 3) {
            $input = [
                'nombre'          => $request['nombre'],
                'estado'          => $tipo,
                'naturaleza'      => $naturaleza,
                'naturaleza_2'    => $naturaleza_2,
                'ip_modificacion' => $ip_cliente,
                'id_usuariomod'   => $idusuario,
            ];
        } else {
            $input = [
                'nombre'          => '0',
                'estado'          => $tipo,
                'naturaleza'      => $naturaleza,
                'naturaleza_2'    => $naturaleza_2,
                'ip_modificacion' => $ip_cliente,
                'id_usuariomod'   => $idusuario,
            ];
        }
        plan_cuentas::find($id)->update($input);
        return "ok";
    }

    public function nuevo_padre($id)
    {
        $padre = plan_cuentas::find($id);
        return view('contable/plan_cuentas/modal_nuevo', ['padre' => $padre]);
    }

    public function guardar_nuevo(Request $request)
    {
        $id       = $request['id_padre'] . '.' . $request['id_cuenta'];
        $nombre   = $request['nombre'];
        $tipo     = $request['tipo'];
        $revision = plan_cuentas::find($id);
        if (!is_null($revision)) {
            return "El numero de plan de cuentas ya existe";
        }
        if (is_null($nombre)) {
            return "Ingrese el nombre del plan de cuentas";
        }
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        date_default_timezone_set('America/Guayaquil');
        $input = [

            'id'              => $id,
            'id_padre'        => $request['id_padre'],
            'nombre'          => $nombre,
            'estado'          => $tipo,
            'ip_creacion'     => $ip_cliente,
            'ip_modificacion' => $ip_cliente,
            'id_usuariocrea'  => $idusuario,
            'id_usuariomod'   => $idusuario,

        ];
        plan_cuentas::create($input);
        return "ok";
    }

    public function seleccion_empresa(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $rolUsuario = Auth::user()->id_tipo_usuario;
        if ($rolUsuario == 1) {
            $empresas = Empresa::all();
            $empresa  = Empresa::findorfail($request->session()->get('id_empresa'));
        } else {
            $id_usuario = Auth::user()->id;
            $empresas   = Empresa::join('usuario_empresa', 'empresa.id', '=', 'usuario_empresa.id_empresa')
                ->where('id_usuario', $id_usuario)->select('empresa.*')->get();
            $empresa = Empresa::findorfail($request->session()->get('id_empresa'));
            if (count($empresas) < 1) {
                $empresa  = Empresa::where('prioridad', '1')->first();
                $empresas = Empresa::where('id', $empresa->id)->get();
            }
        }

        return view('contable/plan_cuentas/seleccion_empresa', ['empresas' => $empresas, 'request' => $request, 'empresa' => $empresa]);
    }

    public function guardar_empresa(Request $request)
    {
        $empresa = Empresa::findorfail($request['id_empresa']);
        $request->session()->put('id_empresa', $request['id_empresa']);
        return back();

    }

    public function exportar()
    {
        // dd("Exportar");
        $id_empresa = Session::get('id_empresa');
        $empresa    = Empresa::where('id', $id_empresa)->where('estado', '1')->first();
        $plan       = array();
        $plan       = Plan_Cuentas::where('estado', '<>', 0)
        // ->where('id', 'like', "$condicion%")
            ->select('id', 'nombre', 'naturaleza', 'naturaleza_2')
            ->orderBy('id', 'asc')
            ->get();
        Excel::create('PlanCuentas', function ($excel) use ($empresa, $plan) {
            $excel->sheet('EstadoSituacionFinanciera', function ($sheet) use ($empresa, $plan) {
                // dd($participacion);
                $sheet->mergeCells('A1:G1');
                $sheet->cell('A1', function ($cell) use ($empresa) {
                    // manipulate the cel
                    $cell->setValue($empresa->nombrecomercial);
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('15');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', '', 'thin');
                });
                $sheet->mergeCells('A2:G2');
                $sheet->cell('A2', function ($cell) {
                    // manipulate the cel
                    $cell->setValue("PLAN DE CUENTAS");
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('15');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('A3:G3');
                $sheet->cell('A3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue("");
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                //$sheet->mergeCells('A4:A5');
                $sheet->cell('A4', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('CUENTA');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('B4:G4');
                $sheet->cell('B4', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('NOMBRE');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');

                });
                // DETALLES

                $i = $this->setDetalles($plan, $sheet, 5);

                //  CONFIGURACION FINAL
                $sheet->cells('A2:G2', function ($cells) {
                    // manipulate the range of cells
                    $cells->setBackground('#0070C0');
                    // $cells->setFontSize('10');
                    $cells->setFontWeight('bold');
                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                    $cells->setValignment('center');
                });

                $sheet->cells('A4:G4', function ($cells) {
                    // manipulate the range of cells
                    $cells->setBackground('#cdcdcd');
                    $cells->setFontWeight('bold');
                    $cells->setFontSize('12');
                });

                $sheet->setWidth(array(
                    'A' => 12,
                    'B' => 12,
                    'C' => 12,
                    'D' => 12,
                    'E' => 12,
                    'F' => 12,
                    'G' => 12,
                ));

            });
        })->export('xlsx');
    }

    public function setDetalles($data, $sheet, $i, $totpyg = "", $participacion = "")
    {
        foreach ($data as $value) {

            $cont = substr_count($value['id'], ".");
            // if ($cont == 0) {$valor100 = $value['saldo'];}

            $sheet->cell('A' . $i, function ($cell) use ($value, $cont) {
                // manipulate the cel
                $cell->setValue(" " . $value['id'] . " ");
                $cell->setBorder('thin', 'thin', 'thin', 'thin');
                $this->setSangria($cont, $cell);
            });

            $sheet->mergeCells('B' . $i . ':G' . $i);
            $sheet->cell('B' . $i, function ($cell) use ($value, $cont) {
                // manipulate the cel

                $cell->setValue($value['nombre']);
                $cell->setBorder('thin', 'thin', 'thin', 'thin');
                $this->setSangria($cont, $cell, 1);
            });

            $i++;
        }
        $sheet->getStyle('A' . $i)->getAlignment()->setWrapText(true);
        return $i;
    }

    public function setSangria($cont, $cell, $indent = "")
    {
        switch ($cont) {
            case 0:
                $cell->setFontSize('12');
                $cell->setFontWeight('bold');
                break;
            case 1:
                $cell->setFontSize('11');
                $cell->setFontWeight('bold');
                if ($indent != "") {
                    $cell->setTextIndent(1);
                }
                break;
            case 2:
                $cell->setFontSize('10');
                $cell->setFontWeight('bold');
                if ($indent != "") {
                    $cell->setTextIndent(2);
                }
                break;
            case 3:
                $cell->setFontSize('10');
                $cell->setFontWeight('bold');
                if ($indent != "") {
                    $cell->setTextIndent(3);
                }
                break;
            case 4:
                $cell->setFontSize('10');
                // $cell->setFontWeight('bold');
                if ($indent != "") {
                    $cell->setTextIndent(4);
                }
                break;
            default:
                $cell->setFontSize('10');
                // $cell->setFontWeight('bold');
                if ($indent != "") {
                    $cell->setTextIndent(5);
                }
                break;
        }
    }
}
