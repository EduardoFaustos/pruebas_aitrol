<?php

namespace Sis_medico\Http\Controllers\contable;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Response;
use Sis_medico\Ct_productos;
use Sis_medico\Ct_Productos_Tarifario;
use Sis_medico\Ct_Producto_Tarifario_Paquete;
use Sis_medico\Http\Controllers\Controller;
use Sis_medico\Seguro;
use Sis_medico\User;
use Sis_medico\Empresa;
use Sis_medico\Equipo;
use Sis_medico\Plan_Cuentas;
use Sis_medico\Proveedor;
use Sis_medico\Ct_Acreedores;
use Sis_medico\Marca;
use Sis_medico\Producto;
use Sis_medico\Ct_configuraciones_pdf;

class ProductosController extends Controller
{
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    private function rol()
    {
        $rolUsuario = Auth::user()->id_tipo_usuario;
        if (in_array($rolUsuario, array(1,22)) == false) {
            return true;
        }
    }

    public function productos_tarifario()
    {
        $seguros   = Ct_Productos_Tarifario::groupby('id_producto')->get();
        $seg       = Ct_Productos_Tarifario::orderby('id_seguro')->orderby('nivel')->groupBy(DB::raw('id_seguro, nivel'))->get();
        $productos = Ct_productos::where('estado_tabla', '1')->paginate(20);
        //dd($seg);

        return view('contable/productos_tarifario/index', ['seguros' => $seguros, 'seg' => $seg, 'productos' => $productos, 'nombre' => '']);
    }

    public function crear()
    {
        $seguros   = Seguro::where('inactivo', '1')->orderBy('nombre')->get();
        $productos = Ct_productos::where('estado_tabla', '1')->get();

        return view('contable/productos_tarifario/create', ['seguros' => $seguros, 'productos' => $productos]);
    }

    public function configuraciones_pdf(Request $request)
    {

        $empresas  = Empresa::all();
        $id_empresa = $request->session()->get('id_empresa');
        $nombre_empresa = Empresa::where('id', $id_empresa)->first();
        $empresa = Empresa::where('id', $id_empresa)->first();
        //dd($nombre_empresa);
        return view('contable/configuracion_pdf/create', ['empresas' => $empresas, 'id_empresa' => $id_empresa, 'nombre_empresa' => $nombre_empresa,'empresa'=>$empresa]);
    }
    public function guardar_confi(Request $request)
    {
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $obj = [
            'fech_autorizacion'       => $request['fecha'],
            'id_empresa'           => $request['empresa'],
            'detalle'     => $request['detalle'],
            'autorizacion' =>$request['autorizacion'],
            'estado' =>$request['estado'],
            'id_usuariocrea'  => $idusuario,
            'id_usuariomod'   => $idusuario,
            'ip_creacion'     => $ip_cliente,
            'ip_modificacion' => $ip_cliente,
        ];
        //dd($obj);
        Ct_configuraciones_pdf::create($obj);
        return redirect()->route('configuraciones_pdf_index');;
    }
    public function editar_pdf($id, Request $request)
    {

        $edit = Ct_configuraciones_pdf::find($id);
        $nombre = Empresa::where('id',$edit->id_empresa)->first();
        $id_empresa = $request->session()->get('id_empresa');
        $empresa = Empresa::where('id', $id_empresa)->first();
        return view('contable/configuracion_pdf/edit',['edit'=>$edit,'nombre'=>$nombre,'empresa'=>$empresa]);
    }

    public function actualizar_pdf(Request $request){

        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        date_default_timezone_set('America/Guayaquil');
        $id = $request['id'];
        $tipo_ambiente = Ct_configuraciones_pdf::findOrFail($id);
        
        $input = [

            'fech_autorizacion'       => $request['fecha'],
            'detalle'     => $request['detalle'],
            'autorizacion' =>$request['autorizacion'],
            'estado' =>$request['estado'],
            'id_usuariocrea'  => $idusuario,
            'id_usuariomod'   => $idusuario,
            'ip_creacion'     => $ip_cliente,
            'ip_modificacion' => $ip_cliente,

        ]; 


        $tipo_ambiente->update($input); 
        
        return redirect()->route('configuraciones_pdf_index');;
    }

    public function index_confi(Request $request)
    {

        $empresas  = Empresa::all();
        $id_empresa = $request->session()->get('id_empresa');
        $empresa = Empresa::where('id', $id_empresa)->first();
        $confi = Ct_configuraciones_pdf::where('id_empresa',$id_empresa)->paginate(5);
        return view('contable/configuracion_pdf/index', ['empresas' => $empresas, 'confi' => $confi,'empresa'=>$empresa]);
    }

    public function guardar(Request $request)
    {

        //return $request['id_producto'];
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $id_empresa = $request->session()->get('id_empresa');

        $id_paquete = $request['id_paq'];
 
        $existe_prod_tar = Ct_Productos_Tarifario::where('id_seguro',$request['id_seguro'])
                                                   ->where('nivel',$request['id_nivel'])
                                                   ->where('id_producto',$request['id_producto'])
                                                   ->where('estado','1')
                                                   ->first();

        if(!is_null($existe_prod_tar)){

            $msj =  "ok";
                                
            return ['msj' => $msj];
            
        }else{
        
            
            if($request['id_seguro'] == 1){

             
              Ct_productos::where('id',$request['id_producto'])->update(['valor_total_paq' => $request['precio']]);


              return "ok";

            }

            if($request['id_seguro'] != 1){

                $arr = [
                    'id_seguro'       => $request['id_seguro'],
                    'nivel'           => $request['id_nivel'],
                    'id_producto'     => $request['id_producto'],
                    'precio_producto' => $request['precio'],
                    'id_usuariocrea'  => $idusuario,
                    'id_usuariomod'   => $idusuario,
                    'ip_creacion'     => $ip_cliente,
                    'ip_modificacion' => $ip_cliente,
                ];
            
                $id_prod_tar = Ct_Productos_Tarifario::insertGetId($arr);

                return "ok";

            }

        }

        //Insertamos data a la tabla ct_producto_tarifario_paquete
        /*$input = [
            
            'id_producto_tarifario'  => $id_prod_tar,
            'id_paquete'             => $id_paquete,
            'id_usuariocrea'         => $idusuario,
            'id_usuariomod'          => $idusuario,
            'ip_creacion'            => $ip_cliente,
            'ip_modificacion'        => $ip_cliente,
        ];*/

        //Ct_Producto_Tarifario_Paquete::create($input);

        
    }

    //GUARDA TARIFARIO PAQUETE
    public function guardar_tarifario_paquete(Request $request)
    {
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;

        $id_prod_paq = $request['id_prod_paq'];

        $existe_prod_tar_paq = Ct_Producto_Tarifario_Paquete::where('id_seguro',$request['id_seguro'])
        ->where('id_nivel',$request['id_nivel'])
        ->where('id_producto',$request['id_prod'])
        ->where('id_paquete',$request['id_paq'])
        ->where('estado','1')
        ->first();

        if(!is_null($existe_prod_tar_paq)){

            $msj =  "ok";
                                
            return ['msj' => $msj];
            
        }else{
        
            $input = [
                
                'id_producto_paquete'   => $id_prod_paq,
                'id_producto'           => $request['id_prod'],
                'id_paquete'           => $request['id_paq'],
                'id_seguro'             => $request['id_seguro'],
                'id_nivel'              => $request['id_nivel'],
                'cantidad'              => $request['cantidad'],
                'precio'                => $request['precio'],
                'id_usuariocrea'        => $idusuario,
                'id_usuariomod'         => $idusuario,
                'ip_creacion'           => $ip_cliente,
                'ip_modificacion'       => $ip_cliente,
            ];

            Ct_Producto_Tarifario_Paquete::create($input);
            
            return "ok";

        }

    }


    public function edit($id_producto)
    {
     
        $prod_tari = Ct_Productos_Tarifario::where('id_producto', $id_producto)->where('estado', '1')->join('ct_productos as prod', 'prod.id', 'ct_producto_tarifario.id_producto')->select('prod.nombre', 'ct_producto_tarifario.id_producto', 'prod.codigo', 'prod.id as id_producto', 'ct_producto_tarifario.id_seguro', 'ct_producto_tarifario.precio_producto', 'ct_producto_tarifario.nivel')->get();
        //dd($prod_tari);

        $seguros = Seguro::where('inactivo', '1')->orderBy('nombre')->get();

        return view('contable/productos_tarifario/edit', ['seguros' => $seguros, 'prod_tari' => $prod_tari]);
    }

    public function nivel(Request $request)
    {

        //dd($request->id_seguro);
        $id_empresa = $request->session()->get('id_empresa');
        
        $convenios = DB::table('convenio as c')
                     ->where('c.id_seguro', $request->id_seguro)
                     //->where('c.id_empresa',$id_empresa)
                     ->join('nivel as n', 'n.id', 'c.id_nivel')
                     ->select('c.*', 'n.nombre', 'n.id as id_nivel')
                     ->get();

        //dd($convenios);

        return view('contable/productos_tarifario/niveles', ['convenios' => $convenios]);
    }

    public function precios(Request $request)
    {
        $producto = Ct_productos::where('id', $request->id_producto)->first();

        $precio_prod = DB::table('precio_producto as pre_pro')->where('pre_pro.codigo_producto', $producto->codigo)->get();

        return view('contable/productos_tarifario/precios', ['precio_prod' => $precio_prod]);
    }

    public function update(Request $request, $id_producto)
    {
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;

        $prod_tari = Ct_Productos_Tarifario::where('id_producto', $id_producto)->where('id_seguro', $request->id_seguro);
        $arr = [
            'id_seguro'       => $request['id_seguro'],
            'nivel'           => $request['id_nivel'],
            'id_producto'     => $id_producto,
            'precio_producto' => $request['precio'],
            'id_usuariocrea'  => $idusuario,
            'id_usuariomod'   => $idusuario,
            'ip_creacion'     => $ip_cliente,
            'ip_modificacion' => $ip_cliente,
        ];

        $prod_tari->update($arr);

        return "ok";
    }

    public function edit2($id_producto, $id_seguro)
    {
        //dd($prod_tari);
        $productos = Ct_productos::where('id', $id_producto)->where('estado_tabla', '1')->get();
        $seguros = Seguro::where('id', $id_seguro)->where('inactivo', '1')->orderBy('nombre')->get();

        return view('contable/productos_tarifario/edit2', ['seguros' => $seguros, 'productos' => $productos]);
    }

    public function buscar(Request $request)
    {
        $id_empresa = $request->session()->get('id_empresa');
        $empresa    = Empresa::where('id', $id_empresa)->where('estado', '1')->first();

        $nombre = $request['nombre'];
        $productos = Ct_productos::where('nombre', 'like', '%' . $nombre . '%')->where('estado_tabla', '1')->paginate(20);
        $seg = Ct_Productos_Tarifario::orderby('id_seguro')->orderby('nivel')->groupBy(DB::raw('id_seguro, nivel'))->get();

        return view('contable/productos_tarifario/index', ['nombre' => $nombre, 'productos' => $productos, 'seg' => $seg]);
    }


    //Buscar Codigo Producto
    public function buscar_codigo_producto(Request $request){

        $existe = Ct_productos::where('codigo', $request['cod_prod'])
                    ->where('estado_tabla','1')->first();

        if(!is_null($existe)){

          $dato = ['existe'=> $existe];
        
          return $dato;
        }

    }


}
