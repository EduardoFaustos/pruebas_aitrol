<?php

namespace Sis_medico\Http\Controllers\contable;

use Sis_medico\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Sis_medico\Ct_Tipo_Pago;
use Sis_medico\Ct_Asientos_Cabecera;
use PHPExcel_Worksheet_Drawing;
use Sis_medico\Ct_Asientos_Detalle;
use Sis_medico\Ct_master_tipos;
use Sis_medico\Ct_Configuraciones;
use Sis_medico\Bodega;
use Sis_medico\Empresa;
use Sis_medico\Log_usuario;
use Sis_medico\Ct_Clientes;
use Sis_medico\Marca;
use Sis_medico\Ct_Nota_Credito_Clientes;
use Sis_medico\Ct_Detalle_Rubro_Credito;
use Sis_medico\Ct_Detalle_Credito_Clientes;
use Sis_medico\Ct_Rubros_Cliente;
use Sis_medico\Plan_Cuentas;
use Sis_medico\Validate_Decimals;
use Sis_medico\Ct_ventas;
use Sis_medico\Ct_Sucursales;
use Sis_medico\Ct_Caja;
use Sis_medico\Numeros_Letras;
use Sis_medico\Ct_Comprobante_Ingreso;
use Excel;
use laravel\laravel;
use Carbon\Carbon;
use Sis_medico\Ct_detalle_venta;
use Sis_medico\Ct_Devolucion_Productos;
use Sis_medico\Http\Controllers\ApiFacturacionController;
use Sis_medico\Http\Requests\Request as RequestsRequest;

class NotaCreditoClienteController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    private function rol()
    {
        $rolUsuario = Auth::user()->id_tipo_usuario;
        $id_auth    = Auth::user()->id;
        if (in_array($rolUsuario, array(1, 4, 5, 20, 22)) == false) {
            return true;
        }
    }

    /************************************************************/
    /****************INDEX NOTA DE CREDITO CLIENTE***************
    /***********************************************************/
    public function index(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }

        $id_empresa = $request->session()->get('id_empresa');
        $empresa = Empresa::where('id', $id_empresa)->first();
        $clientes = Ct_Clientes::where('estado', '1')->get();
        $nota_credito = Ct_Nota_Credito_Clientes::where('estado', '=', 1)->where('id_empresa', $id_empresa)->orderBy('id', 'desc')->paginate(10);
        return view('contable/nota_credito_cliente/index', ['nota_credito' => $nota_credito, 'clientes' => $clientes, 'empresa' => $empresa]);
    }
    public function create(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $id_empresa = $request->session()->get('id_empresa');
        $empresa = Empresa::where('id', $id_empresa)->first();
        $iva_param = Ct_Configuraciones::where('id_plan', '4.1.01.02')->first();
        $sucursales = Ct_Sucursales::where('estado', 1)->where('id_empresa', $id_empresa)->get();
        return view('contable/nota_credito_cliente/create', ['iva_param' => $iva_param, 'empresa' => $empresa, 'sucursales' => $sucursales]);
    }


    /************************************************************/
    /***********BUSQUEDA DE CLIENTE POR IDENTIFICACION***********
    /***********************************************************/
    public function buscarClientexId(Request $request)
    {
        $nombre = $request['term'];
        $data      = array();
        $id_empresa = $request->session()->get('id_empresa');
        $clientes = Ct_Clientes::where('identificacion', 'like', '%' . $nombre . '%')->get();
        foreach ($clientes as $cliente) {
            $data[] = array('value' => $cliente->identificacion, 'nombre' => $cliente->nombre, 'direccion' => $cliente->direccion_representante, 'ciudad' => $cliente->ciudad_representante, 'mail' => $cliente->email_representante, 'telefono' => $cliente->telefono1_representante, 'tipo' => $cliente->clase);
        }

        if (count($data) > 0) {
            return $data;
        } else {
            return ['value' => 'No se encontraron resultados', 'id' => ''];
        }
    }

    /************************************************************/
    /*************BUSQUEDA DE CLIENTE POR NOMBRE*****************
    /***********************************************************/
    public function buscarCliente(Request $request)
    {
        $nombre = $request['term'];
        $data      = array();

        $id_empresa = $request->session()->get('id_empresa');
        $clientes = Ct_Clientes::where('nombre', 'like', '%' . $nombre . '%')->get();
        foreach ($clientes as $cliente) {
            $data[] = array('value' => $cliente->nombre, 'id' => $cliente->identificacion, 'direccion' => $cliente->direccion_representante, 'ciudad' => $cliente->ciudad_representante, 'mail' => $cliente->email_representante, 'telefono' => $cliente->telefono1_representante, 'tipo' => $cliente->clase);
        }

        if (count($data) > 0) {
            return $data;
        } else {
            return ['value' => 'No se encontraron resultados', 'id' => ''];
        }
    }

    /************************************************************/
    /************ BUSQUEDA DE RUBRO DE CLIENTE POR CODIGO********
    /***********************************************************/
    public function search_rubro_codigo(Request $request)
    {

        $codigo_rubro = $request['term'];
        $data      = array();
        //$data = null;

        $rubros = DB::table('ct_rubros_cliente')->where('estado', '1')->where('codigo', 'like', '%' . $codigo_rubro . '%')->get();
        foreach ($rubros as $rubr) {
            $data[] = array('value' => $rubr->codigo);
        }
        if (count($data) > 0) {
            return $data;
        } else {
            return ['value' => 'No se encontraron resultados'];
        }
    }

    /************************************************************/
    /************GUARDADO DE NOTA DE CREDITO CLIENTE*************/
    /***********************************************************/
    public function store_nota_credito(Request $request)
    {

        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $id_empresa = $request->session()->get('id_empresa');
        $objeto_validar = new Validate_Decimals();
        $fecha_nota = $request['fecha_hoy'];
        $iva_param = Ct_Configuraciones::where('id_plan', '4.1.01.02')->first();
        $ivaf = $iva_param->iva;
        $num_fact_cancelar = $request['nro_factura'];
        $total = 0;
        $nuevo_saldo = 0;
        $total_final = $objeto_validar->set_round($request['total']);
        DB::beginTransaction();
        $msj = "no";
        try {
            $ventas = Ct_ventas::where('estado', '1')
                ->where('id_cliente', $request['id_cliente'])
                ->where('id_empresa', $id_empresa)
                ->where('nro_comprobante', $num_fact_cancelar)->first();
            if ($request['contador'] > 0) {
                /************************************************************/
                /******Validacion a Insertar Sucursales y Punto de Emision**/
                /***********************************************************/
                if ($request['sucursal'] != 0) {
                    $cod_sucurs = Ct_Sucursales::where('estado', '1')->where('id', $request['sucursal'])->first();
                    $c_sucursal = $cod_sucurs->codigo_sucursal;
                    $cod_caj = Ct_Caja::where('estado', '1')->where('id', $request['punto_emision'])->first();
                    $c_caja = $cod_caj->codigo_caja;
                    $nfactura = $this->obtener_numero_factura($id_empresa, $cod_sucurs->codigo_sucursal, $cod_caj->codigo_caja);
                    if (!is_null($request['secuencial'])) {
                        $nfactura = $request['secuencial'];
                    }
                    $num_comprobante  = $cod_sucurs->codigo_sucursal . '-' . $cod_caj->codigo_caja . '-' . $nfactura;
                } else {
                    $c_sucursal = 0;
                    $c_caja = 0;
                    $num_comprobante = 0;
                    $nfactura = 0;
                }

                /************************************************************/
                /****************Guardado Ct_Asientos_Cabecera***************/
                /***********************************************************/
                $input_cabecera = [
                    'observacion'       => $request['concepto'],
                    'fecha_asiento'     => $fecha_nota,
                    'fact_numero'       => $num_comprobante,
                    'valor'             => $total_final,
                    'id_empresa'        => $id_empresa,
                    'estado'            => '1',
                    'ip_creacion'       => $ip_cliente,
                    'ip_modificacion'   => $ip_cliente,
                    'id_usuariocrea'    => $idusuario,
                    'id_usuariomod'     => $idusuario,
                ];

                $id_asiento_cabecera = Ct_Asientos_Cabecera::insertGetId($input_cabecera);

                /************************************************************/
                /************Guardado Ct_Nota_Credito_Clientes***************/
                /***********************************************************/
                $input = [
                    'id_empresa'                    => $id_empresa,
                    'id_cliente'                    => $request['id_cliente'],
                    'check_sri'                     => $request['check_archivo_sri'],
                    'id_asiento_cabecera'           => $id_asiento_cabecera,
                    'sucursal'                      => $c_sucursal,
                    'punto_emision'                 => $c_caja,
                    'numero_factura'                => $request['nro_factura'],
                    'nro_comprobante'               => $num_comprobante,
                    'secuencia'                     => $nfactura,
                    'fecha'                         => $request['fecha_hoy'],
                    'tipo'                          => $request['tipo'],
                    'concepto'                      => $request['concepto'],
                    'subtotal'                      => $request['subtotal'],
                    'impuesto'                      => $request['impuesto'],
                    'sub_sin_imp'                   => $request['sub_sin_imp'],
                    'tar_iva_12'                    => $request['tar_iva_12'],
                    'total_credito'                 => $request['total'],
                    'total_deudas'                  => $request['total_deudas'],
                    'total_abonos'                  => $request['total_abonos'],
                    'total_nuevo_saldo'             => $request['total_nuevo_saldo'],
                    'observacion'                   => $request['observaciones'],
                    'electronica'                   => $request['electronica'],
                    'estado'                        => '1',
                    'ip_creacion'                   => $ip_cliente,
                    'ip_modificacion'               => $ip_cliente,
                    'id_usuariocrea'                => $idusuario,
                    'id_usuariomod'                 => $idusuario,
                ];

                $id_credito = Ct_Nota_Credito_Clientes::insertGetId($input);

                /************************************************************/
                /************Guardado Ct_Detalle_Rubro_Credito**************/
                /***********************************************************/
                $iva = 0;
                if ($request['impuesto'] > 0) {
                    $iva = 1;
                }
                $valor = 0;
                $primerarray = array();
                for ($i = 0; $i <= $request['contador']; $i++) {
                    if ($request['visibilidad' . $i] == '1') {
                        if (!is_null($request['codigo' . $i])) {
                            $valor += $request['valor' . $i];

                            if ($iva == 1) {
                                $ivasx = $valor * $ivaf;
                                $valor = $ivasx;
                            }

                            $consul_rub_client = Ct_Rubros_Cliente::where('codigo', $request['codigo' . $i])->first();
                            if (!is_null($consul_rub_client)) {

                                $segundoarray = [$consul_rub_client->haber, $request['valor' . $i]];
                                $key = array_search($consul_rub_client->haber, array_column($primerarray, '0'));

                                if ($key !== false) {
                                    $valor2 =  $primerarray[$key][1];
                                    $valor2 = $valor2 + $request['valor' . $i];
                                    $primerarray[$key][0] = $consul_rub_client->haber;
                                    $primerarray[$key][1] = $valor2;
                                } else {
                                    array_push($primerarray, $segundoarray);
                                }

                                Ct_Detalle_Rubro_Credito::create([
                                    'id_nt_cred_client' => $id_credito,
                                    'codigo'            => $request['codigo' . $i],
                                    'nombre_rubro'      => $request['rubro' . $i],
                                    'detalle'           => $request['detalle' . $i],
                                    'valor'             => $request['valor' . $i],
                                    'total_base'        => $request['total_base' . $i],
                                    'id_usuariocrea'    => $idusuario,
                                    'id_usuariomod'     => $idusuario,
                                    'ip_creacion'       => $ip_cliente,
                                    'ip_modificacion'   => $ip_cliente,
                                ]);
                            }
                        }
                    }
                }

                /*****************************************************************/
                /*****************Guardado de Asiento Detalle*********************/
                /*****************************************************************/

                $plan_nota_credito = Plan_Cuentas::where('id', '1.01.02.05.01')->first();

                Ct_Asientos_Detalle::create([
                    'id_asiento_cabecera'           => $id_asiento_cabecera,
                    'id_plan_cuenta'                => '1.01.02.05.01',
                    'descripcion'                   => $plan_nota_credito->nombre,
                    'fecha'                         => $fecha_nota,
                    'debe'                          => $request['total'],
                    'haber'                         => '0',
                    'estado'                        => '1',
                    'id_usuariocrea'                => $idusuario,
                    'id_usuariomod'                 => $idusuario,
                    'ip_creacion'                   => $ip_cliente,
                    'ip_modificacion'               => $ip_cliente,
                ]);


                for ($file = 0; $file < count($primerarray); $file++) {
                    $cuent_descrip = Plan_Cuentas::where('id', $primerarray[$file][0])->first();
                    $cuenta = $primerarray[$file][0];
                    $debe =  number_format($primerarray[$file][1], 2, '.', '');
                    $debes = 0;
                    if ($iva == 1) {
                        $debes = $debe * $ivaf;
                        $debe = $debe + $debes;
                    }
                    Ct_Asientos_Detalle::create([
                        'id_asiento_cabecera'           => $id_asiento_cabecera,
                        'id_plan_cuenta'                => $cuenta,
                        'descripcion'                   => $cuent_descrip->nombre,
                        'fecha'                         => $fecha_nota,
                        'haber'                         => $debe,
                        'debe'                          => '0',
                        'estado'                        => '1',
                        'id_usuariocrea'                => $idusuario,
                        'id_usuariomod'                 => $idusuario,
                        'ip_creacion'                   => $ip_cliente,
                        'ip_modificacion'               => $ip_cliente,
                    ]);
                }

                for ($i = 0; $i <= $request['contador_a']; $i++) {
                    if (!is_null($request['abono_a' . $i]) && $request['abono_a' . $i] > 0) {
                        $consulta_venta = null;
                        $input_comprobante = null;
                        if (!is_null($request['id_actualiza' . $i])) {
                            //dd($request['id_actualiza'.$i]);
                            $consulta_venta = Ct_Ventas::where('id', $request['id_actualiza' . $i])->where('estado', '<>', '0')->where('id_empresa', $id_empresa)->first();
                            if (!is_null($consulta_venta)) {
                                Ct_Detalle_Credito_Clientes::create([
                                    'id_not_cred'                    => $id_credito,
                                    'id_factura'                     => $consulta_venta->id,
                                    'fecha_emision'                  => $request['emision' . $i],
                                    'fecha_vence'                    => $request['vence' . $i],
                                    'tipo'                           => $request['tipo_a' . $i],
                                    'secuencia_factura'              => $request['numero' . $i],
                                    'concepto'                       => $request['observacion' . $i],
                                    'saldo'                          => $request['saldo_a' . $i],
                                    'abono'                          => $request['abono_a' . $i],
                                    'nuevo_saldo'                    => $request['nuevo_saldo' . $i],
                                    'estado'                         => '1',
                                    'ip_creacion'                    => $ip_cliente,
                                    'ip_modificacion'                => $ip_cliente,
                                    'id_usuariocrea'                 => $idusuario,
                                    'id_usuariomod'                  => $idusuario,
                                ]);
                            }
                        }
                    }
                    $consulta_venta = Ct_ventas::where('id', $request['id_actualiza' . $i])
                        ->where('id_empresa', $id_empresa)
                        ->where('estado', '<>', '0')
                        ->first();
                    //dd($consulta_venta);
                    if ($request['abono_a' . $i] > 0) {
                        if (!is_null($consulta_venta)) {
                            if ($request['abono_a' . $i] > ($consulta_venta->valor_contable)) {
                                $nuevo_saldo = $request['abono_a' . $i] - $consulta_venta->valor_contable;
                            } else {
                                $nuevo_saldo = $consulta_venta->valor_contable - $request['abono_a' . $i];
                            }

                            $nuevo_saldof = $objeto_validar->set_round($nuevo_saldo);
                            $input_actualiza = null;

                            if ($nuevo_saldof != 0) {
                                $input_actualiza = [
                                    'estado_pago'                   => '2', //Aun en pago
                                    'valor_contable'                => $nuevo_saldof,
                                    'ip_creacion'                   => $ip_cliente,
                                    'ip_modificacion'               => $ip_cliente,
                                    'id_usuariocrea'                => $idusuario,
                                    'id_usuariomod'                 => $idusuario,
                                ];
                            } else {
                                $input_actualiza = [
                                    'estado_pago'                   => '3', //Pagado 
                                    'valor_contable'                => $nuevo_saldof,
                                    'ip_creacion'                   => $ip_cliente,
                                    'ip_modificacion'               => $ip_cliente,
                                    'id_usuariocrea'                => $idusuario,
                                    'id_usuariomod'                 => $idusuario,
                                ];
                            }

                            $consulta_venta->update($input_actualiza);
                        }
                    }
                }

                $empresa = Empresa::find($id_empresa);
                $sri = "";
                if ($empresa->electronica == 1 && $request['electronica'] == 1) {
                    $sri = $this->getSRI($id_credito);
                }


                DB::commit();

                return $id_credito;
            } else {

                return 'false';
            }
        } catch (\Exception $e) {
            //if there is an error/exception in the above code before commit, it'll rollback
            DB::rollBack();
            return ['error' => $e->getMessage()];
        }
    }


    /***************************************************/
    /***OBTENEMOS SECUENCIA DE LA NOTA CREDITO CLIENTE**/
    /***************************************************/
    public function obtener_numero_factura($idempresa, $sucursal, $punto_emision)
    {

        $contador_ntc = Ct_Nota_Credito_Clientes::where('id_empresa', $idempresa)
            ->where('sucursal', $sucursal)
            ->where('punto_emision', $punto_emision)->get()->count();

        if ($contador_ntc == 0) {

            $num = '1';
            $numero_factura = str_pad($num, 9, "0", STR_PAD_LEFT);
            return  $numero_factura;
        } else {

            $max_id = Ct_Nota_Credito_Clientes::where('id_empresa', $idempresa)->where('sucursal', $sucursal)
                ->where('punto_emision', $punto_emision)->latest()->first();
            $max_id = intval($max_id->secuencia);

            if (($max_id >= 1) && ($max_id < 10)) {
                $nu = $max_id + 1;
                $numero_factura = str_pad($nu, 9, "0", STR_PAD_LEFT);
                return  $numero_factura;
            }

            if (($max_id >= 10) && ($max_id < 100)) {
                $nu = $max_id + 1;
                $numero_factura = str_pad($nu, 9, "0", STR_PAD_LEFT);
                return  $numero_factura;
            }

            if (($max_id >= 100) && ($max_id < 1000)) {
                $nu = $max_id + 1;
                $numero_factura = str_pad($nu, 9, "0", STR_PAD_LEFT);
                return  $numero_factura;
            }

            if ($max_id == 1000) {
                $numero_factura = $max_id;
                return  $numero_factura;
            }
        }
    }

    /************************************************************/
    /***************CREACION DE PDF NOTA CREDITO CLIENTE*********
    /***********************************************************/
    public function crear_pdf_nota_credito(Request $request, $id)
    {
        $id_empresa = $request->session()->get('id_empresa');
        $nota_cred = Ct_Nota_Credito_Clientes::where('id', $id)->first();
        //   dd($nota_cred->nro_autorizacion);
        $asiento_cabecera = null;
        $empresa = null;

        if (!is_null($nota_cred)) {

            $det_rub = Ct_Detalle_Rubro_Credito::where('estado', '1')->where('id_nt_cred_client', $nota_cred->id)->get();
            $empresa = Empresa::where('id', $nota_cred->id_empresa)->first();
            $cliente = Ct_Clientes::where('estado', '1')->where('identificacion', $nota_cred->id_cliente)->first();

            $detalle_credito = Ct_Detalle_Credito_Clientes::where('id_not_cred', $nota_cred->id)->get();
            $ventas = Ct_Ventas::where('estado', '1')->where('id', $detalle_credito[0]->id_factura)->where('id_empresa', $id_empresa)->first();
            $letras = new Numeros_Letras();
            $total_str = $letras->convertir(number_format($nota_cred->total_credito, 2, '.', ''), "DOLARES", "CTVS");

            $asiento_cabecera = Ct_Asientos_Cabecera::where('estado', '1')->where('id', $nota_cred->id_asiento_cabecera)->first();
        }

        $asiento_detalle = null;

        if ($asiento_cabecera != null) {
            $asiento_detalle = Ct_Asientos_Detalle::where('estado', '1')->where('id_asiento_cabecera', $asiento_cabecera->id)->get();
        }

        //if (!is_null($nota_cred)){

        $vistaurl = "contable.nota_credito_cliente.pdf_nota_credito2";
        $view     = \View::make($vistaurl, compact('nota_cred', 'empresa', 'total_str', 'asiento_cabecera', 'asiento_detalle', 'cliente', 'ventas', 'det_rub'))->render();
        $pdf      = \App::make('dompdf.wrapper');
        $pdf->loadHTML($view);
        $pdf->setOptions(['dpi' => 150, 'isPhpEnabled' => true]);
        $pdf->setPaper('A4', 'landscape');
        return $pdf->stream('Nota de Crédito Clientes' . $id . '.pdf');
        //}

        //return 'error';

    }

    /************************************************************/
    /*****************BUZQUEDA DE FACTURAS DE VENTAS*************
    /***********************************************************/
    public function obtener_num_fact(Request $request)
    {

        $num = $request['term'];
        $data      = array();

        $id_empresa = $request->session()->get('id_empresa');

        $fact_venta = Ct_Ventas::where('nro_comprobante', 'like', '%' . $num . '%')
            ->where('estado', '1')
            ->where('valor_contable', '>', '0')
            ->where('id_empresa', $id_empresa)
            ->get();


        foreach ($fact_venta as $fact_venta) {
            $data[] = array('value' => $fact_venta->nro_comprobante, 'num_asiento' => $fact_venta->id_asiento, 'cliente' => $fact_venta->id_cliente, 'nomb_client' => $fact_venta->cliente->nombre);
        }

        //dd($fact_venta);

        if (count($data) > 0) {
            return $data;
        } else {
            return ['value' => 'No se encontraron resultados', 'id' => ''];
        }
    }

    /************************************************************/
    /**************ANULACION ASIENTO NOTA DE CREDITO CLIENTE*****
    /***********************************************************/
    public function anular_asiento($id)
    {
        $ip_cliente      = $_SERVER["REMOTE_ADDR"];
        $idusuario       = Auth::user()->id;
        $asiento         = Ct_Asientos_Cabecera::findorfail($id);
        $asiento->estado = 1;
        $asiento->save();
        $detalles = $asiento->detalles;

        $id_asiento = Ct_Asientos_Cabecera::insertGetId([
            'observacion'     => 'ANULACION ' . $asiento->observacion,
            'fecha_asiento'   => $asiento->fecha_asiento,
            'fact_numero'     => $asiento->fact_numero,
            'id_empresa'      => $asiento->id_empresa,
            'valor'           => $asiento->valor,
            'ip_creacion'     => $ip_cliente,
            'ip_modificacion' => $ip_cliente,
            'id_usuariocrea'  => $idusuario,
            'id_usuariomod'   => $idusuario,
        ]);
        foreach ($detalles as $value) {
            $value->estado = 1;
            $value->save();
            Ct_Asientos_Detalle::create([
                'id_asiento_cabecera' => $id_asiento,
                'id_plan_cuenta'      => $value->id_plan_cuenta,
                'debe'                => $value->haber,
                'haber'               => $value->debe,
                'descripcion'         => $value->descripcion,
                'fecha'               => $asiento->fecha_asiento,
                'ip_creacion'         => $ip_cliente,
                'ip_modificacion'     => $ip_cliente,
                'id_usuariocrea'      => $idusuario,
                'id_usuariomod'       => $idusuario,
            ]);
        }
        return "ok";
    }



    /************************************************************/
    /**************ANULAR NOTA DE CREDITO CLIENTE****************
    /***********************************************************/
    public function anular($id, Request $request)
    {

        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $fechahoy   = Date('Y-m-d H:i:s');
        $id_empresa = $request->session()->get('id_empresa');
        $nota_credito = Ct_Nota_Credito_Clientes::where('id', $id)->where('id_empresa', $id_empresa)->first();

        if (!is_null($nota_credito)) {

            $input = [
                'estado'          => '0',
                'id_usuariomod'   => $idusuario,
                'ip_modificacion' => $ip_cliente,
            ];

            $nota_credito->update($input);

            $consulta_cabecera_nc_client = Ct_Asientos_Cabecera::where('estado', '1')->where('id', $nota_credito->id_asiento_cabecera)->first();

            $input_asiento = [
                'estado'  => '0',
            ];

            $consulta_cabecera_nc_client->update($input_asiento);

            //Creamos un nuevo Registro de Anulacion Nota Credito Cliente
            $input_cabecera = [
                'observacion'     => 'ANULACIÓN NOTA DE CRÉDITO :' . $nota_credito->secuencia,
                'fecha_asiento'   => $fechahoy,
                'id_empresa'      => $consulta_cabecera_nc_client->id_empresa,
                'valor'           => $consulta_cabecera_nc_client->valor,
                'id_usuariocrea'  => $idusuario,
                'id_usuariomod'   => $idusuario,
                'ip_creacion'     => $ip_cliente,
                'ip_modificacion' => $ip_cliente,
            ];

            //Insercion en la Tabla Ct_Asientos_Cabecera
            $id_asiento_cab = Ct_Asientos_Cabecera::insertGetId($input_cabecera);

            //Obtenemos los Detalles
            $consulta_detalle = Ct_Asientos_Detalle::where('id_asiento_cabecera', $consulta_cabecera_nc_client->id)->get();

            if ($consulta_detalle != '[]') {

                foreach ($consulta_detalle as $value) {
                    Ct_Asientos_Detalle::create([
                        'id_asiento_cabecera' => $id_asiento_cab,
                        'id_plan_cuenta'      => $value->id_plan_cuenta,
                        'descripcion'         => $value->descripcion,
                        'fecha'               => $fechahoy,
                        'haber'               => $value->debe,
                        'debe'                => $value->haber,
                        'id_usuariocrea'      => $idusuario,
                        'id_usuariomod'       => $idusuario,
                        'ip_creacion'         => $ip_cliente,
                        'ip_modificacion'     => $ip_cliente,
                    ]);
                }
            }

            return redirect()->route('nota_credito_cliente.index');
        }
    }


    /************************************************************/
    /***************BUSCAR DATA CT NOTA CREDITO******************
    /***********************************************************/
    public function buscar_parametros(Request $request)
    {

        if (!is_null($request['id_nota'])) {

            $nota_credito  = Ct_Nota_Credito_Clientes::where('estado', '1')->where('id', $request['id_nota'])->first();
            $id_nota = $nota_credito->id;
            $secuencia = $nota_credito->secuencia;
            $id_asiento = $nota_credito->id_asiento_cabecera;

            return ['id_nota' => $id_nota, 'secuencia' => $secuencia, 'id_asiento' => $id_asiento];
        } else {

            return "false";
        }
    }

    /************************************************************/
    /**********OBTENER DETALLE DE DEUDAS DEL CLIENTE*************
    /***********************************************************/
    public function obtener_deudas_cliente(Request $request)
    {

        $id_cliente = $request['id_cliente'];
        $num_comprobante = $request['num_fact'];
        $id_empresa = $request->session()->get('id_empresa');

        $detalle_deuda = '[]';

        $detalle_deuda = DB::table('ct_clientes as p')
            ->join('ct_ventas as cv', 'cv.id_cliente', 'p.identificacion')
            ->where('cv.id_cliente', $id_cliente)
            ->where('cv.id_empresa', $id_empresa)
            ->where('cv.nro_comprobante', $num_comprobante)
            ->where('cv.estado_pago', '<', '3')
            ->where('cv.estado', '1')
            ->Where('cv.estado_pago', '>', '0')
            ->where('cv.valor_contable', '>', '0')
            //->where('cv.total_final','>','0')
            ->select('cv.id', 'cv.numero', 'cv.nro_comprobante', 'cv.fecha', 'cv.valor_contable')
            ->get();
        //->select('cv.id','cv.numero','cv.nro_comprobante','cv.fecha','cv.valor_contable')



        if ($detalle_deuda != '[]') {
            //$data = [$detalle_deuda[0]->id,$detalle_deuda[0]->numero,$detalle_deuda[0]->fecha,$detalle_deuda[0]->valor_contable,$detalle_deuda];
            $data = [$detalle_deuda[0]->id, $detalle_deuda[0]->numero, $detalle_deuda[0]->fecha, $detalle_deuda[0]->valor_contable, $detalle_deuda];
            return $data;
        } else {
            return ['value' => 'false'];
        }
    }

    /*******************************************************************************/
    /**********OBTENER DETALLE DE DEUDAS DEL CLIENTE SIN NUMERO FACTURA*************
    /*******************************************************************************/
    public function buscar_deudas_cliente(Request $request)
    {
        $id_cliente = $request['id_cliente'];
        $id_empresa = $request->session()->get('id_empresa');


        $detalle_deuda = '[]';

        $detalle_deuda = DB::table('ct_clientes as p')
            ->join('ct_ventas as cv', 'cv.id_cliente', 'p.identificacion')
            ->where('cv.id_cliente', $id_cliente)
            ->where('cv.id_empresa', $id_empresa)
            ->where('cv.estado', '1')
            ->where('cv.valor_contable', '>', '0')
            ->where('cv.tipo', '<>', 'VEN-FACT')
            ->select('cv.id', 'cv.numero', 'cv.nro_comprobante', 'cv.fecha', 'cv.valor_contable')
            ->get();

        if ($detalle_deuda != '[]') {
            $data = [$detalle_deuda[0]->id, $detalle_deuda[0]->numero, $detalle_deuda[0]->fecha, $detalle_deuda[0]->valor_contable, $detalle_deuda];
            return $data;
        } else {
            return ['value' => 'false'];
        }
    }


    /************************************************************/
    /**************OBTENER SUMA TOTAL DEUDAS CLIENTES************
    /***********************************************************/
    public function obtener_total_deudas(Request $request)
    {

        $id_cliente = $request['id_cliente'];
        $num_comprobante = $request['num_fact'];
        $id_empresa = $request->session()->get('id_empresa');

        $total_deuda_cliente = '[]';

        $total_deuda_cliente = DB::table('ct_clientes as p')
            ->join('ct_ventas as cv', 'cv.id_cliente', 'p.identificacion')
            ->where('cv.id_cliente', $id_cliente)
            ->where('cv.id_empresa', $id_empresa)
            ->where('cv.nro_comprobante', $num_comprobante)
            ->where('cv.estado_pago', '<', '3')
            ->Where('cv.estado_pago', '>', '0')
            ->where('cv.total_final', '>', '0')
            ->select(DB::raw("SUM(cv.valor_contable) as total"))
            ->first();

        //if(!is_null($total_deuda_cliente)){
        if ($total_deuda_cliente != '[]') {

            //return ['total_deuda' => $total_deuda_cliente->total];
            $data = ['total_deuda' => $total_deuda_cliente->total];
            return $data;
        } else {
            //return "false";
            return ['value' => 'false'];
        }
    }

    /************************************************************/
    /**************OBTENER SUMA TOTAL DEUDAS CLIENTES************
    /***********************************************************/
    public function suma_deudas_clientes(Request $request)
    {

        $id_cliente = $request['id_cliente'];
        $id_empresa = $request->session()->get('id_empresa');

        $total_deuda_cliente = '[]';

        $total_deuda_cliente = DB::table('ct_clientes as p')
            ->join('ct_ventas as cv', 'cv.id_cliente', 'p.identificacion')
            ->where('cv.id_cliente', $id_cliente)
            ->where('cv.id_empresa', $id_empresa)
            ->where('cv.estado_pago', '<', '3')
            ->Where('cv.estado_pago', '>', '0')
            ->where('cv.total_final', '>', '0')
            ->select(DB::raw("SUM(cv.total_final) as total"))
            ->first();


        if ($total_deuda_cliente != '[]') {

            $data = ['total_deuda' => $total_deuda_cliente->total];
            return $data;
        } else {

            return ['value' => 'false'];
        }
    }
    public function edit_nota_credito($id, Request $request)
    {

        if ($this->rol()) {
            return response()->view('errors.404');
        }

        $id_empresa = $request->session()->get('id_empresa');
        $empresa = Empresa::where('id', $id_empresa)->first();
        $nota_cred_client = Ct_Nota_Credito_Clientes::where('id', $id)->where('id_empresa', $id_empresa)->first();
        
        if (!is_null($nota_cred_client)) {

            $det_rub_cred = Ct_Detalle_Rubro_Credito::where('id_nt_cred_client', $nota_cred_client->id)->get();
            $det_cred_client = Ct_Detalle_Credito_Clientes::where('id_not_cred', $nota_cred_client->id)->get();
            //Obtenemos las Deudas del Cliente
            $id_cliente = $nota_cred_client->id_cliente;
            if($nota_cred_client->tipo!='CLI-RP'){
                return view('contable/nota_credito_cliente/edit', ['nota_cred_client' => $nota_cred_client, 'det_cred_client' => $det_cred_client, 'det_rub_cred' => $det_rub_cred, 'empresa' => $empresa]);
            }else{
                return view('contable/nota_credito_cliente/show', ['nota_cred_client' => $nota_cred_client, 'det_cred_client' => $det_cred_client, 'det_rub_cred' => $det_rub_cred, 'empresa' => $empresa]);
            }
            
        }

    }

    /************************************************************/
    /*****************BUSCAR NOTA DE CREDITO*********************
    /************************************************************/

    public function search(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }

        $id_empresa = $request->session()->get('id_empresa');
        $empresa    = Empresa::where('id', $id_empresa)->where('estado', '1')->first();

        $constraints = [
            'id_asiento_cabecera' => $request['buscar_asiento'],
            'id'                  => $request['numero'],
            'id_cliente'          => $request['id_cliente'],
            'concepto'            => $request['concepto'],
            'estado'              => 1,
            'id_empresa'          => $id_empresa,
        ];

        //$id_empresa = $request->session()->get('id_empresa');
        $clientes = Ct_Clientes::where('estado', '1')->get();
        $nota_credito = $this->doSearchingQuery($constraints);

        return view('contable/nota_credito_cliente/index', ['nota_credito' => $nota_credito, 'clientes' => $clientes, 'empresa' => $empresa]);
    }
    private function doSearchingQuery($constraints)
    {

        $query  = Ct_Nota_Credito_Clientes::query();
        $fields = array_keys($constraints);

        $index = 0;

        foreach ($constraints as $constraint) {
            if ($constraint != null) {
                $query = $query->where($fields[$index], 'like', '%' . $constraint . '%');
            }

            $index++;
        }

        return $query->orderby('id', 'asc')->paginate(10);
    }
    public function exportar_excel(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $consulta = null;
        $fecha_creacion = date('Y/m/d');
        $id_empresa = $request->session()->get('id_empresa');
        $empresa    = Empresa::where('id', $id_empresa)->first();

        $constraints = [
            'id_asiento_cabecera' => $request['buscar_asiento2'],
            'id'                  => $request['numero2'],
            'id_cliente'          => $request['id_cliente2'],
            'concepto'            => $request['concepto2'],
            'estado'              => 1,
            'id_empresa'          => $id_empresa,
        ];

        $consulta  = Ct_Nota_Credito_Clientes::query();
        $fields = array_keys($constraints);

        $index = 0;

        foreach ($constraints as $constraint) {
            if ($constraint != null) {
                $consulta = $consulta->where($fields[$index], 'like', '%' . $constraint . '%');
            }

            $index++;
        }

        $consulta = $consulta->get();

        Excel::create('Nota de Credito Clientes' . ' ' . $fecha_creacion, function ($excel) use ($empresa, $consulta) {

            $excel->sheet('Nota de Credito Clientes', function ($sheet) use ($empresa,  $consulta) {

                $sheet->mergeCells('C1:R1');
                $sheet->cell('C1', function ($cell) use ($empresa) {
                    if (!is_null($empresa)) {
                        $cell->setValue($empresa->nombrecomercial . ':' . $empresa->id);
                    }
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('15');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', '', 'thin');
                });
                if ($empresa->logo != null) {
                    $sheet->mergeCells('A1:B1');
                    $objDrawing = new PHPExcel_Worksheet_Drawing;
                    $objDrawing->setPath(base_path() . '/storage/app/logo/' . $empresa->logo);
                    $objDrawing->setCoordinates('A1');
                    $objDrawing->setHeight(220);
                    $objDrawing->setWidth(120);
                    $objDrawing->setWorksheet($sheet);
                }
                $sheet->mergeCells('C2:R2');
                $sheet->cell('C2', function ($cell) use ($empresa) {
                    if (!is_null($empresa)) {
                        $cell->setValue('INFORME NOTA DE CREDITO');
                    }
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->mergeCells('A3:B3');
                $sheet->cell('A3', function ($cell) {
                    $cell->setValue('# Nota Crédito');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('C3:D3');
                $sheet->cell('C3', function ($cell) {
                    
                    $cell->setValue('# de Asiento');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('E3', function ($cell) {
                    
                    $cell->setValue('Cliente');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('F3', function ($cell) {
                    
                    $cell->setValue('Fecha');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('G3', function ($cell) {
                    
                    $cell->setValue('Tipo');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->mergeCells('H3:I3');
                $sheet->cell('H3', function ($cell) {
                    
                    $cell->setValue('Detalle');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->mergeCells('J3:K3');
                $sheet->cell('J3', function ($cell) {
                    
                    $cell->setValue('Total Crédito');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->mergeCells('L3:M3');
                $sheet->cell('L3', function ($cell) {
                    
                    $cell->setValue('Total Deudas');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->mergeCells('N3:O3');
                $sheet->cell('N3', function ($cell) {
                    
                    $cell->setValue('Total Abono');
                    $cell->setFontWeight('bold');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('P3', function ($cell) {
                    
                    $cell->setValue('Estado');
                    $cell->setFontWeight('bold');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('Q3', function ($cell) {
                    
                    $cell->setValue('Creado Por');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('R3', function ($cell) {
                    
                    $cell->setValue('Factura Aplica');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBackground('#D1D1D1');
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->setColumnFormat(array(
                    'J' => '0.00',
                    'L' => '0.00',
                    'N' => '0.00',
                ));

                $i = 4;
                $total = 0;
                foreach ($consulta as $value) {
                    $nueva = ct_detalle_credito_clientes::where('id', $value->id)->first();
                    //dd($nueva);
                    $total += $value->total_credito;

                    $sheet->mergeCells('A' . $i . ':B' . $i);
                    $sheet->cell('A' . $i, function ($cell) use ($value) {
                        $cell->setValue($value->id);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->mergeCells('C' . $i . ':D' . $i);
                    $sheet->cell('C' . $i, function ($cell) use ($value) {
                        $cell->setValue($value->id_asiento_cabecera);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->cell('E' . $i, function ($cell) use ($value) {
                        $cell->setValue($value->cliente->nombre);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->cell('F' . $i, function ($cell) use ($value) {
                        $fech_inver = date("d/m/Y", strtotime($value->fecha));
                        $cell->setValue($fech_inver);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->cell('G' . $i, function ($cell) use ($value) {
                        $cell->setValue($value->tipo);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->mergeCells('H' . $i . ':I' . $i);
                    $sheet->cell('H' . $i, function ($cell) use ($value) {
                        $cell->setValue($value->concepto);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->mergeCells('J' . $i . ':K' . $i);
                    $sheet->cell('J' . $i, function ($cell) use ($value) {
                        $cell->setValue($value->total_credito);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->mergeCells('L' . $i . ':M' . $i);
                    $sheet->cell('L' . $i, function ($cell) use ($value) {
                        $cell->setValue($value->total_deudas);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->mergeCells('N' . $i . ':O' . $i);
                    $sheet->cell('N' . $i, function ($cell) use ($value) {
                        $cell->setValue($value->total_abonos);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->cell('P' . $i, function ($cell) use ($value) {
                        if (($value->estado) != 0) {
                            $cell->setValue('ACTIVO');
                        } else {
                            $cell->setValue('ANULADO');
                        }
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });


                    $sheet->cell('Q' . $i, function ($cell) use ($value) {
                        $cell->setValue($value->usercrea->nombre1 . $value->usercrea->apellido1);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('R' . $i, function ($cell) use ($nueva) {
                        if (!empty($nueva->secuencia_factura)) {
                            $cell->setValue($nueva->secuencia_factura);
                            $cell->setBorder('thin', 'thin', 'thin', 'thin');
                        } else {
                            $cell->setValue('No tiene secuencia');
                            $cell->setBorder('thin', 'thin', 'thin', 'thin');
                        }
                    });
                    $i++;
                }

                $sheet->mergeCells('H' . $i . ':I' . $i);
                $sheet->cell('H' . $i, function ($cell) {
                    $cell->setValue('Total');
                    $cell->setFontWeight('bold');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('J' . $i . ':K' . $i);
                $sheet->cell('J' . $i, function ($cell) use ($total) {
                    $cell->setValue($total);
                    $cell->setFontWeight('bold');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('L' . $i . ':M' . $i);
                $sheet->cell('L' . $i, function ($cell) use ($total) {
                    $cell->setValue($total);
                    $cell->setFontWeight('bold');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('N' . $i . ':O' . $i);
                $sheet->cell('N' . $i, function ($cell) use ($total) {
                    $cell->setValue($total);
                    $cell->setFontWeight('bold');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
            });
        })->export('xlsx');
    }
    public function getSRI($id)
    {
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $nota_credito = Ct_Nota_Credito_Clientes::find($id);
        $getType = $nota_credito->cliente->tipo;
        if (strlen($getType) == 1) {
            $getType = '0' . $getType;
        }
        $data['empresa']      = $nota_credito->id_empresa;
        $cliente['cedula']    = $nota_credito->id_cliente;
        $cliente['tipo']      = $getType;
        $cliente['nombre']    = $nota_credito->cliente->nombre;
        $cliente['apellido']  = '';
        $explode              = explode(" ", $nota_credito->cliente->nombre);
        if (count($explode) >= 4) {
            $cliente['nombre']    = $explode[0] . ' ' . $explode[1];
            for ($i = 2; $i < count($explode); $i++) {
                $cliente['apellido']  = $cliente['apellido'] . ' ' . $explode[$i];
            }
        }
        if (count($explode) == 3) {
            $cliente['nombre']    = $explode[0];
            $cliente['apellido']  = $explode[1] . ' ' . $explode[2];
        }
        if (count($explode) == 2) {
            $cliente['nombre']    = $explode[0];
            $cliente['apellido']  = $explode[1];
        }
        $cliente['email']     = $nota_credito->cliente->email;
        $cliente['telefono']  = $nota_credito->cliente->telefono;
        $direccion['calle']   = $nota_credito->cliente->direccion_representante;
        $direccion['ciudad']  = $nota_credito->cliente->ciudad_representante;
        $cliente['direccion'] = $direccion;
        $data['cliente']      = $cliente;

        $details = Ct_Detalle_Credito_Clientes::where('id_not_cred', $id)->first();
        $venta_detalle = Ct_detalle_venta::where('id_ct_ventas', $details->id_factura)->get();
        $ventas = Ct_ventas::find($details->id_compra);
        $tax = 0;

        $ventas = Ct_ventas::find($details->id_factura);
        $factura['comprobante']  = $ventas->nro_comprobante;
        $factura['fechaemision'] = $nota_credito->fecha;
        $factura['motivo']       = $nota_credito->concepto;
        $data['factura']         = $factura;

        //se envian los productos
        $cant = 0;

        foreach ($venta_detalle as $value) {
            //se envian los productos
            $producto['sku']       = $value->id_ct_productos; //ID EXAMEN
            $producto['nombre']    = $value->nombre; // NOMBRE DEL EXAMEN
            $producto['cantidad']  = $value->cantidad;
            $producto['precio']    = $value->precio; //DETALLE
            $pricetot = $value->cantidad * $value->precio;
            $producto['descuento'] = $value->descuento;
            $producto['subtotal']  = $pricetot - $value->descuento; //precio-descuento
            $tax = "0";
            if ($value->check_iva == 1) {
                $tax = $pricetot * $value->porcentaje;
            }
            $producto['tax']       = $tax;
            $producto['total']     = $pricetot - $value->valor_descuento; //SUBTOTAL
            $producto['copago']    = "0";
            $productos[$cant] = $producto;
            $cant++;
        }
        $data['productos'] = $productos;

        /*01  SIN UTILIZACION DEL SISTEMA FINANCIERO
        15  COMPENSACIÓN DE DEUDAS
        16  TARJETA DE DÉBITO
        17  DINERO ELECTRÓNICO
        18  TARJETA PREPAGO
        19  TARJETA DE CRÉDITO
        20  OTROS CON UTILIZACION DEL SISTEMA FINANCIERO
        21  ENDOSO DE TÍTULOS
         */

        $info_adicional['nombre']      = $nota_credito->cliente->nombre;
        $info_adicional['valor']       = $nota_credito->cliente->email_representante;
        $info[0]                       = $info_adicional;
        $pago['informacion_adicional'] = $info;
        $pago['forma_pago']            = '01';
        $pago['dias_plazo']            = '30';
        $data['pago']                  = $pago;

        if ($idusuario == "0957258056") {
            //dd($data);
        }

        $envio = ApiFacturacionController::crearNotasCredito($data);
        $nota_credito->update([
            'nro_comprobante' => $envio->comprobante,
            'fecha_envio' => date('Y-m-d H:i:s'),
        ]);

        $manage = $envio->status->status . '-' . $envio->status->message . '-' . $envio->status->reason;

        Log_usuario::create([
            'id_usuario'  => $idusuario,
            'ip_usuario'  => $ip_cliente,
            'descripcion' => "NOTA DE CREDITO ",
            'dato_ant1'   => $nota_credito->id,
            'dato1'       => 'envio',
            'dato_ant2'   => "ENVIAR AL SRI",
            'dato_ant4'   => $manage,
        ]);
    }
    public function informe_notacrecliente(Request $request)
    {
        //5000 id_venta revisar OJOOOOOOO

        $id_empresa  = $request->session()->get('id_empresa');
        $empresa     = Empresa::where('id', $id_empresa)->first();
        $fecha_desde = $request['fecha_desde'];
        $gastos      = $request['esfac_contable'];
        $variable    = 0;
        $variable2   = 0;
        $totales     = 0;
        $subtotal12  = 0;
        $subtotal0   = 0;
        $subtotal    = 0;
        $descuento   = 0;
        $impuesto    = 0;
        if ($gastos == null) {
            $gastos = 0;
        }
        $tipo = $request['tipo'];
        if ($tipo == null) {
            $tipo = 0;
        }
        if ($request['excelF'] == 1) {
            $this->excel_ncc($request);
        }
        $fecha_hasta = $request['fecha_hasta'];
        $proveedor   = $request['id_cliente'];
        $concepto    = $request['concepto'];
        $secuencia   = $request['secuencia'];
        $deudas      = [];
        $deudas2     = [];
        $proveedores = Ct_Clientes::where('estado', '<>', '0')->get();
        if (!is_null($fecha_hasta)) {
            $deudas = $this->informe_final($proveedor, $fecha_desde, $fecha_hasta, $id_empresa, $variable, $tipo, 0, $secuencia);

            $deudas2 = $this->informe_final($proveedor, $fecha_desde, $fecha_hasta, $id_empresa, $variable2, $tipo, 0, $secuencia);

            foreach ($deudas2 as $value) {
                if ($value != null) {
                    if ($value->estado != 0) {
                        $totales += $value->total_credito;
                        $subtotal12 += $value->tar_iva_12;
                        $subtotal0 += $value->sub_sin_imp;
                        $subtotal += $value->sub_sin_imp + $value->tar_iva_12;
                        $descuento += $value->descuento;
                        $impuesto += $value->impuesto;
                    }
                }
            }
        }

        return view('contable/nota_credito_cliente/informe_notacreditoclientes', ['informe' => $deudas, 'secuencia' => $secuencia, 'empresa' => $empresa, 'totales' => $totales, 'subtotal0' => $subtotal0, 'subtotal' => $subtotal, 'subtotal12' => $subtotal12, 'impuesto' => $impuesto, 'proveedores' => $proveedores, 'descuento' => $descuento, 'fecha_hasta' => $fecha_hasta, 'fecha_desde' => $fecha_desde, 'id_proveedor' => $proveedor, 'tipo' => $tipo]);
    }
    public function informe_final($proveedor, $fecha_desde, $fecha_hasta, $id_empresa, $variable, $referencia, $r, $secuencia)
    {
        //$deudas = $this->informe_final($proveedor, $fecha_desde, $fecha_hasta, $id_empresa, $variable, $tipo, 0, $secuencia);
        $deudas = null;
        // no modificar por favor 
        $deudas = Ct_Nota_Credito_Clientes::where('tipo', 'CLI-CR')
            ->where('id_empresa', $id_empresa);

        if (!is_null($fecha_desde)) {
            $deudas = $deudas->whereBetween('fecha', [$fecha_desde . ' 00:00:00', $fecha_hasta . ' 23:59:59']);
        } else {
            $deudas = $deudas->where('fecha', '<=', $fecha_hasta);
        }
        if (!is_null($secuencia)) {
            $deudas = $deudas->where('nro_comprobante', 'like', '%' . $secuencia . '%');
        }
        if (!is_null($proveedor)) {
            $deudas = $deudas->where('id_cliente', $proveedor);
        }
        if (($variable) == 1) {
            $deudas = $deudas->paginate(20);
        } else {
            $deudas = $deudas->orderBy('fecha', 'ASC')->get();
        }

        return $deudas;
    }
    public function excel_ncc(Request $request)
    {
        //dd("Ingreso");
        $id_empresa  = $request->session()->get('id_empresa');
        $fecha_desde = $request['fecha_desde'];
        $proveedor   = $request['id_cliente'];
        $fecha_hasta = $request['fecha_hasta'];
        $concepto    = $request['secuencia'];
        $gastos      = $request['tipo'];
        $variable    = 0;
        $fech        = 0;
        $empresa     = Empresa::where('id', $id_empresa)->first();
        $consulta    = $this->informe_final($proveedor, $fecha_desde, $fecha_hasta, $id_empresa, $variable, $gastos, 0, $concepto);
        //dd($consulta);
        Excel::create('Informe Nota de Credito Cliente ' . $fecha_desde . '-al-' . $fecha_hasta, function ($excel) use ($empresa, $consulta, $gastos, $fecha_hasta, $fecha_desde) {
            $excel->sheet('Informe Nota de Credito Cliente', function ($sheet) use ($empresa, $fecha_desde, $fecha_hasta, $consulta, $gastos) {
                if ($empresa->logo != null && $empresa->logo != '(N/A)') {
                    $fech = 1;
                    $sheet->mergeCells('A1:H1');
                    $objDrawing = new PHPExcel_Worksheet_Drawing;
                    $objDrawing->setPath(base_path() . '/storage/app/logo/' . $empresa->logo);
                    $objDrawing->setCoordinates('A1');
                    $objDrawing->setHeight(70);
                    $objDrawing->setWorksheet($sheet);
                }

                $sheet->mergeCells('C2:Q2');
                $sheet->cell('C2', function ($cell) use ($empresa) {
                    
                    $cell->setValue($empresa->nombrecomercial . ' ' . $empresa->id);
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('15');
                    $cell->setAlignment('center');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('C3:Q3');
                $sheet->cell('C3', function ($cell) {
                    
                    $cell->setValue("INFORME NOTA DE CREDITO DE CLIENTES ");
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('15');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->mergeCells('A4:Q4');
                $sheet->cell('A4', function ($cell) use ($fecha_desde, $fecha_hasta) {
                    
                    if ($fecha_desde != null) {
                        $cell->setValue("Desde " . date("d-m-Y", strtotime($fecha_desde)) . " Hasta " . date("d-m-Y", strtotime($fecha_hasta)));
                    } else {
                        $cell->setValue(" Al - " . date("d-m-Y", strtotime($fecha_hasta)));
                    }
                    $cell->setFontWeight('bold');
                    $cell->setFontSize('12');
                    $cell->setAlignment('center');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                //$sheet->mergeCells('A4:A5');
                $sheet->cell('A5', function ($cell) {
                    
                    $cell->setValue('FECHA');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('B5', function ($cell) {
                    
                    $cell->setValue('NUMERO');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('C5', function ($cell) {
                    
                    $cell->setValue('RUC');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('D5', function ($cell) {
                    
                    $cell->setValue('CLIENTE');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('E5', function ($cell) {
                    
                    $cell->setValue('PACIENTE');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('F5', function ($cell) {
                    $cell->setFontColor('#FFFFFF');
                    
                    $cell->setValue('TIPO');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });;
                $sheet->cell('G5', function ($cell) {
                    
                    $cell->setValue('DETALLE');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('H5', function ($cell) {
                    
                    $cell->setValue('SUBTOTAL 12');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('I5', function ($cell) {
                    
                    $cell->setValue('SUBTOTAL 0');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('J5', function ($cell) {
                    
                    $cell->setValue('SUBTOTAL ');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('K5', function ($cell) {
                    
                    $cell->setValue('DESCUENTO ');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('L5', function ($cell) {
                    
                    $cell->setValue('IMPUESTO ');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('M5', function ($cell) {
                    
                    $cell->setValue('TOTAL');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('N5', function ($cell) {
                    
                    $cell->setValue('ESTADO');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('O5', function ($cell) {
                    
                    $cell->setValue('CREADO POR');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('P5', function ($cell) {
                    
                    $cell->setValue('ANULADO POR');
                    $cell->setFontColor('#FFFFFF');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                // DETALLES

                $sheet->setColumnFormat(array(
                    'H' => '0.00',
                    'I' => '0.00',
                    'J' => '0.00',
                    'K' => '0.00',
                    'L' => '0.00',
                    'M' => '0.00',
                    'N' => '0.00',
                    'O' => '0.00',

                ));
                $i = $this->setDetalleInforme($consulta, $sheet, 6, $gastos);
                // $i = $this->setDetalles($pasivos, $sheet, $i);
                // $i = $this->setDetalles($patrimonio, $sheet, $i, $totpyg);

                //  CONFIGURACION FINAL
                $sheet->cells('C3:Q3', function ($cells) {
                    // manipulate the range of cells
                    $cells->setBackground('#BFBFBF');
                    // $cells->setFontSize('10');
                    $cells->setFontWeight('bold');
                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                    $cells->setValignment('center');
                });
                $sheet->cells('C2:Q2', function ($cells) {
                    // manipulate the range of cells
                    $cells->setBackground('#BFBFBF');
                    // $cells->setFontSize('10');
                    $cells->setFontWeight('bold');
                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                    $cells->setValignment('center');
                });

                $sheet->cells('A5:Q5', function ($cells) {
                    // manipulate the range of cells
                    $cells->setBackground('#BFBFBF');
                    $cells->setFontWeight('bold');
                    $cells->setFontSize('12');
                });
            });
            $excel->getActiveSheet()->getColumnDimension("A")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("B")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("C")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("D")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("E")->setWidth(23)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("F")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("G")->setWidth(60)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("H")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("I")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("J")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("K")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("L")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("M")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("N")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("O")->setWidth(20)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("P")->setWidth(18)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("Q")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("R")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("S")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("T")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("U")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("V")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("W")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("X")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("Y")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("Z")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("AA")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("AB")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("AC")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("AD")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("AE")->setWidth(16)->setAutosize(false);
            $excel->getActiveSheet()->getColumnDimension("AF")->setWidth(16)->setAutosize(false);
        })->export('xlsx');
    }
    public function setDetalleInforme($consulta, $sheet, $i, $variable)
    {
        $x          = 0;
        $valor      = 0;
        $resta      = 0;
        $totales    = 0;
        $subtotal12 = 0;
        $subtotal0  = 0;
        $subtotal   = 0;
        $descuento  = 0;
        $impuesto   = 0;
        $finalsub   = 0;
        foreach ($consulta as $value) {
            if ($value != null) {
                if ($value->estado != 0) {
                    if ($value->electronica == 1) {
                        $subtotal += $value->sub_sin_imp + $value->tar_iva_12 + $value->descuento;
                    } else {
                        $subtotal += $value->sub_sin_imp + $value->tar_iva_12;
                    }
                    $subtotal12 += $value->tar_iva_12;

                    $subtotal0 += $value->sub_sin_imp;

                    $descuento += $value->descuento;
                    $impuesto += $value->impuesto;
                    $finalsub = $value->tar_iva_12 + $value->sub_sin_imp;
                    $totales += $value->total_credito;
                }

                $sheet->cell('A' . $i, function ($cell) use ($value) {
                    
                    $cell->setValue(date("d-m-Y", strtotime($value->fecha)));
                    $cell->setFontWeight('bold');
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }

                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    // $this->setSangria($cont, $cell);
                });

                $sheet->cell('B' . $i, function ($cell) use ($value) {
                    
                    $cell->setValue($value->nro_comprobante);
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    // $this->setSangria($cont, $cell,1);
                });

                $sheet->cell('C' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);

                    $cell->setValue(' ' . $value->id_cliente);
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                //$sheet->mergeCells('G'.$i.':H'.$i);
                $sheet->cell('D' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    if ($value->cliente != null) {
                        $cell->setValue($value->cliente->nombre);
                    }
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }

                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('E' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    if ($value->paciente != null && $value->id_paciente != "9999999999") {
                        $cell->setValue($value->paciente->apellido1 . ' ' . $value->paciente->apellido2 . ' ' . $value->paciente->nombre1 . ' ' . $value->paciente->nombre2);
                    }
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('F' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    $cell->setValue($value->tipo);
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('G' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    $cell->setValignment('left');
                    $cell->setValue($value->concepto . "# Asiento " . $value->id_asiento);
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('H' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    if ($value->tar_iva_12 == null) {
                        $cell->setValue('0,00');
                    } else {
                        $cell->setValue($value->tar_iva_12);
                    }
                    $cell->setValignment('center');
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('I' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    if ($value->sub_sin_imp == null) {
                        $cell->setValue('0,00');
                    } else {
                        $cell->setValue($value->sub_sin_imp);
                    }


                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setValignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('J' . $i, function ($cell) use ($finalsub, $value) {
                    
                    // $this->setSangria($cont, $cell);

                    $cell->setValue($finalsub);
                    $cell->setValignment('center');
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('K' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    if ($value->descuento == null) {
                        $cell->setValue('0,00');
                    } else {
                        $cell->setValue($value->descuento);
                    }

                    $cell->setValignment('center');
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('L' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);

                    $cell->setValue($value->impuesto);
                    $cell->setValignment('center');
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('M' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    if ($value->electronica == 1) {
                        $get = $value->total_credito - $value->descuento;
                        if ($value->estado == 0) {
                            $cell->setBackground('#E64725');
                        }
                        $cell->setValue($get);
                    } else {
                        if ($value->estado == 0) {
                            $cell->setBackground('#E64725');
                        }
                        $cell->setValue($value->total_credito);
                    }
                    $cell->setValignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('N' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    if ($value->estado == 0) {
                        $cell->setValue('ANULADA');
                    } else {
                        $cell->setValue('ACTIVO');
                    }
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setValignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('O' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);

                    $cell->setValue($value->usuario->nombre1 . " " . $value->usuario->apellido1);
                    $cell->setValignment('center');
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('P' . $i, function ($cell) use ($value) {
                    
                    // $this->setSangria($cont, $cell);
                    if ($value->estado == 0) {
                        $cell->setValue($value->usuario->nombre1 . " " . $value->usuario->apellido1);
                    }
                    if ($value->estado == 0) {
                        $cell->setBackground('#E64725');
                    }
                    $cell->setValignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $i++;
            }
        }
        $sheet->cell('G' . $i, function ($cell) {
            
            // $this->setSangria($cont, $cell);

            $cell->setValue("TOTAL :");
            $cell->setValignment('center');
            $cell->setFontWeight('bold');
        });
        $sheet->cell('H' . $i, function ($cell) use ($subtotal12) {
            
            // $this->setSangria($cont, $cell);

            $cell->setValue($subtotal12);
            $cell->setValignment('center');
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        $sheet->cell('I' . $i, function ($cell) use ($subtotal0) {
            
            // $this->setSangria($cont, $cell);

            $cell->setValue($subtotal0);
            $cell->setValignment('center');
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        $sheet->cell('J' . $i, function ($cell) use ($subtotal) {
            
            // $this->setSangria($cont, $cell);

            $cell->setValue($subtotal);
            $cell->setValignment('center');
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        $sheet->cell('K' . $i, function ($cell) use ($descuento) {
            
            // $this->setSangria($cont, $cell);

            $cell->setValue($descuento);
            $cell->setValignment('center');
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        $sheet->cell('L' . $i, function ($cell) use ($impuesto) {
            
            // $this->setSangria($cont, $cell);

            $cell->setValue($impuesto);
            $cell->setValignment('center');
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });
        $sheet->cell('M' . $i, function ($cell) use ($totales) {
            
            // $this->setSangria($cont, $cell);

            $cell->setValue($totales);
            $cell->setValignment('center');
            $cell->setFontWeight('bold');
            $cell->setBorder('thin', 'thin', 'thin', 'thin');
        });

        return $i;
    }
    public function index_parcial(Request $request)
    {

        return view('contable.nota_credito_cliente.index_parcial');
    }
    public function create2(Request $request)
    {
        $id_empresa = $request->session()->get('id_empresa');
        $empresa = Empresa::where('id', $id_empresa)->first();
        $clientes = Ct_Clientes::where('estado', '1')->get();
        $sucursales = Ct_Sucursales::where('estado', 1)->where('id_empresa', $id_empresa)->get();
        return view('contable.nota_credito_cliente.create2', ['empresa' => $empresa, 'clientes' => $clientes, 'sucursales' => $sucursales]);
    }
    public function getcomprobante(Request $request)
    {
        $id_empresa = $request->session()->get('id_empresa');
        $productos = [];
        if ($request['search'] != null) {
            $productos = Ct_ventas::where('nro_comprobante', 'LIKE', '%' . $request['search'])->where('id_empresa', $id_empresa)->select('ct_ventas.id as id', 'ct_ventas.nro_comprobante as text')->get();
        }
        return response()->json($productos);
    }
    public function newData(Request $request)
    {
        $id_factura = $request['id_factura'];
        $venta = Ct_ventas::find($id_factura);

        $detalles = Ct_detalle_venta::where('id_ct_ventas', $id_factura)->get();
        $verificar= Ct_Devolucion_Productos::where('id_factura',$id_factura)->get();
        if(count($verificar)>0){
            $detalles= Ct_Devolucion_Productos::where('id_factura',$id_factura)->where('estado','0')->get();
        }
        return response()->json($detalles);
    }
    public function newstore(Request $request)
    {
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $id_empresa = $request->session()->get('id_empresa');
        $objeto_validar = new Validate_Decimals();
        $fecha_nota = $request['fecha_hoy'];
        $iva_param = Ct_Configuraciones::where('id_plan', '4.1.01.02')->first();
        $ivaf = $iva_param->iva;
        $nuevo_saldo = 0;
        $total_final = $objeto_validar->set_round($request['total']);
        DB::beginTransaction();
        //dd($request->all());
        $msj = "no";
        try {
            $venta = Ct_ventas::find($request['factura']);
            $cod_sucurs = Ct_Sucursales::where('estado', '1')->where('id', $request['sucursal'])->first();
            $c_sucursal = $cod_sucurs->codigo_sucursal;
            $cod_caj = Ct_Caja::where('estado', '1')->where('id', $request['punto_emision'])->first();
            $c_caja = $cod_caj->codigo_caja;
            $nfactura = $this->obtener_numero_factura($id_empresa, $cod_sucurs->codigo_sucursal, $cod_caj->codigo_caja);
            if (!is_null($request['secuencial'])) {
                $nfactura = $request['secuencial'];
            }
            $num_comprobante  = $cod_sucurs->codigo_sucursal . '-' . $cod_caj->codigo_caja . '-' . $nfactura;
            $input_cabecera = [
                'observacion'       => $request['concepto'],
                'fecha_asiento'     => $fecha_nota,
                'fact_numero'       => $num_comprobante,
                'valor'             => $total_final,
                'id_empresa'        => $id_empresa,
                'estado'            => '1',
                'ip_creacion'       => $ip_cliente,
                'ip_modificacion'   => $ip_cliente,
                'id_usuariocrea'    => $idusuario,
                'id_usuariomod'     => $idusuario,
            ];
            $id_asiento_cabecera = Ct_Asientos_Cabecera::insertGetId($input_cabecera);
            $input = [
                'id_empresa'                    => $id_empresa,
                'id_cliente'                    => $venta->id_cliente,
                'check_sri'                     => $request['check_archivo_sri'],
                'id_asiento_cabecera'           => $id_asiento_cabecera,
                'sucursal'                      => $c_sucursal,
                'punto_emision'                 => $c_caja,
                'numero_factura'                => $request['factura'],
                'nro_comprobante'               => $num_comprobante,
                'secuencia'                     => $nfactura,
                'fecha'                         => $request['fecha_hoy'],
                'tipo'                          => $request['tipo'],
                'concepto'                      => $request['concepto'],
                'subtotal'                      => $request['subtotal'],
                'impuesto'                      => $request['impuesto'],
                'sub_sin_imp'                   => $request['sub_sin_imp'],
                'tar_iva_12'                    => $request['tar_iva_12'],
                'total_credito'                 => $request['total'],
                'total_deudas'                  => $request['total'],
                'total_abonos'                  => $request['total'],
                'total_nuevo_saldo'             => $request['total'],
                'observacion'                   => $request['observaciones'],
                'electronica'                   => $request['electronica'],
                'estado'                        => '1',
                'ip_creacion'                   => $ip_cliente,
                'ip_modificacion'               => $ip_cliente,
                'id_usuariocrea'                => $idusuario,
                'id_usuariomod'                 => $idusuario,
            ];

            $id_credito = Ct_Nota_Credito_Clientes::insertGetId($input);
            $plan_nota_credito = Plan_Cuentas::where('id', '1.01.02.05.01')->first();
            Ct_Asientos_Detalle::create([
                'id_asiento_cabecera'           => $id_asiento_cabecera,
                'id_plan_cuenta'                => '1.01.02.05.01',
                'descripcion'                   => $plan_nota_credito->nombre,
                'fecha'                         => $fecha_nota,
                'debe'                          => $request['total'],
                'haber'                         => '0',
                'estado'                        => '1',
                'id_usuariocrea'                => $idusuario,
                'id_usuariomod'                 => $idusuario,
                'ip_creacion'                   => $ip_cliente,
                'ip_modificacion'               => $ip_cliente,
            ]);
            //cuentas por cobraer clientes y 
            for ($i = 0; $i < count($request['codigo']); $i++) {
                if($request['id'][$i]!=0){
                    $s= Ct_Devolucion_Productos::find($request['id'][$i]);
                    $s->estado=1;
                    $s->save();
                }else{
                    Ct_Devolucion_Productos::create([
                        'id_nota_credito' => $id_credito,
                        'descripcion'     =>$request['descripcion'][$i],
                        'id_factura'      =>$venta->id,
                        'nombre'          => $request['nombre'][$i],
                        'codigo'          =>$request['codigo'][$i],
                        'cantidad'        =>$request['cantidad'][$i],
                        'precio'          =>$request['precio'][$i],
                        'estado'          =>$request['verificar'][$i],
                        'id_usuariocrea'  => $idusuario,
                        'id_usuariomod'   => $idusuario,
                    ]);
                }
               
            }
            $valor_contable= $venta->valor_contable;
            $venta->valor_contable= $valor_contable- $request['total'];
            $venta->save();
            $empresa = Empresa::find($id_empresa);
            $sri = "";
            if ($empresa->electronica == 1 && $request['electronica'] == 1) {
                $sri = $this->getSRIParcial($id_credito);
            }
            DB::commit();

            return $id_credito;
        } catch (\Exception $e) {
           
            DB::rollBack();
            return ['error' => $e->getMessage()];
        }
    }
    public function getSRIParcial($id){
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $nota_credito = Ct_Nota_Credito_Clientes::find($id);
        $getType = $nota_credito->cliente->tipo;
        if (strlen($getType) == 1) {
            $getType = '0' . $getType;
        }
        $data['empresa']      = $nota_credito->id_empresa;
        $cliente['cedula']    = $nota_credito->id_cliente;
        $cliente['tipo']      = $getType;
        $cliente['nombre']    = $nota_credito->cliente->nombre;
        $cliente['apellido']  = '';
        $explode              = explode(" ", $nota_credito->cliente->nombre);
        if (count($explode) >= 4) {
            $cliente['nombre']    = $explode[0] . ' ' . $explode[1];
            for ($i = 2; $i < count($explode); $i++) {
                $cliente['apellido']  = $cliente['apellido'] . ' ' . $explode[$i];
            }
        }
        if (count($explode) == 3) {
            $cliente['nombre']    = $explode[0];
            $cliente['apellido']  = $explode[1] . ' ' . $explode[2];
        }
        if (count($explode) == 2) {
            $cliente['nombre']    = $explode[0];
            $cliente['apellido']  = $explode[1];
        }
        $cliente['email']     = $nota_credito->cliente->email;
        $cliente['telefono']  = $nota_credito->cliente->telefono;
        $direccion['calle']   = $nota_credito->cliente->direccion_representante;
        $direccion['ciudad']  = $nota_credito->cliente->ciudad_representante;
        $cliente['direccion'] = $direccion;
        $data['cliente']      = $cliente;
        //dd($nota_credito);
        $details = Ct_Detalle_Credito_Clientes::where('id_not_cred', $id)->first();
        $venta_detalle = Ct_Devolucion_Productos::where('id_nota_credito', $id)->where('estado','1')->get();
        $ventas = Ct_ventas::where('id',$nota_credito->numero_factura)->first();
        $factura['comprobante']  = $ventas->nro_comprobante;
        $factura['fechaemision'] = $ventas->fecha_emision;
        $factura['motivo']       = $nota_credito->concepto;
        $data['factura']         = $factura;
        //dd($data);
        //se envian los productos
        $cant = 0;
        //dd($venta_detalle);
        foreach ($venta_detalle as $value) {
            //se envian los productos
            $producto['sku']       = $value->codigo; //ID EXAMEN
            $producto['nombre']    = $value->nombre; // NOMBRE DEL EXAMEN
            $producto['cantidad']  = $value->cantidad;
            $producto['precio']    = $value->precio; //DETALLE
            $pricetot = $value->cantidad * $value->precio;
            $producto['descuento'] = $value->descuento;
            $producto['subtotal']  = $pricetot - $value->descuento; //precio-descuento
            $tax = "0";
            if ($value->iva == 1) {
                $tax = $pricetot * $value->porcentaje;
            }
            $producto['tax']       = $tax;
            $producto['total']     = $pricetot - $value->valor_descuento; //SUBTOTAL
            $producto['copago']    = "0";
            $productos[$cant] = $producto;
            $cant++;
        }
        $data['productos'] = $productos;
        if($idusuario=='1316262193'){
            //dd($data);
        }
        /*01  SIN UTILIZACION DEL SISTEMA FINANCIERO
        15  COMPENSACIÓN DE DEUDAS
        16  TARJETA DE DÉBITO
        17  DINERO ELECTRÓNICO
        18  TARJETA PREPAGO
        19  TARJETA DE CRÉDITO
        20  OTROS CON UTILIZACION DEL SISTEMA FINANCIERO
        21  ENDOSO DE TÍTULOS
         */

        $info_adicional['nombre']      = $nota_credito->cliente->nombre;
        $info_adicional['valor']       = $nota_credito->cliente->email_representante;
        $info[0]                       = $info_adicional;
        $pago['informacion_adicional'] = $info;
        $pago['forma_pago']            = '01';
        $pago['dias_plazo']            = '30';
        $data['pago']                  = $pago;

        $envio = ApiFacturacionController::crearNotasCredito($data);
        dd($envio);
        $nota_credito->update([
            'nro_comprobante' => $envio->comprobante,
            'fecha_envio' => date('Y-m-d H:i:s'),
        ]);

        $manage = $envio->status->status . '-' . $envio->status->message . '-' . $envio->status->reason;

        Log_usuario::create([
            'id_usuario'  => $idusuario,
            'ip_usuario'  => $ip_cliente,
            'descripcion' => "NOTA DE CREDITO ",
            'dato_ant1'   => $nota_credito->id,
            'dato1'       => 'envio',
            'dato_ant2'   => "ENVIAR AL SRI",
            'dato_ant4'   => $manage,
        ]);
    }
}
