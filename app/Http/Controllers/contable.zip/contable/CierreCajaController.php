<?php

namespace Sis_medico\Http\Controllers\contable;

use Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Sis_medico\Agenda;
use Sis_medico\CierreCaja;
use Sis_medico\Ct_Bancos;
use Sis_medico\Ct_Clientes;
use Sis_medico\Ct_Orden_Venta;
use Sis_medico\Empresa;
use Sis_medico\Ct_productos_paquete;
use Sis_medico\Ct_Tipo_Pago;
use Sis_medico\Ct_Tipo_Tarjeta;
use Sis_medico\Ct_Ven_Orden;
use Sis_medico\Ct_Ven_Orden_Detalle;
use Sis_medico\Detalle_Cierre_Caja;
use Sis_medico\Examen;
use Sis_medico\Examen_Agrupador;
use Sis_medico\Examen_Detalle_Forma_Pago;
use Sis_medico\Examen_Orden;
use Sis_medico\Http\Controllers\Controller;
use Sis_medico\Http\Requests\Request as RequestsRequest;
use Sis_medico\Labs_doc_externos;
use Sis_medico\Paciente;
use Sis_medico\Protocolo;
use Sis_medico\Seguro;
use Sis_medico\User;
use Sis_medico\Log_usuario;
use Sis_medico\Http\Controllers\ApiFacturacionController;

class CierreCajaController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    private function rol()
    {
        $rolUsuario = Auth::user()->id_tipo_usuario;
        if (in_array($rolUsuario, array(1, 4, 5, 20, 21, 22)) == false) {
            return true;
        }
    }

    public function index_cierre(Request $request)
    {

        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $fecha = $request['fecha'];
        if (is_null($fecha)) {
            $fecha = date('Y-m-d');
        }
        $fecha_hasta = $request['fecha_hasta'];
        if (is_null($fecha_hasta)) {
            $fecha_hasta = date('Y-m-d');
        }
        $id_empresa = $request['id_empresa'];
        if (is_null($id_empresa)) {
            $id_empresa = '0992704152001';
        }
        $caja = $request['caja'];

        $doctor = $request['doctor'];

        $tipo = $request['tipo'];
        /*if (is_null($tipo)) {
        $tipo = '0';
        }*/
        $cedula = $request['cedula'];
        //agenda.estado = 1 activa agenda.proc_consul 0 o 1
        $numero = $request['numero'];
        $facturas_pendientes = Agenda::leftjoin('ct_orden_venta as orden', 'orden.id_agenda', 'agenda.id')->join('paciente as p', 'p.id', 'agenda.id_paciente')->join('users as u', 'agenda.id_usuariocrea', 'u.id')->whereBetween('agenda.fechaini', [$fecha . ' 00:00:00', $fecha_hasta . ' 23:59:00'])->join('seguros as s', 's.id', 'agenda.id_seguro')->where('s.tipo', '<>', '0')->where('agenda.proc_consul', '<', '2')->whereRaw('(agenda.omni = "%NO%" OR agenda.omni IS NULL)')->where('agenda.estado', '<>', '0')->whereNotNull('agenda.id_doctor1')->whereNull('orden.id');
        if (is_null($numero)) {
            $ordenes = Ct_Orden_Venta::where('ct_orden_venta.estado', 1)
                ->join('agenda as a', 'a.id', 'ct_orden_venta.id_agenda')
                ->where('ct_orden_venta.id_empresa', $id_empresa);



            if (!is_null($caja)) {
                $ordenes = $ordenes->where('ct_orden_venta.caja', $caja);
            } else {
                $ordenes = $ordenes->where('ct_orden_venta.caja', '<>', 'LABORATORIO');
            }
            if (!is_null($tipo)) {
                $ordenes = $ordenes->where('a.proc_consul', $tipo);
                $facturas_pendientes = $facturas_pendientes->where('agenda.proc_consul', $tipo);
            }
            if (!is_null($doctor)) {
                $ordenes = $ordenes->where('a.id_doctor1', $doctor);
                $facturas_pendientes = $facturas_pendientes->where('agenda.id_doctor1', $doctor);
            }
            if (!is_null($cedula)) {
                $ordenes = $ordenes->where('a.id_paciente', $cedula);
                $facturas_pendientes = $facturas_pendientes->where('agenda.id_paciente', $cedula);
            }

            $ordenes = $ordenes->whereBetween('ct_orden_venta.fecha_emision', [$fecha . ' 00:00:00', $fecha_hasta . ' 23:59:00'])
                ->select('ct_orden_venta.*', 'a.id_doctor1', 'a.proc_consul')->get();
        } else {
            $ordenes = Ct_Orden_Venta::where('ct_orden_venta.id', $numero)
                ->join('agenda as a', 'a.id', 'ct_orden_venta.id_agenda')
                ->select('ct_orden_venta.*', 'a.id_doctor1', 'a.proc_consul')
                ->get();
        }
        $doctores = User::where('id_tipo_usuario', '3')->where('training', '0')->where('uso_sistema', '0')->orderby('apellido1')->get();
        $empresas = Empresa::where('id', '0992704152001')->orWhere('id', '1314490929001')->get();
        $facturas_pendientes = $facturas_pendientes->select('agenda.*', 'p.nombre1 as nombre1', 'p.apellido1 as apellido1', 'p.apellido2 as apellido2', 'u.nombre1 as unombre1', 'u.apellido1 as uapellido1', 'u.apellido2 as uapellido2', 'orden.id as orden')->get();
        return view('contable/reporte_cierre_caja/index_cierre', ['empresas' => $empresas, 'facturas_pendientes' => $facturas_pendientes, 'fecha' => $fecha, 'fecha_hasta' => $fecha_hasta, 'ordenes' => $ordenes, 'request' => $request, 'doctores' => $doctores, 'numero' => $numero, 'cedula' => $cedula]);
    }

    public function reporte(Request $request)
    {

        $fecha = $request['fecha'];
        if (is_null($fecha)) {
            $fecha = date('Y-m-d');
        }
        $fecha_hasta = $request['fecha_hasta'];
        if (is_null($fecha_hasta)) {
            $fecha_hasta = date('Y-m-d');
        }
        $id_empresa = $request['id_empresa'];
        if (is_null($id_empresa)) {
            $id_empresa = '0992704152001';
        }
        $caja = $request['caja'];

        $doctor = $request['doctor'];

        $tipo = $request['tipo'];
        /*if (is_null($tipo)) {
        $tipo = '0';
        }*/

        $ordenes = Ct_Orden_Venta::where('ct_orden_venta.estado', 1)
            ->join('agenda as a', 'a.id', 'ct_orden_venta.id_agenda')
            ->where('ct_orden_venta.id_empresa', $id_empresa)
            ->where('ct_orden_venta.caja', '<>', 'LABORATORIO')
            ->whereBetween('ct_orden_venta.fecha_emision', [$fecha . ' 00:00:00', $fecha_hasta . ' 23:59:00'])
            ->select('ct_orden_venta.*', 'a.id_doctor1', 'a.proc_consul');

        if (!is_null($tipo)) {
            $ordenes = $ordenes->where('a.proc_consul', $tipo);
        }

        if (!is_null($caja)) {
            $ordenes = $ordenes->where('ct_orden_venta.caja', $caja);
        }

        if (!is_null($doctor)) {
            $ordenes = $ordenes->where('a.id_doctor1', $doctor);
        }

        $ordenes = $ordenes->get();
        $empresa = Empresa::findorfail($id_empresa);

        $vistaurl = "contable.reporte_cierre_caja.pdf";
        $view     = \View::make($vistaurl, compact('ordenes', 'empresa', 'fecha', 'fecha_hasta', 'caja'))->render();

        $pdf = \App::make('dompdf.wrapper');
        $pdf->loadHTML($view);
        $pdf->setOptions(['dpi' => 150, 'isPhpEnabled' => true]);
        $pdf->setPaper('A4', 'landscape');
        return $pdf->stream('Cierre de Caja-' . $fecha . '.pdf');
    }
    public function imprimir_excel(Request $request)
    {
        $fecha = $request['fecha'];
        if (is_null($fecha)) {
            $fecha = date('Y-m-d');
        }
        $fecha_hasta = $request['fecha_hasta'];
        if (is_null($fecha_hasta)) {
            $fecha_hasta = date('Y-m-d');
        }
        $id_empresa = $request['id_empresa'];
        if (is_null($id_empresa)) {
            $id_empresa = '0992704152001';
        }
        $caja = $request['caja'];

        $doctor = $request['doctor'];

        $tipo = $request['tipo'];
        /*if (is_null($tipo)) {
        $tipo = '0';
        }*/

        $ordenes = Ct_Orden_Venta::where('ct_orden_venta.estado', 1)
            ->join('agenda as a', 'a.id', 'ct_orden_venta.id_agenda')
            ->where('ct_orden_venta.id_empresa', $id_empresa)
            ->whereBetween('ct_orden_venta.fecha_emision', [$fecha . ' 00:00:00', $fecha_hasta . ' 23:59:00'])
            ->select('ct_orden_venta.*', 'a.id_doctor1', 'a.proc_consul');

        /*$ordenes  = Agenda::where('agenda.estado', 1)
        ->leftjoin('ct_orden_venta as orden_venta', 'orden_venta.id_agenda', 'agenda.id')
        ->where('orden_venta.id_empresa', $id_empresa)
        ->whereBetween('agenda.fechaini', [$fecha.' 00:00:00', $fecha_hasta.' 23:59:00'])
        ->where('agenda.proc_consul',$tipo)
        ->where('agenda.estado_cita','4')
        ->select('agenda.*', 'agenda.id_doctor1', 'agenda.proc_consul','agenda.estado_cita');*/

        if (!is_null($tipo)) {
            $ordenes = $ordenes->where('a.proc_consul', $tipo);
        }

        if (!is_null($caja)) {
            $ordenes = $ordenes->where('ct_orden_venta.caja', $caja);
        }

        if (!is_null($doctor)) {
            $ordenes = $ordenes->where('a.id_doctor1', $doctor);
        }

        $ordenes = $ordenes->get();
        //dd($request->all(),$ordenes);

        $empresa = Empresa::findorfail($id_empresa);

        Excel::create('Cierre de Caja-' . $fecha, function ($excel) use ($ordenes, $empresa) {

            $excel->sheet('Cierre de Caja', function ($sheet) use ($ordenes, $empresa) {
                $sheet->mergeCells('B2:M2');
                $sheet->cell('B2', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('CONSULTAS MEDICAS ESPECIALIZADAS DR CARLOS ROBLES');
                    $cell->setFontWeight('bold');
                    $cell->setBackground('#1A28D7');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('B3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('FECHA CITA');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('C3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('HORA CITA');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('D3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('PACIENTE');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('E3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('CTS');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('F3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('ADMISION');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('G3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('DOCTOR');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('H3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('PROCEDIMIENTO');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('I3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('SEGURO/CONVENIO');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('J3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('TIPO CITA');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $sheet->cell('K3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('REFERENCIA');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('L3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('EFECTIVO');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('M3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('T.CREDITO');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('N3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('7% T/C');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('O3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('2% T/D');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('P3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('TRANSF/DEP');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('Q3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('CHEQUE');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('R3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('PEND FC SEG');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('S3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('TOTAL VTA');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('T3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('HONOR. MEDICOS');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('U3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('COMPROBANTE');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('V3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('OBSERVACION');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('W3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('ORIGEN');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('X3', function ($cell) {
                    // manipulate the cel
                    $cell->setValue('DETALLE');
                    $cell->setFontWeight('bold');
                    $cell->setAlignment('center');
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });

                $tefectivo      = 0;
                $ttarjeta       = 0;
                $acum_efectivo  = 0;
                $acum_tcredito  = 0;
                $acum_p7        = 0;
                $acum_p2        = 0;
                $acum_tran      = 0;
                $acum_cheque    = 0;
                $acum_oda       = 0;
                $acum_total     = 0;
                $acum_honorario = 0;
                $xcont          = 0;
                $i              = 4;
                foreach ($ordenes as $value) {

                    $pagos      = $value->pagos;
                    $efectivo   = 0;
                    $tcredito   = 0;
                    $p7         = 0;
                    $p2         = 0;
                    $tran       = 0;
                    $cheque     = 0;
                    $total      = 0;
                    $referencia = "";
                    foreach ($pagos as $pago) {
                        $total += $pago->valor;
                        if ($pago->tipo == '1') {
                            $efectivo += $pago->valor;
                        }

                        if ($pago->tipo == 4) {
                            $va = $pago->valor / (1 + $pago->p_fi);
                            $po = $va * $pago->p_fi;
                            $tcredito += $va;
                            $p7 += $po;
                        }

                        if ($pago->tipo == 6) {
                            $va = $pago->valor / (1 + $pago->p_fi);
                            $po = $va * $pago->p_fi;
                            $tcredito += $va;
                            $p2 += $po;
                        }

                        if ($pago->tipo == 3 || $pago->tipo == 5) {
                            $tran += $pago->valor;
                        }

                        if ($pago->tipo == 2) {
                            $cheque += $pago->valor;
                        }
                    }
                    if ($efectivo > 0) {
                        $referencia = "CASH";
                    }
                    if ($tcredito > 0) {
                        if (!is_null($referencia)) {
                            $referencia = $referencia . "+Tarjeta ";
                        } else {
                            $referencia = "+Tarjeta ";
                        }
                    }
                    if ($tran > 0) {
                        if (!is_null($referencia)) {
                            $referencia = $referencia . "+TRAN/DEP";
                        } else {
                            $referencia = "+TRAN/DEP";
                        }
                    }
                    if ($cheque > 0) {
                        if (!is_null($referencia)) {
                            $referencia = $referencia . "+CH";
                        } else {
                            $referencia = "+CH";
                        }
                    }
                    $total += $value->valor_oda;
                    $honorario      = $total - $p2 - $p7;
                    $acum_efectivo  = $acum_efectivo + $efectivo;
                    $acum_tcredito  = $acum_tcredito + $tcredito;
                    $acum_p7        = $acum_p7 + $p7;
                    $acum_p2        = $acum_p2 + $p2;
                    $acum_tran      = $acum_tran + $tran;
                    $acum_cheque    = $acum_cheque + $cheque;
                    $acum_oda       = $acum_oda + $value->valor_oda;
                    $acum_total     = $acum_total + $total;
                    $acum_honorario = $acum_honorario + $honorario;
                    $xcont++;

                    $sheet->cell('B' . $i, function ($cell) use ($value) {
                        // manipulate the cel
                        $cell->setValue(substr($value->agenda->fechaini, 0, 10));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('C' . $i, function ($cell) use ($value) {
                        // manipulate the cel
                        $cell->setValue(substr($value->agenda->fechaini, 11, 5));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->cell('D' . $i, function ($cell) use ($value) {
                        // manipulate the cel
                        $cell->setValue($value->agenda->paciente->apellido1 . ' ' . $value->agenda->paciente->apellido2 . ' ' . $value->agenda->paciente->nombre1 . ' ' . $value->agenda->paciente->nombre2);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $sheet->cell('E' . $i, function ($cell) use ($value) {
                        // manipulate the cel
                        $cell->setValue($value->agenda->cortesia);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('F' . $i, function ($cell) use ($value) {
                        // manipulate the cel
                        $cell->setValue($value->usercrea->apellido1 . " " . $value->usercrea->nombre1);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('G' . $i, function ($cell) use ($value) {
                        // manipulate the cel
                        if ($value->agenda->doctor1 != null) {
                            $cell->setValue($value->agenda->doctor1->apellido1 . " " . $value->agenda->doctor1->nombre1);
                            $cell->setBorder('thin', 'thin', 'thin', 'thin');
                        }
                    });
                    $sheet->cell('H' . $i, function ($cell) use ($value) {

                        // manipulate the cel
                        if ($value->agenda->proc_consul == 0) {
                            $cell->setValue("CONSULTA");
                            $cell->setBorder('thin', 'thin', 'thin', 'thin');
                        } elseif ($value->agenda->proc_consul == 1) {
                            $procedimiento = "";
                            if ($value->agenda->proc_consul == 1) {
                                $pro_c = \Sis_medico\Procedimiento::find($value->agenda->id_procedimiento);
                                if (!is_null($pro_c)) {
                                    $procedimiento = $pro_c->observacion . '+';
                                }
                                $proced_total = \Sis_medico\AgendaProcedimiento::where('id_agenda', $value->id_agenda)->get();
                                foreach ($proced_total as $value_pro) {
                                    $procedimiento = $procedimiento . $value_pro->procedimiento->observacion . '+';
                                }
                                $procedimiento = substr($procedimiento, 0, -1);
                            }
                            $cell->setValue($procedimiento);
                            $cell->setBorder('thin', 'thin', 'thin', 'thin');
                        }
                    });
                    //dd($value->agenda);

                    $sheet->cell('I' . $i, function ($cell) use ($value) {
                        // manipulate the cel
                        if (!is_null($value->agenda->historia_clinica)) {
                            $cell->setValue($value->agenda->historia_clinica->seguro->nombre);
                        } else {
                            $cell->setValue($value->agenda->seguro->nombre);
                        }
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('J' . $i, function ($cell) use ($value) {
                        // manipulate the cel
                        if ($value->agenda->tipo_cita == 0) {
                            $cell->setValue("PRIMERA VEZ");
                            $cell->setBorder('thin', 'thin', 'thin', 'thin');
                        } else {
                            $cell->setValue("CONSECUTIVO");
                            $cell->setBorder('thin', 'thin', 'thin', 'thin');
                        }
                    });
                    $sheet->cell('K' . $i, function ($cell) use ($value, $referencia) {
                        // manipulate the cel
                        $cell->setValue($referencia);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('L' . $i, function ($cell) use ($value, $efectivo) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $efectivo));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('M' . $i, function ($cell) use ($value, $tcredito) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $tcredito));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('N' . $i, function ($cell) use ($value, $p7) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $p7));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('O' . $i, function ($cell) use ($value, $p2) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $p2));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('P' . $i, function ($cell) use ($value, $tran) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $tran));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('Q' . $i, function ($cell) use ($value, $cheque) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $cheque));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('R' . $i, function ($cell) use ($value) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $value->valor_oda));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('S' . $i, function ($cell) use ($value, $total) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $total));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('T' . $i, function ($cell) use ($value, $honorario) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $honorario));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('U' . $i, function ($cell) use ($value, $honorario) {
                        // manipulate the cel
                        $cell->setValue(sprintf("%.2f", $value->id));
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('V' . $i, function ($cell) use ($value, $honorario) {
                        // manipulate the cel
                        $cell->setValue($value->observacion);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('W' . $i, function ($cell) use ($value, $honorario) {
                        // manipulate the cel
                        $cell->setValue($value->agenda->paciente->origen);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->cell('X' . $i, function ($cell) use ($value, $honorario) {
                        // manipulate the cel
                        $cell->setValue($value->agenda->paciente->origen2);
                        $cell->setBorder('thin', 'thin', 'thin', 'thin');
                    });

                    $i++;
                }
                $x = $i;
                $sheet->cell('L' . $x, function ($cell) use ($acum_efectivo) {
                    // manipulate the cel
                    $cell->setValue(sprintf("%.2f", $acum_efectivo));
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('M' . $x, function ($cell) use ($acum_tcredito) {
                    // manipulate the cel
                    $cell->setValue(sprintf("%.2f", $acum_tcredito));
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('N' . $x, function ($cell) use ($acum_p7) {
                    // manipulate the cel
                    $cell->setValue(sprintf("%.2f", $acum_p7));
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('O' . $x, function ($cell) use ($acum_p2) {
                    // manipulate the cel
                    $cell->setValue(sprintf("%.2f", $acum_p2));
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('P' . $x, function ($cell) use ($acum_tran) {
                    // manipulate the cel
                    $cell->setValue(sprintf("%.2f", $acum_tran));
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('Q' . $x, function ($cell) use ($acum_cheque) {
                    // manipulate the cel
                    $cell->setValue(sprintf("%.2f", $acum_cheque));
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('R' . $x, function ($cell) use ($acum_oda) {
                    // manipulate the cel
                    $cell->setValue(sprintf("%.2f", $acum_oda));
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('S' . $x, function ($cell) use ($acum_total) {
                    // manipulate the cel
                    $cell->setValue(sprintf("%.2f", $acum_total));
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
                $sheet->cell('T' . $x, function ($cell) use ($acum_honorario) {
                    // manipulate the cel
                    $cell->setValue(sprintf("%.2f", $acum_honorario));
                    $cell->setBorder('thin', 'thin', 'thin', 'thin');
                });
            });
        })->export('xlsx');
    }

    //Completa Proceso 
    /*public function completa_proceso_cierrecaja($id_product,$id_orden,$id_orden){
       
        //dd($id_product,$id_orden);

        $orden_venta_det =  Ct_Orden_Venta::where('ct_orden_venta.id',$id_orden)
                             ->select('ct_orden_venta.id_seguro as seguro', 'ct_orden_venta.id_nivel as nivel')
                             ->first();

        $existe_prod_paquete = Ct_productos_paquete::where('ct_productos_paquete.id_producto',$id_product)
                             ->join('ct_producto_tarifario_paquete as ptq', 'ptq.id_producto_paquete', 'ct_productos_paquete.id')
                             ->where('ct_productos_paquete.estado','1')
                             ->where('ptq.id_seguro',$request['id_seguro'])
                             ->where('ptq.id_nivel',$request['id_nivel'])
                             ->where('ptq.estado','1')
                             ->select('ct_productos_paquete.id as id_prod_paquete','ptq.id as id_prod_tar_paquete','ptq.precio as precio','ptq.id_seguro as id_seguro','ptq.id_nivel as id_nivel','ct_productos_paquete.id_producto as id_producto','ct_productos_paquete.nombre as nomb_paquete')
                             ->get();
        
    
    }*/
    public function cierre_caja(Request $request)
    {
        $id_empresa = $request->session()->get('id_empresa');
        $idusuario       = Auth::user()->id;
        $empresa = Empresa::where('id', '0993075000001')->first();
        $dateToday = date('Y-m-d');
        if ($request['fecha'] != null) {
            $dateToday = date('Y-m-d', strtotime($request['fecha']));
        }
        $cierre = CierreCaja::where('estado', '1')->whereDate('fecha', $dateToday)->where('id_usuariocrea', $idusuario)->orderBy('fecha', 'ASC')->get();
        $ingresoCaja = CierreCaja::whereDate('fecha', $dateToday)->where('tipo', '0')->first();
        $cierreFinal = CierreCaja::whereDate('fecha', $dateToday)->where('tipo', '4')->where('id_usuariocrea', $idusuario)->first();
        $datosFinal= $this->getLast($idusuario,$dateToday,$request);
        return view('contable.cierre_caja.index', ['empresa' => $empresa, 'cierre' => $cierre, 'ingresoCaja' => $ingresoCaja, 'cierreFinal' => $cierreFinal, 'fecha' => $dateToday,'datosFinal'=>$datosFinal]);
    }
    public function store_cierre(Request $request)
    {
        $ip_cliente      = $_SERVER["REMOTE_ADDR"];
        $idusuario       = Auth::user()->id;
        if ($request['inicial'] == '0') {
            //dd($request->all());
            CierreCaja::create([
                'fecha' => $request['fechaTime'],
                'tipo' => '0',
                'descripcion' => $request['observacionTime'],
                'valor' => $request['valorTime'],
                'saldo' => $request['valorTime'],
                'estado' => '1',
                'ip_creacion'     => $ip_cliente,
                'ip_modificacion' => $ip_cliente,
                'id_usuariocrea'  => $idusuario,
                'id_usuariomod'   => $idusuario,
            ]);
        } else {
            $saldo = CierreCaja::whereDate('fecha', date('Y-m-d'))->latest()->first();
            $total = $saldo->saldo + $request['valorTime'];
            CierreCaja::create([
                'fecha' => $request['fechaTime'],
                'tipo' => '1',
                'descripcion' => $request['observacionTime'],
                'valor' => $request['valorTime'],
                'saldo' => $total,
                'estado' => '1',
                'ip_creacion'     => $ip_cliente,
                'ip_modificacion' => $ip_cliente,
                'id_usuariocrea'  => $idusuario,
                'id_usuariomod'   => $idusuario,
            ]);
        }

        return redirect()->route('c_caja.index');
    }
    public function store_salida(Request $request)
    {
        $ip_cliente      = $_SERVER["REMOTE_ADDR"];
        $idusuario       = Auth::user()->id;

        $saldo = CierreCaja::whereDate('fecha', date('Y-m-d'))->latest()->first();
        CierreCaja::create([
            'fecha' => $request['fechacierre'],
            'tipo' => '4',
            'descripcion' => $request['observacionTime2'],
            'valor' => $request['valorcierre'],
            'saldo' => $request['valorcierre'],
            'estado' => '1',
            'ip_creacion'     => $ip_cliente,
            'ip_modificacion' => $ip_cliente,
            'id_usuariocrea'  => $idusuario,
            'id_usuariomod'   => $idusuario,
        ]);
        return redirect()->route('c_caja.index');
    }
    public function modalrecibo($id, Request $request)
    {
        $orden   = Examen_Orden::find($id);
        $cliente = Ct_Clientes::where('identificacion', $id)->where('estado', '1')->first();
        $recargo_valor = $orden->detalle_forma_pago->sum('p_fi');
        $valor_forma   = $orden->detalle_forma_pago->sum('valor');
        $total_forma   = $valor_forma + $recargo_valor;
        return view('contable.cierre_caja.modal', ['id_orden' => $id, 'orden' => $orden, 'cliente' => $cliente, 'recargo_valor' => $recargo_valor, 'valor_forma' => $valor_forma, 'total_forma' => $total_forma]);
    }
    public function storeLabs(Request $request)
    {

        $saldo = CierreCaja::whereDate('fecha', date('Y-m-d'))->latest()->first();
        $ip_cliente      = $_SERVER["REMOTE_ADDR"];
        $idusuario       = Auth::user()->id;
        if (!is_null($saldo)) {
            $total = $saldo->saldo + $request['total'];
        } else {
            $total = 0;
        }
        $orden = Examen_Orden::find($request['id_orden']);
        if (is_null($orden)) {
            return response()->json("error");
        }
        $paciente = Paciente::find($request['id_paciente']);
        if (is_null($request['id_paciente'])) {
            $request['id_paciente'] = $idusuario;
        }
        $nseguro = "";
        if (!is_null($paciente)) {
            $nseguro = $paciente->seguro->id;
        }

        $valid = CierreCaja::whereDate('fecha', date('Y-m-d'))->where('tipo', '4')->where('id_usuariocrea', $idusuario)->first();
        $othervalid= CierreCaja::where('id_orden',$request['id_orden'])->first();
        if(is_null($othervalid)){
            $idcierre = CierreCaja::insertGetid([
                'fecha' => date('Y-m-d H:m:s'),
                'tipo' => '1',
                'id_paciente' => $request['id_paciente'],
                'id_seguro' => $nseguro,
                'descripcion' => 'El examen orden : ' . $request['id_orden'] . ' paciente: ' . $paciente->apellido1 . ' ' . $paciente->nombre1,
                'valor' => $request['total'],
                'saldo' => $total,
                'id_orden' => $request['id_orden'],
                'estado' => '1',
                'ip_creacion'     => $ip_cliente,
                'ip_modificacion' => $ip_cliente,
                'id_usuariocrea'  => $idusuario,
                'id_usuariomod'   => $idusuario,
            ]);
        }


        return response()->json("ok");
    }
    public function getData(Request $request)
    {
        $idusuario       = Auth::user()->id;
        $today = date('Y-m-d', strtotime($request['fecha']));
        $draw = $request->get('draw');
        $start = $request->get("start");
        $rowperpage = $request->get("length"); // Rows display per page
        $columnIndex_arr = $request->get('order');
        $columnName_arr = $request->get('columns');
        $order_arr = $request->get('order');
        $search_arr = $request->get('search');

        $columnIndex = $columnIndex_arr[0]['column']; // Column index
        $columnName = $columnName_arr[$columnIndex]['data']; // Column name
        $columnSortOrder = $order_arr[0]['dir']; // asc or desc
        $searchValue = $search_arr['value']; // Search value
        $records = [];
        $id_user = $request['idUser'];
        // Total records

        $totalRecords = CierreCaja::where('estado', '1')->where('tipo','<>','3')->whereDate('fecha', $today)->select('count(*) as allcount')->count();
        $totalRecordswithFilter = CierreCaja::where('estado', '1')->where('tipo','<>','3')->whereDate('fecha', $today)->select('count(*) as allcount')->where('descripcion', 'like', '%' . $searchValue . '%')->count();
        $records = CierreCaja::where('cierre_caja.estado', '1')
        
            ->leftjoin('examen_detalle_forma_pago as ep', 'ep.id_examen_orden', 'cierre_caja.id_orden')
            ->whereDate('cierre_caja.fecha', $today)->where('cierre_caja.tipo','<>','4');
            

        if ($rowperpage == '-1') {

            if (isset($id_user) && $id_user != "null") {
                $records = $records
                    ->where('cierre_caja.id_usuariocrea', $id_user);
            }
            if (isset($request['ordenid']) && $request['ordenid'] != null) {
                $records->where('cierre_caja.id_orden', $request['ordenid']);
            }
        }
        $records = $records->orderBy($columnName, $columnSortOrder)
            ->select('cierre_caja.*')
            ->distinct('cierre_caja.id_orden')
            ->get();
        // Fetch records
        if ($searchValue != null) {
            if ($rowperpage == '-1') {
                $records = CierreCaja::where('cierre_caja.estado', '1')
                    ->leftjoin('examen_detalle_forma_pago as ep', 'ep.id_examen_orden', 'cierre_caja.id_orden')
                    ->whereDate('cierre_caja.fecha', $today)
                    ->orderBy($columnName, $columnSortOrder)
                    ->select('cierre_caja.*')
                    ->distinct()
                    ->get();
                if (isset($id_user) && $id_user != "null") {
                    $records = CierreCaja::where('cierre_caja.estado', '1')
                        ->leftjoin('examen_detalle_forma_pago as ep', 'ep.id_examen_orden', 'cierre_caja.id_orden')
                        ->whereDate('cierre_caja.fecha', $today)
                        ->where('cierre_caja.id_usuariocrea', $id_user)
                        ->orderBy($columnName, $columnSortOrder)
                        ->select('cierre_caja.*')
                        ->distinct()
                        ->get();
                }
            } else {
                $records = CierreCaja::where('cierre_caja.estado', '1')
                    ->leftjoin('examen_detalle_forma_pago as ep', 'ep.id_examen_orden', 'cierre_caja.id_orden')
                    ->whereDate('cierre_caja.fecha', $today)
                    ->select('cierre_caja.*')
                    ->distinct()
                    ->orderBy($columnName, $columnSortOrder)
                    ->skip($start)
                    ->take($rowperpage)
                    ->get();
            }
        }


        $data_arr = array();
        $sno = $start + 1;
        $contador = 0;
        foreach ($records as $record) {

            $id = date('d/m/Y H:i:s', strtotime($record->fecha));
            $orden = Examen_Orden::find($record->id_orden);
            $forma_pago = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->get();
            $xdata = "";
            $dataEfectivo = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '1')->sum('valor');
            $dataCheque = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '2')->sum('valor');
            $dataDeposito = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '3')->sum('valor');
            $dataTarjetaCredito = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '4')->sum('p_fi');
            $dataTransferencia = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '5')->sum('valor');
            $dataTarjetaDebito = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '6')->sum('p_fi');
            $dataPendientePago = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '7')->sum('valor');
            $paciente = Paciente::find($record->id_paciente);
            $usuario = User::find($record->id_usuariocrea);
            $seguro = null;
            $id_orden = null;
            if (!is_null($orden)) {
                $seguro = Seguro::find($orden->id_seguro);
                $paciente = Paciente::find($orden->id_paciente);
                $id_orden = $orden->id;
                if ($dataTarjetaCredito > 0) {
                    //tuve que setear los valores de esta manera por el valor
                    $dataTarjetaCredito = $orden->total_valor;
                }
                if ($dataTarjetaDebito > 0) {
                    //tuve que setear los valores de esta manera por equivocacion martes 20 de julio del 2021
                    $dataTarjetaDebito = $orden->total_valor;
                }
            }
            //$pl = "1"; //acuerdate de esto siempre 
            //$datesFinally = "Martes 20 de Julio del 2021";
            $nseguro = "";
            if (!is_null($seguro)) {
                $nseguro = $seguro->nombre;
            }

            $facturado = "No Facturado";
            if ($orden != null) {
                if ($orden->comprobante != null && $orden->fecha_envio != null) {
                    $facturado = "Facturado";
                }
                if ($orden->seguro->tipo == 0) {
                    if ($dataPendientePago == 0) {
                        $facturado = "Orden Publica";
                        $dataPendientePago = $orden->total_valor;
                    }
                }
            } else {
                if ($record->tipo == '4') {
                    $facturado = "Cierre Caja";
                } else if ($record->tipo == '0') {
                    $facturado = "Inicio de Caja";
                }
            }

            $nombre = "";
            if (!is_null($paciente)) {
                $nombre = $paciente->apellido1 . ' ' . $paciente->apellido2 . ' ' . $paciente->nombre1;
            } else {
            }
            if ($record->tipo == '0') {
                $xdata = "Inicio de caja";
            } elseif ($record->tipo == '1') {
                $xdata = "Ingreso de caja";
            } elseif ($record->tipo == '2') {
                $xdata = "Salida de caja";
            } elseif ($record->tipo == '4') {
                $xdata = "Cierre de caja";
            }
            if ($request['facturado'] == '1') { //facturado 
                if ($facturado == "Facturado") {
                    if ($orden != null) {

                        if ($orden->estado == 0) {
                        } else {
                            $data_arr[] = array(
                                "fecha" => $id,
                                "descripcion" => $record->descripcion,
                                "tipo" => $xdata,
                                "valor" => $record->valor,
                                "saldo" => $record->saldo,
                                "orden" => $orden,
                                "id_orden" => $id_orden,
                                "dataEfectivo" => $dataEfectivo,
                                "dataCheque" => $dataCheque,
                                "dataDeposito" => $dataDeposito,
                                "dataTransferencia" => $dataTransferencia,
                                "dataTarjetaCredito" => $dataTarjetaCredito,
                                "dataTarjetaDebito" => $dataTarjetaDebito,
                                "dataPendientePago" => $dataPendientePago,
                                "forma_pago" => $forma_pago,
                                "paciente" => $nombre,
                                "seguro" => $nseguro,
                                "numero" => $orden->comprobante,
                                "facturado" => $facturado,
                                "usuario" => $usuario->apellido1 . ' ' . $usuario->apellido2 . ' ' . $usuario->nombre1,
                                "oda" => $orden->total_con_oda,
                            );
                        }
                    } else {
                        $orden = [];
                        $forma_pago = [];
                        if ($xdata == "Inicio de caja") {
                            $dataEfectivo = $record->valor;
                        }
                        if ($xdata == "Cierre de caja") {
                            $dataEfectivo = $record->valor;
                        }

                        $dataPendientePago = 0.00;
                        $dataTarjetaDebito = 0.00;
                        $dataTransferencia = 0.00;
                        $dataDeposito = 0.00;
                        $dataCheque = 0.00;
                        $data_arr[] = array(
                            "fecha" => $id,
                            "descripcion" => $record->descripcion,
                            "tipo" => $xdata,
                            "id_orden" => $id_orden,
                            "valor" => $record->valor,
                            "saldo" => $record->saldo,
                            "dataEfectivo" => $dataEfectivo,
                            "dataCheque" => $dataCheque,
                            "dataDeposito" => $dataDeposito,
                            "dataTransferencia" => $dataTransferencia,
                            "dataTarjetaCredito" => $dataTarjetaCredito,
                            "dataTarjetaDebito" => $dataTarjetaDebito,
                            "dataPendientePago" => $dataPendientePago,
                            "orden" => $orden,
                            "forma_pago" => $forma_pago,
                            "paciente" => $nombre,
                            "seguro" => $nseguro,
                            "facturado" => $facturado,
                            "numero" => "",
                            "oda" => 0.00,
                            "usuario" => $usuario->apellido1 . ' ' . $usuario->apellido2 . ' ' . $usuario->nombre1,
                        );
                    }
                }
            } elseif ($request['facturado'] == '2') { // no facturado
                if ($facturado == "No Facturado") {
                    if ($orden != null) {
                        if ($orden->estado == 0) {
                        } else {
                            $data_arr[] = array(
                                "fecha" => $id,
                                "descripcion" => $record->descripcion,
                                "tipo" => $xdata,
                                "valor" => $record->valor,
                                "saldo" => $record->saldo,
                                "orden" => $orden,
                                "id_orden" => $id_orden,
                                "dataEfectivo" => $dataEfectivo,
                                "dataCheque" => $dataCheque,
                                "dataDeposito" => $dataDeposito,
                                "dataTransferencia" => $dataTransferencia,
                                "dataTarjetaCredito" => $dataTarjetaCredito,
                                "dataTarjetaDebito" => $dataTarjetaDebito,
                                "dataPendientePago" => $dataPendientePago,
                                "forma_pago" => $forma_pago,
                                "paciente" => $nombre,
                                "seguro" => $nseguro,
                                "numero" => $orden->comprobante,
                                "facturado" => $facturado,
                                "usuario" => $usuario->apellido1 . ' ' . $usuario->apellido2 . ' ' . $usuario->nombre1,
                                "oda" => $orden->total_con_oda,
                            );
                        }
                    } else {
                        $orden = [];
                        $forma_pago = [];
                        if ($xdata == "Inicio de caja") {
                            $dataEfectivo = $record->valor;
                        }
                        if ($xdata == "Cierre de caja") {
                            $dataEfectivo = $record->valor;
                        }

                        $dataPendientePago = 0.00;
                        $dataTarjetaDebito = 0.00;
                        $dataTransferencia = 0.00;
                        $dataDeposito = 0.00;
                        $dataCheque = 0.00;
                        $data_arr[] = array(
                            "fecha" => $id,
                            "descripcion" => $record->descripcion,
                            "tipo" => $xdata,
                            "id_orden" => $id_orden,
                            "valor" => $record->valor,
                            "saldo" => $record->saldo,
                            "dataEfectivo" => $dataEfectivo,
                            "dataCheque" => $dataCheque,
                            "dataDeposito" => $dataDeposito,
                            "dataTransferencia" => $dataTransferencia,
                            "dataTarjetaCredito" => $dataTarjetaCredito,
                            "dataTarjetaDebito" => $dataTarjetaDebito,
                            "dataPendientePago" => $dataPendientePago,
                            "orden" => $orden,
                            "forma_pago" => $forma_pago,
                            "paciente" => $nombre,
                            "seguro" => $nseguro,
                            "facturado" => $facturado,
                            "numero" => "",
                            "oda" => 0.00,
                            "usuario" => $usuario->apellido1 . ' ' . $usuario->apellido2 . ' ' . $usuario->nombre1,
                        );
                    }
                }
            } elseif ($request['facturado']==null) {
                if ($orden != null) {

                    if ($orden->estado == 0) {
                        
                    } else {
                        if($idusuario=='1316262193'){
                            if($contador==32){
                                //dd($records);
                            }
                        }
                        $data_arr[] = array(
                            "fecha" => $id,
                            "descripcion" => $record->descripcion,
                            "tipo" => $xdata,
                            "valor" => $record->valor,
                            "saldo" => $record->saldo,
                            "orden" => $orden,
                            "id_orden" => $id_orden,
                            "dataEfectivo" => $dataEfectivo,
                            "dataCheque" => $dataCheque,
                            "dataDeposito" => $dataDeposito,
                            "dataTransferencia" => $dataTransferencia,
                            "dataTarjetaCredito" => $dataTarjetaCredito,
                            "dataTarjetaDebito" => $dataTarjetaDebito,
                            "dataPendientePago" => $dataPendientePago,
                            "forma_pago" => $forma_pago,
                            "paciente" => $nombre,
                            "seguro" => $nseguro,
                            "numero" => $orden->comprobante,
                            "facturado" => $facturado,
                            "usuario" => $usuario->apellido1 . ' ' . $usuario->apellido2 . ' ' . $usuario->nombre1,
                            "oda" => $orden->total_con_oda,
                        );
                    }
                } else {
                    $orden = [];

                    $forma_pago = [];
                    if ($xdata == "Inicio de caja") {
                        $dataEfectivo = $record->valor;
                    }
                    if ($xdata == "Cierre de caja") {
                        $dataEfectivo = $record->valor;
                    }

                    $dataPendientePago = 0.00;
                    $dataTarjetaDebito = 0.00;
                    $dataTransferencia = 0.00;
                    $dataDeposito = 0.00;
                    $dataCheque = 0.00;
                    $data_arr[] = array(
                        "fecha" => $id,
                        "descripcion" => $record->descripcion,
                        "tipo" => $xdata,
                        "id_orden" => $id_orden,
                        "valor" => $record->valor,
                        "saldo" => $record->saldo,
                        "dataEfectivo" => $dataEfectivo,
                        "dataCheque" => $dataCheque,
                        "dataDeposito" => $dataDeposito,
                        "dataTransferencia" => $dataTransferencia,
                        "dataTarjetaCredito" => $dataTarjetaCredito,
                        "dataTarjetaDebito" => $dataTarjetaDebito,
                        "dataPendientePago" => $dataPendientePago,
                        "orden" => $orden,
                        "forma_pago" => $forma_pago,
                        "paciente" => $nombre,
                        "seguro" => $nseguro,
                        "facturado" => $facturado,
                        "numero" => "",
                        "oda" => 0.00,
                        "usuario" => $usuario->apellido1 . ' ' . $usuario->apellido2 . ' ' . $usuario->nombre1,
                    );
                }
               
            }
            $contador++;
        }

        //dd($d
        $response = array(
            "draw" => intval($draw),
            "contador" => $contador,
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordswithFilter,
            "aaData" => $data_arr
        );
       

        echo json_encode($response);
        exit;
    }
    public function modalforma($id, Request $request)
    {
        if (!is_null($id)) {
            $forma_pago = Examen_Detalle_Forma_Pago::where('id_examen_orden', $id)->get();
            $tipo_pago = Ct_Tipo_Pago::all();
            $bancos = Ct_Bancos::all();
            $tipo_tarjeta = Ct_Tipo_Tarjeta::all();
            return view('contable.cierre_caja.modalforma', ['formapago' => $forma_pago, 'tipo_pago' => $tipo_pago, 'lista_banco' => $bancos, 'tipo_tarjeta' => $tipo_tarjeta]);
        } else {
            return response()->json("error");
        }
    }
    public function redirecciona($id, $valida)
    {
        $orden = Examen_Orden::find($id);

        //$usuarios = User::where('id_tipo_usuario', '3')->where('estado', '1')->where('training', '<>', '1')->orderBy('nombre1')->get();
        //file:///Users/macbook/Downloads/vuexy-admin-6.5/vuexy-admin-v6.5/html-version/vuexy-html-bootstrap-admin-template/html/ltr/horizontal-menu-template/index.html
        $usuarios = User::where('id_tipo_usuario', '3')->where('estado', '1')->orderBy('apellido1')->where('uso_laboratorio', '1')->get();

        $formas = DB::table('forma_de_pago')->where('estado', '1')->get();
        //dd($formas);
        $examenes = Examen::orderBy('id_agrupador')->get();
        //dd($examenes);
        $agrupadores = Examen_Agrupador::where('estado', '1')->get();
        $seguros1    = DB::table('seguros as s')->where('s.inactivo', '1')->where('s.tipo', '>', '1')->orderBy('s.nombre');
        $seguros2    = DB::table('seguros as s')->where('s.inactivo', '1')->where('s.tipo', '>', '0')->join('convenio as c', 'c.id_seguro', 's.id')->select('s.*')->orderBy('s.nombre');
        $seguros     = $seguros1->union($seguros2)->get();
        $protocolos  = Protocolo::where('estado', '1')->get();
        $protocolos2 = Protocolo::where('estado', '3')->get();
        $codigo      = Labs_doc_externos::where('estado', '1')->get();

        $empresas = DB::table('empresa as e')->where('e.estado', '1')->join('convenio as c', 'c.id_empresa', 'e.id')->select('e.id', 'e.nombrecomercial')->groupBy('e.id', 'e.nombrecomercial')->get();
        if ($valida == 0) {
            /*return view('laboratorio/orden/create_particular',['usuarios' => $usuarios, 'examenes' => $examenes, 'agrupadores' => $agrupadores, 'seguros' => $seguros, 'protocolos' => $protocolos, 'empresas' => $empresas]);*/
            return view('laboratorio/orden/editar_cotizacion', ['usuarios' => $usuarios, 'examenes' => $examenes, 'agrupadores' => $agrupadores, 'seguros' => $seguros, 'empresas' => $empresas, 'orden' => $orden, 'formas' => $formas, 'protocolos' => $protocolos, 'codigo' => $codigo, 'protocolos2' => $protocolos2]);
        } else {
            return view('contable/cierre_caja/editforma', ['usuarios' => $usuarios, 'examenes' => $examenes, 'agrupadores' => $agrupadores, 'seguros' => $seguros, 'empresas' => $empresas, 'orden' => $orden, 'formas' => $formas, 'protocolos' => $protocolos, 'codigo' => $codigo, 'protocolos2' => $protocolos2]);
        }
    }
    public function storenew($id, Request $request)
    {
        //funcion para guardar
        $mes = $request['mes'];
        $anio = $request['anio'];
        $validar = Examen_Orden::whereMonth('mes', $mes)->whereYear('anio', $anio)->where('estado', '1')->first();
        if (is_null($validar)) {
            $ip_cliente = $_SERVER["REMOTE_ADDR"];
            $idusuario  = Auth::user()->id;
            $fecha_as   = $request['fecha_asiento'];
            $id_empresa = $request->session()->get('id_empresa');
            $c_sucursal      = 0;
            $c_caja          = 0;
            $num_comprobante = 0;
            $nfactura        = 0;
            $proced          = $request['procedimiento'];
            $pac             = "";
            $id_asiento_cabecera = 0;
            $ver = Ct_Ven_Orden::where('orden_venta', $request['orden_venta'])->where('tipo', 'VEN-LABS')->first();
            if (is_null($ver)) {
                $factura_venta = [
                    'sucursal'            => $c_sucursal,
                    'punto_emision'       => $c_caja,
                    'numero'              => $nfactura,
                    'nro_comprobante'     => $request['numero_comprobante'], //numero de comprobante
                    'id_empresa'          => $request['empresa'], // id_empresa 
                    'tipo'                => $request['tipo'], // es un campo varchar puede ser VEN-LABS
                    'fecha'               => $request['fecha_asiento'], //fecha de envio
                    'divisas'             => $request['divisas'], // clavale uno
                    'nombre_cliente'      => $request['nombre_cliente'], // nombre del cliente en varchar
                    'tipo_consulta'       => $request['tipo_consulta'], // este puede ser 1 o 0 consulta o procedimiento 
                    'id_cliente'          => $request['identificacion_cliente'], //identificacion del cliente
                    'direccion_cliente'   => $request['direccion_cliente'], //direccion del cliente
                    'telefono_cliente'    => $request['telefono_cliente'], // telefono del cliente
                    'email_cliente'       => $request['mail_cliente'], //mail del cliene
                    'orden_venta'         => $request['orden_venta'], //el numero de orden, el id de la orden de laboratorio
                    'estado_pago'         => '0', // default 0 
                    'id_paciente'         => $request['identificacion_paciente'], // datos del paciente
                    'nombres_paciente'    => $request['nombre_paciente'], //nombre del paciente
                    'seguro_paciente'     => $request['id_seguro'], //seguro del paciente
                    'copago'              => $request['copago'], // valor copago del paciente
                    'id_recaudador'       => $request['cedula_recaudador'], //recaudador pero no es requerido
                    'ci_vendedor'         => $request['cedula_vendedor'], // id del recuadador 
                    'vendedor'            => $request['vendedor'], // vendedor pero no es requerido
                    'subtotal_0'          => $request['subtotal_0'], //subtotal 0
                    'subtotal_12'         => $request['subtotal_12'], //subtotal 12
                    'descuento'           => $request['descuento'], // descuento 
                    'base_imponible'      => $request['subtotal'], //subtotal
                    'impuesto'            => $request['tarifa_iva'], // el valor del iva
                    'total_final'         => $request['total'], //total de la factura
                    'ip_creacion'         => "vic",
                    'ip_modificacion'     => $ip_cliente,
                    'id_usuariocrea'      => $idusuario,
                    'id_usuariomod'       => $idusuario,
                ];

                // return $factura_venta;

                $id_venta = Ct_Ven_Orden::insertGetId($factura_venta);
                //$id_venta = 0;
                $arr_total      = [];
                $total_iva      = 0;
                $total_impuesto = 0;
                $total_0        = 0;

                for ($i = 0; $i < count($request->input("nombre")); $i++) {
                    if ($request->input("nombre")[$i] != "" || $request->input("nombre")[$i] != null) {
                        $arr = [
                            'nombre'     => $request->input("nombre")[$i],
                            'cantidad'   => $request->input("cantidad")[$i],
                            'codigo'     => $request->input("codigo")[$i],
                            'precio'     => $request->input("precio")[$i],
                            'descpor'    => $request->input("descpor")[$i],
                            'copago'     => $request->input("copago")[$i],
                            'descuento'  => $request->input("desc")[$i],
                            'precioneto' => $request->input("precioneto")[$i],
                            'detalle'    => $request->input("descrip_prod")[$i],
                            'iva'        => $request->input("iva")[$i],

                        ];
                        array_push($arr_total, $arr);
                    }
                }
                foreach ($arr_total as $valor) {
                    $detalle = [
                        'id_ct_ven_orden'      => $id_venta,
                        'id_ct_productos'      => $valor['codigo'],
                        'nombre'               => $valor['nombre'],
                        'cantidad'             => $valor['cantidad'],
                        'precio'               => $valor['precio'],
                        'descuento_porcentaje' => $valor['descpor'],
                        'descuento'            => $valor['descuento'],
                        'extendido'            => $valor['copago'],
                        'detalle'              => $valor['detalle'],
                        'copago'               => $valor['precioneto'],
                        'check_iva'            => $valor['iva'],
                        'ip_creacion'          => $ip_cliente,
                        'ip_modificacion'      => $ip_cliente,
                        'id_usuariocrea'       => $idusuario,
                        'id_usuariomod'        => $idusuario,
                    ];

                    Ct_Ven_Orden_Detalle::create($detalle);
                }
                return response()->json(['success' => '1', 'id_orden' => $id_venta]);
            }
            return response()->json(['success' => '1', 'id_orden' => '0']);
        } else {
            return response()->json(['success' => '1', 'id_orden' => '0']);
        }
    }

    public function pago_en_linea_contab($id)
    {

        $ip_cliente      = $_SERVER["REMOTE_ADDR"];
        $idusuario       = Auth::user()->id;
        //PAGO 1 - ESTADO PAGO 1 - PAGO ONLINE 1 - COMPROBANTE NULL - FECHA ENVIO NULL
        $orden = Examen_Orden::find($id);

        $data            = array();
        $cliente         = array();
        $direccion       = array();
        $producto        = array();
        $info_adicional  = array();
        $pago            = array();
        $info            = array();
        $tipos_pago      = array();
        $productos       = array();

        $pagoonline = DB::table('pagosenlinea')->where('clave', $orden->id)->first();
        if (!is_null($pagoonline)) {
            if ($pagoonline->nro_comprobante != null) {

                $datavh['empresa']      = '0993075000001';
                $datavh['tipo']         = 'comprobante';
                $datavh['comprobante']  = $pagoonline->nro_comprobante;

                $comprascontroller = new ComprasController();
                $finaly            = json_decode($comprascontroller->estado_comprobante($datavh), true);
                $f_emision         = $finaly['details']['fecha'];
                $f_emision         = date('Y-m-d H:i:s', strtotime($f_emision));

                $data['empresa']      = '0993075000001';
                $data['fecha']        = date('Y-m-d ', strtotime($f_emision)); //ESTA FECHA ES LA DE EMISION
                $data['electronica']  = '1';

                $cliente['cedula']    = $orden->cedula_factura;

                $cliente['tipo']     = '6'; //eduardo dice q el lo calcula y luego se
                if (strlen($orden->cedula_factura) == 13 && substr($orden->cedula_factura, -3) == '001') {
                    $cliente['tipo'] = '4';
                } elseif (strlen($orden->cedula_factura) == 10) {
                    $cliente['tipo'] = '5';
                }

                $cliente['nombre']    = $orden->nombre_factura;
                $cliente['apellido']  = '';

                $explode              = explode(" ", $orden->nombre_factura);
                if (count($explode) >= 4) {
                    $cliente['nombre']    = $explode[0] . ' ' . $explode[1];
                    for ($i = 2; $i < count($explode); $i++) {
                        $cliente['apellido']  = $cliente['apellido'] . ' ' . $explode[$i];
                    }
                }
                if (count($explode) == 3) {
                    $cliente['nombre']    = $explode[0];
                    $cliente['apellido']  = $explode[1] . ' ' . $explode[2];
                }
                if (count($explode) == 2) {
                    $cliente['nombre']    = $explode[0];
                    $cliente['apellido']  = $explode[1];
                }
                //dd($cliente);
                $cliente['email']     = $orden->email_factura;
                $cliente['telefono']  = $orden->telefono_factura;
                $direccion['calle']   = $orden->direccion_factura;
                $direccion['ciudad']  = $orden->ciudad_factura;
                $cliente['direccion'] = $direccion;
                $cliente['nro_autorizacion'] = null;
                $data['cliente']      = $cliente;

                $msn_error = '';
                $flag_error = false;
                if ($cliente['cedula'] == null) {
                    $flag_error = true;
                    $msn_error = 'Error en cedula';
                }

                if ($cliente['nombre'] == null) {
                    $flag_error = true;
                    $msn_error = 'Error en Nombre';
                }
                if ($cliente['email'] == null) {
                    $flag_error = true;
                    $msn_error = 'Error en email';
                }
                if ($cliente['telefono'] == null) {
                    $flag_error = true;
                    $msn_error = 'Error en telefono';
                }
                if ($direccion['calle'] == null) {
                    $flag_error = true;
                    $msn_error = 'Error en calle';
                }
                if ($direccion['ciudad'] == null) {
                    //$flag_error=true;
                    //$msn_error='Error en Ciudad';
                    $direccion['ciudad'] = 'GUAYAQUIL';
                }

                $cant = 0;
                foreach ($orden->detalles as $value) {
                    //se envian los productos
                    $producto['sku']       = "LABS-" . $value->examen->id; //ID EXAMEN
                    $producto['nombre']    = $value->examen->nombre; // NOMBRE DEL EXAMEN
                    $producto['cantidad']  = "1";
                    $producto['precio']    = $value->valor; //DETALLE
                    $producto['descuento'] = $value->valor_descuento;
                    $producto['subtotal']  = $value->valor - $value->valor_descuento; //precio-descuento
                    $producto['tax']       = "0";
                    $producto['total']     = $value->valor - $value->valor_descuento; //SUBTOTAL
                    $producto['copago']    = "0";
                    $productos[$cant] = $producto;
                    $cant++;
                }

                $data['productos'] = $productos;
                /*01  SIN UTILIZACION DEL SISTEMA FINANCIERO
                15  COMPENSACIÓN DE DEUDAS
                16  TARJETA DE DÉBITO
                17  DINERO ELECTRÓNICO
                18  TARJETA PREPAGO
                19  TARJETA DE CRÉDITO
                20  OTROS CON UTILIZACION DEL SISTEMA FINANCIERO
                21  ENDOSO DE TÍTULOS
                */
                $info_adicional['nombre']      = "AGENTES_RETENCION";
                $info_adicional['valor']       = "Resolucion 1";
                $info[0]                       = $info_adicional;

                $info_adicional['nombre']      = "PACIENTE";
                $info_adicional['valor']       = $orden->id_paciente . ' ' . $orden->paciente->apellido1 . ' ' . $orden->paciente->nombre1;
                $info[1]                       = $info_adicional;

                $info_adicional['nombre']      = "MAIL";
                $info_adicional['valor']       = $orden->email_factura; //EMAIL
                $info[2]                       = $info_adicional;

                $info_adicional['nombre']      = "CIUDAD";
                $info_adicional['valor']       = $orden->ciudad_factura; //EMAIL
                $info[3]                       = $info_adicional;

                $info_adicional['nombre']      = "DIRECCION";
                $info_adicional['valor']       = $orden->direccion_factura; //EMAIL
                $info[4]                       = $info_adicional;

                $info_adicional['nombre']      = "ORDEN";
                $info_adicional['valor']       = '' . $orden->id . ''; //EMAIL
                $info[5]                       = $info_adicional;

                $info_adicional['nombre']      = "SEGURO";
                $info_adicional['valor']       = $orden->seguro->nombre; //SEGURO
                $info[6]                       = $info_adicional;

                $info_adicional['nombre']      = "FORMA_PAGO";
                $info_adicional['valor']       = '';
                $info[7]                       = $info_adicional;

                $pago['forma_pago']            = '01';
                $pago['informacion_adicional'] = $info;
                $pago['dias_plazo']            = '10';
                $data['pago']                  = $pago;
                $data['contable']              = 1; //si se marca 1 crea factura, 0 no crea factura
                $data['laboratorio']           = 1;
                $data['paciente']              = $orden->id_paciente;
                $data['concepto']              = 'Ingreso de Factura Electronica por Pago en Linea';
                $data['copago']                = 0;
                $data['id_seguro']             = '1'; //si se marca 1 se crea un solo producto por id de laboratorioo, 0 graba detalle de datos
                $data['total_factura']         = $orden->total_valor;

                $tipos_pago['id_tipo']            = 5; //metodo de pago efectivo, tarjeta, etc
                $tipos_pago['fecha']              = substr($orden->fecha_orden, 0, 10);
                $tipos_pago['tipo_tarjeta']       = null; //si es efectivo no se envia
                $tipos_pago['numero_transaccion'] = $pagoonline->pago_auth; //si es efectivo no se envia
                $banco = Ct_Bancos::where('nombre', $pagoonline->issuer)->first();
                $id_banco = '1';
                if (!is_null($banco)) {
                    $id_banco = $banco->id;
                }
                $tipos_pago['id_banco']           = $id_banco; //si es efectivo no se envia
                $tipos_pago['cuenta']             = $pagoonline->credittype . '-' . $pagoonline->paymentmethod; //si es efectivo no se envia
                $tipos_pago['giradoa']            = null; //si es efectivo no se envia
                $tipos_pago['valor']              = $orden->total_valor; //valor a pagar de total
                $tipos_pago['valor_base']         = $orden->total_valor; //valor a pagar de base
                $pagos['tipos_pago']              = $tipos_pago;
                $data['formas_pago']              = $pagos;

                if ($orden->fecha_envio != null) {
                    $flag_error = true;
                    $msn_error = 'Ya enviado al SRI';
                }

                if ($flag_error) {
                    Log_usuario::create([
                        'id_usuario'  => $idusuario,
                        'ip_usuario'  => $ip_cliente,
                        'descripcion' => "LABORATORIO",
                        'dato_ant1'   => $orden->id,
                        'dato1'       => $orden->id_paciente,
                        'dato_ant2'   => "ERROR FACTURA PAGO EN LINEA",
                        'dato_ant4'   => $msn_error,
                    ]);
                    return "error";
                }

                $orden->update([
                    'fecha_envio' => date('Y-m-d H:i:s'),
                ]);

                $valid = CierreCaja::whereDate('fecha', $orden->fecha_orden)->where('tipo', '4')->first();
                if (is_null($valid)) {
                    $idcierre = CierreCaja::insertGetid([
                        'fecha' => date('Y-m-d H:m:s'),
                        'tipo' => '1',
                        'id_paciente' => $orden->paciente->id,
                        'id_seguro' => $orden->seguro->id,
                        'descripcion' => 'El examen orden : ' . $orden->id . ' paciente: ' . $orden->paciente->apellido1 . ' ' . $orden->paciente->nombre1,
                        'valor' => $orden->total_valor,
                        'saldo' => $orden->total_valor,
                        'id_orden' => $orden->id,
                        'estado' => '1',
                        'ip_creacion'     => $ip_cliente,
                        'ip_modificacion' => $ip_cliente,
                        'id_usuariocrea'  => $idusuario,
                        'id_usuariomod'   => $idusuario,
                    ]);
                }

                //dd($data);
                $envio = ApiFacturacionController::crea_factura_noelec($data, $pagoonline->nro_comprobante);

                $orden->update([
                    'comprobante' => $pagoonline->nro_comprobante,
                    'fecha_envio' => date('Y-m-d H:i:s'),
                ]);

                Log_usuario::create([
                    'id_usuario'  => $idusuario,
                    'ip_usuario'  => $ip_cliente,
                    'descripcion' => "LABORATORIO",
                    'dato_ant1'   => $orden->id,
                    'dato1'       => $orden->id_paciente,
                    'dato_ant2'   => "FACTURA PAGO EN LINEA",
                    'dato_ant4'   => $pagoonline->nro_comprobante,
                ]);
            }
        }

        return response()->json("ok");
    }
    public function getUserByCierre(Request $request)
    {
        $productos = [];
        if ($request['search'] != null) {
            $types = ['1', '10', '12', '5'];
            $productos = User::whereIn('id_tipo_usuario', $types)->where('estado', '1')->whereRaw("CONCAT_WS(' ', nombre1, nombre2, apellido1, apellido2) like '%" . $request['search'] . "%' ")->select(DB::raw('CONCAT_WS(" ", nombre1, " " , nombre2, " ", apellido1," ",apellido2) as text'), 'id as id')->get();
        }

        return response()->json($productos);
    }
    public function cierre_caja_modal($id, $today, Request $request)
    {
        $records = CierreCaja::where('cierre_caja.estado', '1')
            ->leftjoin('examen_detalle_forma_pago as ep', 'ep.id_examen_orden', 'cierre_caja.id_orden')
            ->whereDate('cierre_caja.fecha', $today)
            ->where('cierre_caja.id_usuariocrea', $id)
            ->select('cierre_caja.*')
            ->distinct('cierre_caja.id_orden')
            ->get();
        $total = 0;
        foreach ($records as $record) {
            $ids = date('d/m/Y H:i:s', strtotime($record->fecha));
            $orden = Examen_Orden::find($record->id_orden);
            $forma_pago = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->get();
            $xdata = "";
            $dataEfectivo = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '1')->sum('valor');
            $dataCheque = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '2')->sum('valor');
            $dataDeposito = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '3')->sum('valor');
            $dataTarjetaCredito = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '4')->sum('p_fi');
            $dataTransferencia = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '5')->sum('valor');
            //$dataTarjetaDebito = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '6')->sum('p_fi');
            $dataPendientePago = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '7')->sum('valor');
            $paciente = Paciente::find($record->id_paciente);
            $usuario = User::find($record->id_usuariocrea);
            $seguro = null;
            if (!is_null($orden)) {
                $seguro = Seguro::find($orden->id_seguro);
                $paciente = Paciente::find($orden->id_paciente);
                $id_orden = $orden->id;
                    //tuve que setear los valores de esta manera por el valor
                    $dataTarjetaCredito = $orden->total_valor;
               
                    //tuve que setear los valores de esta manera por equivocacion martes 20 de julio del 2021
                    $dataTarjetaDebito = $orden->total_valor;
                
            }
            $nseguro = "";
            if (!is_null($seguro)) {
                $nseguro = $seguro->nombre;
            }
            
            $facturado = "No Facturado";
            if ($orden != null) {
                if ($orden->comprobante != null && $orden->fecha_envio != null) {
                    $facturado = "Facturado";
                }
                if ($orden->seguro->tipo == 0) {
                    if ($dataPendientePago == 0) {
                        $facturado = "Orden Publica";
                        $dataPendientePago = $orden->total_valor;
                    }
                }
            } else {
                if ($record->tipo == '4') {
                    $facturado = "Cierre Caja";
                } else if ($record->tipo == '0') {
                    $facturado = "Inicio de Caja";
                }
            }

            $nombre = "";
            if (!is_null($paciente)) {
                $nombre = $paciente->apellido1 . ' ' . $paciente->apellido2 . ' ' . $paciente->nombre1;
            } else {
            }
            if ($record->tipo == '0') {
                $xdata = "Inicio de caja";
            } elseif ($record->tipo == '1') {
                $xdata = "Ingreso de caja";
            } elseif ($record->tipo == '2') {
                $xdata = "Salida de caja";
            } elseif ($record->tipo == '4') {
                $xdata = "Cierre de caja";
            }
            if ($xdata == "Inicio de caja") {
                $dataEfectivo = $record->saldo;
            }
            if ($xdata == "Cierre de caja") {
                $dataEfectivo = $record->saldo;
            }
            $total += $dataEfectivo + $dataCheque + $dataDeposito + $dataTarjetaCredito + $dataTransferencia + $dataTarjetaDebito + $dataPendientePago;
        }
        return view('contable/cierre_caja/modal_cierre', ['valor' => $total]);
    }
    public function getLast($id, $today, Request $request){
        $records = CierreCaja::where('cierre_caja.estado', '1')
        ->leftjoin('examen_detalle_forma_pago as ep', 'ep.id_examen_orden', 'cierre_caja.id_orden')
        ->whereDate('cierre_caja.fecha', $today)
        ->where('cierre_caja.id_usuariocrea', $id)
        ->select('cierre_caja.*')
        ->distinct('cierre_caja.id_orden')
        ->get();
        $total = 0;
        $dataEfectivo=0;
        $dataCheque=0;
        $dataDeposito=0;
        $dataTarjetaCredito=0;
        $dataTarjetaDebito=0;
        $dataPendientePago=0;
        $dataTransferencia=0;
        foreach ($records as $record) {
            $ids = date('d/m/Y H:i:s', strtotime($record->fecha));
            $orden = Examen_Orden::find($record->id_orden);
            $forma_pago = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->get();
            $xdata = "";
            $dataEfectivo += Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '1')->sum('valor');
            $dataCheque += Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '2')->sum('valor');
            $dataDeposito += Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '3')->sum('valor');
            $dataTarjetaCredito2= Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '4')->sum('p_fi');
            $dataTransferencia += Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '5')->sum('valor');
            $dataTarjetaDebito2 = Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '6')->sum('p_fi');
            $dataPendientePago += Examen_Detalle_Forma_Pago::where('id_examen_orden', $record->id_orden)->where('id_tipo_pago', '7')->sum('valor');
            if (!is_null($orden)) {
                $seguro = Seguro::find($orden->id_seguro);
                $paciente = Paciente::find($orden->id_paciente);
                $id_orden = $orden->id;
                if ($dataTarjetaCredito2 > 0) {
                    //tuve que setear los valores de esta manera por el valor
                    $dataTarjetaCredito += $orden->total_valor;
                }
                if ($dataTarjetaDebito2 > 0) {
                    //tuve que setear los valores de esta manera por equivocacion martes 20 de julio del 2021
                    $dataTarjetaDebito += $orden->total_valor;
                }
            }
            if ($orden != null) {
                if ($orden->comprobante != null && $orden->fecha_envio != null) {
                    $facturado = "Facturado";
                }
                if ($orden->seguro->tipo == 0) {
         
                        $facturado = "Orden Publica";
                        $dataPendientePago += $orden->total_valor;
                    
                }
            } else {
                if ($record->tipo == '4') {
                    $facturado = "Cierre Caja";
                } else if ($record->tipo == '0') {
                    $facturado = "Inicio de Caja";
                }
            }

            $total += $dataEfectivo + $dataCheque + $dataDeposito + $dataTarjetaCredito + $dataTransferencia + $dataTarjetaDebito + $dataPendientePago;
        }
        $arraySend['efectivo']=$dataEfectivo;
        $arraySend['cheque']=$dataCheque;
        $arraySend['deposito']=$dataDeposito;
        $arraySend['credito']=$dataTarjetaCredito;
        $arraySend['debito']=$dataTarjetaDebito;
        $arraySend['pendiente']=$dataPendientePago;
        $arraySend['transferencia']=$dataTransferencia;
        $arraySend['total']=$total;
        return $arraySend;
    }
}
