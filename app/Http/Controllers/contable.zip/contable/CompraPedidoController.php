<?php

namespace Sis_medico\Http\Controllers\contable;

use Sis_medico\Http\Controllers\Controller;
use Response;
use Illuminate\Support\Facades\DB;
use Sis_medico\Ct_pedidos_Compra;
use Sis_medico\Proveedor;
use Sis_medico\Ct_master_tipos;
use Sis_medico\Ct_Asientos_Detalle;
use Sis_medico\Empresa;
use Illuminate\Http\Request;
use Sis_medico\Ct_Bodegas;
use Sis_medico\Ct_productos;
use Sis_medico\Ct_Configuraciones;
use Illuminate\Support\Facades\Auth;
use Sis_medico\Validate_Decimals;
use Sis_medico\Ct_Asientos_Cabecera;
use Sis_medico\Ct_Kardex;
use Sis_medico\Ct_Termino;
use Sis_medico\Plan_Cuentas;
use Sis_medico\Ct_Asientos_Pedido;
use Sis_medico\ct_Detalle_Pedido;
use Sis_medico\Ct_Acreedores;

class CompraPedidoController extends Controller
{
    /**
     * Show the profile for a given user.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $id_empresa       = $request->session()->get('id_empresa');
        return view('contable.compras_pedidos.index', [
            'pedidos' => Ct_pedidos_Compra::whereIn('estado', ['0', '1'])->paginate(10), 'proveedor' => Proveedor::all(), 'tipo_comprobante' => ct_master_tipos::where('estado', '1')->where('tipo', '1')->get(), 'empresa' => Empresa::where('id', $id_empresa)->where('estado', '1')->first()
        ]);
    }

    public function create(Request $request)
    {
        $id_empresa       = $request->session()->get('id_empresa');
        return view('contable.compras_pedidos.create', ['empresa' => Empresa::where('id', $id_empresa)->where('estado', '1')->first(), 'proveedor' => Proveedor::all(), 'bodega' => Ct_Bodegas::where('estado', '1')->where('id_empresa', $id_empresa)->get(), 'productos' => $productos = Ct_productos::where('id_empresa', $id_empresa)->get(), 'iva_param' => Ct_Configuraciones::where('id_plan', '4.1.01.02')->first()]);
    }

    public function store(Request $request)
    {
        $ip_cliente      = $_SERVER["REMOTE_ADDR"];
        $id_empresa      = $request->session()->get('id_empresa');
        $idusuario       = Auth::user()->id;
        $objeto_validar  = new Validate_Decimals();
        $errores         = "";
        $iva_param       = Ct_Configuraciones::where('id_plan', '4.1.01.02')->first();
        $punto_emision   = $request['serie'];
        $sucursal        = substr($punto_emision, 0, -4);
        $punto_emision   = substr($punto_emision, 4);
        $empresa = Empresa::find($id_empresa);
        $total_final     = $objeto_validar->set_round($request['total1']);
        $numero_factura = 0;
        $contador_ctv    = DB::table('ct_pedidos_compra')->where('id_empresa', $id_empresa)->where('sucursal', $sucursal)
            ->where('punto_emision', $punto_emision)->get()->count();
        $numero_factura = 0;
        if ($contador_ctv == 0) {
            $num            = '1';
            $numero_factura = str_pad($num, 10, "0", STR_PAD_LEFT);
        } else {

            //Obtener Ultimo Registro de la Tabla ct_compras pedido
            $max_id = DB::table('ct_pedidos_compra')->where('id_empresa', $id_empresa)->where('sucursal', $sucursal)->where('punto_emision', $punto_emision)->latest()->first();
            $max_id = intval($max_id->secuencia_f);
            //dd(strlen($max_id));
            if (strlen($max_id) < 10) {
                $nu             = $max_id + 1;
                $numero_factura = str_pad($nu, 10, "0", STR_PAD_LEFT);
            }
        }
        $fechahoy  = date("Y-m-d");
        $numeroconcadenado   = $request['serie'] . '-' . $request['secuencia_factura'];
        $comprobacion_compra = Ct_pedidos_Compra::where('numero', $numeroconcadenado)->where('tipo', '1')->where('proveedor', $request['proveedor'])->where('id_empresa', $id_empresa)->where('estado', '<>', '0')->first();
        if (is_null($comprobacion_compra) || $comprobacion_compra == '[]') {
            $cabeceraa = [
                'observacion'     => $request['observacion'],
                'fecha_asiento'   => $fechahoy,
                'fact_numero'     => $request['secuencia_factura'],
                'valor'           => $total_final,
                'id_empresa'      => $id_empresa,
                'estado'          => '1',
                'ip_creacion'     => $ip_cliente,
                'ip_modificacion' => $ip_cliente,
                'id_usuariocrea'  => $idusuario,
                'id_usuariomod'   => $idusuario,
            ];
            if ($empresa->id != '0992704152001') {
                $id_proveedor = $request['proveedor'];
                //$proveedor_find = Proveedor::find($id_proveedor);
                $proveedor_find = Ct_Acreedores::where('id_empresa', $id_empresa)->where('id_proveedor', $id_proveedor)->first();
                $cabeceraa  = [
                    'observacion'     => $proveedor_find->razonsocial . ' # ' . $numeroconcadenado,
                    'fecha_asiento'   => $fechahoy,
                    'fact_numero'     => $request['secuencia_factura'],
                    'valor'           => $total_final,
                    'id_empresa'      => $id_empresa,
                    'estado'          => '1',
                    'ip_creacion'     => $ip_cliente,
                    'ip_modificacion' => $ip_cliente,
                    'id_usuariocrea'  => $idusuario,
                    'id_usuariomod'   => $idusuario,
                ];
            }
            $id_asiento_cabecera = Ct_Asientos_Pedido::insertGetId($cabeceraa);
            $nueva_fecha         = null;


            $subtotalf = $request['base1'];
            $input     = [
                'tipo'                => '1',
                'id_asiento_cabecera' => $id_asiento_cabecera,
                'fecha'               => $fechahoy,
                'proveedor'           => $request['proveedor'],
                'direccion_proveedor' => $request['direccion_proveedor'],
                'sucursal'            => $sucursal,
                'punto_emision'       => $punto_emision,
                'valor_contable'      => $total_final,
                'secuencia_f'         => $numero_factura,
                'estado'              => '1',
                'autorizacion'        => $request['autorizacion'],
                'f_autorizacion'      => $request['f_autorizacion'],
                'serie'               => $request['serie'],
                'id_empresa'          => $id_empresa,
                'numero'              => $numeroconcadenado,
                'secuencia_factura'   => $request['secuencia_factura'],
                'observacion'         => $request['observacion'],
                'subtotal_0'          => $request['subtotal_01'],
                'subtotal_12'         => $request['subtotal_121'],
                'subtotal'            => $subtotalf,
                'descuento'           => $request['descuento1'],
                'iva_total'           => $request['tarifa_iva1'],
                'ice_total'           => $request['ice_final1'],
                'total_final'         => $total_final,
                'ip_creacion'         => $ip_cliente,
                'ip_modificacion'     => $ip_cliente,
                'id_usuariocrea'      => $idusuario,
                'id_usuariomod'       => $idusuario,
            ];
            $id_compra = Ct_pedidos_Compra::insertGetId($input);
            $arr_total = [];
            for ($i = 0; $i < count($request->input("nombre")); $i++) {
                if ($request->input("nombre")[$i] != "" || $request->input("nombre")[$i] != null) {
                    $arr = [
                        'nombre'     => $request->input("nombre")[$i],
                        'cantidad'   => $request->input("cantidad")[$i],
                        'bodega'     => $request->input("bodega")[$i],
                        'codigo'     => $request->input("codigo")[$i],
                        'precio'     => $request->input("precio")[$i],
                        'descpor'    => $request->input("descpor")[$i],
                        'copago'     => $request->input("copago")[$i],
                        'descuento'  => $request->input("desc")[$i],
                        'precioneto' => $request->input("precioneto")[$i],
                        'detalle'    => $request->input("descrip_prod")[$i],
                        'iva'        => $request->input("iva")[$i],

                    ];
                    array_push($arr_total, $arr);
                }
            }
            $cuentas_iva = [];
            foreach ($arr_total as $valor) {
                $consulta_product = Ct_productos::where('codigo', $valor['codigo'])->first();
                if (count($consulta_product) > 0) {
                    $cuentas_iva = $consulta_product->impuesto_iva_compras;
                }
                $detalle = [
                    'id_ct_compras_pedido'        => $id_compra,
                    'codigo'               => $valor['codigo'],
                    'nombre'               => $valor['nombre'],
                    'cantidad'             => $valor['cantidad'],
                    'precio'               => $valor['precio'],
                    'bodega'               => $valor['bodega'],
                    'descuento_porcentaje' => $valor['descpor'],
                    'estado'               => '1',
                    'descuento'            => $valor['descuento'],
                    'extendido'            => $valor['precioneto'],
                    'detalle'              => $valor['detalle'],
                    'iva'                  => $valor['iva'],
                    'porcentaje'           => $request['ivareal'],
                    'ip_creacion'          => $ip_cliente,
                    'ip_modificacion'      => $ip_cliente,
                    'id_usuariocrea'       => $idusuario,
                    'id_usuariomod'        => $idusuario,
                ];

                ct_Detalle_Pedido::create($detalle);
            }
        }

        return json_encode('Guardado');
    }
    public function edit(Request $request, $id)
    {
        $id_empresa       = $request->session()->get('id_empresa');
        return view('contable.compras_pedidos.edit', ['compraPedido' => Ct_pedidos_Compra::findOrFail($id), 'proveedor' => Proveedor::all(), 'iva_param' => Ct_Configuraciones::where('id_plan', '4.1.01.02')->first(), 'empresa' => Empresa::where('id', $id_empresa)->where('estado', '1')->first(), 'productos' => Ct_productos::where('id_empresa', $id_empresa)->get(), 'bodega' => Ct_Bodegas::where('estado', '1')->where('id_empresa', $id_empresa)->get()]);
    }
    public function update(Request $request, $id)
    {
        $pedidos = Ct_pedidos_Compra::where('id', $id)->first();
        $ip_cliente      = $_SERVER["REMOTE_ADDR"];
        $id_empresa      = $request->session()->get('id_empresa');
        $idusuario       = Auth::user()->id;

        $pedidos->proveedor = $request['nombre_proveedor'];
        $pedidos->direccion_proveedor = $request['direccion_proveedor'];
        $pedidos->autorizacion = $request['autorizacion'];
        $pedidos->f_autorizacion = $request['f_autorizacion'];
        $pedidos->observacion = $request['observacion'];
        $pedidos->secuencia_factura = $request['secuencia_factura'];
        $pedidos->serie = $request['serie'];
        $pedidos->save();
        $editarPedido = Ct_pedidos_Compra::findOrFail($id)->update();
        $id_empresa  = $request->session()->get('id_empresa');
        return view('contable.compras_pedidos.index', [
            'pedidos' => Ct_pedidos_Compra::where('estado', '1')->paginate(10), 'proveedor' => Proveedor::all(), 'tipo_comprobante' => ct_master_tipos::where('estado', '1')->where('tipo', '1')->get(), 'empresa' => Empresa::where('id', $id_empresa)->where('estado', '1')->first()
        ]);
    }
    public function buscar(Request $request)
    {
        $tipo_comprobante = ct_master_tipos::where('estado', '1')->where('tipo', '1')->get();
        $id_empresa       = $request->session()->get('id_empresa');
        $empresa          = Empresa::where('id', $id_empresa)->first();
        $constraints      = [
            'ct_c.id'                   => $request['id'],
            'proveedor'                 => $request['proveedor'],
            'observacion'               => $request['detalle'],
            'ct_c.id_asiento_cabecera'  => $request['id_asiento_cabecera'],
            'fecha'                     => $request['fecha'],
            'ct_c.tipo_comprobante'     => $request['tipo'],
            'secuencia_factura'         => $request['secuencia_f'],
        ];
        $pedido   = $this->doSearchingQuery($constraints, $request);
        return view('contable.compras_pedidos.index', [
            'pedidos' => $pedido, 'proveedor' => Proveedor::all(), 'tipo_comprobante' => ct_master_tipos::where('estado', '1')->where('tipo', '1')->get(), 'empresa' => Empresa::where('id', $id_empresa)->where('estado', '1')->first()
        ]);
    }
    private function doSearchingQuery($constraints, Request $request)
    {
        $id_empresa = $request->session()->get('id_empresa');
        $query      = DB::table('ct_pedidos_compra as ct_c')
            ->join('proveedor as p', 'p.id', 'ct_c.proveedor')
            ->join('users as u', 'u.id', 'ct_c.id_usuariocrea')
            ->where('ct_c.id_empresa', $id_empresa)
            ->where('ct_c.tipo', 1)
            ->select('ct_c.*');
        $fields = array_keys($constraints);
        $index  = 0;
        foreach ($constraints as $constraint) {
            if ($constraint != null) {
                if ($fields[$index] == "ct_c.id_asiento_cabecera") {
                    $query = $query->where($fields[$index], $constraint);
                } elseif ($fields[$index] == "ct_c.id") {
                    $query = $query->where($fields[$index], $constraint);
                } else {

                    $query = $query->where($fields[$index], 'like', '%' . $constraint . '%');
                }
            }



            $index++;
        }


        return $query->paginate(10);
    }

    public function cambio_estado(Request $request)
    {

        $pedidos = Ct_pedidos_Compra::where('id', $request['id'])->first();
        $pedidos->estado = 0;
        $pedidos->save();
        return json_encode('ok');
    }
}
