<?php

namespace Sis_medico\Http\Controllers\contable;

use Sis_medico\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;   
use Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Sis_medico\Ct_Acreedores;
use Sis_medico\Ct_Tipo_Pago;
use Sis_medico\Ct_productos;
use Sis_medico\Ct_Tipo_Tarjeta;
use Sis_medico\Ct_Caja_Banco;
use Sis_medico\Ct_Bancos;
use Sis_medico\Ct_compras;
use Sis_medico\Ct_Divisas;
use Sis_medico\Ct_detalle_compra;
use Sis_medico\Ct_Asientos_Cabecera;
use Sis_medico\Ct_Asientos_Detalle;
use Sis_medico\Ct_Cruce_Valores;
use Sis_medico\Ct_master_tipos;
use Sis_medico\Ct_Configuraciones;
use Sis_medico\Ct_Credito_Acreedores;
use Sis_medico\Plan_Cuentas;
use Sis_medico\Ct_Comprobante_Egreso;
use Sis_medico\Ct_rubros;
use Sis_medico\Ct_Factura_Contable;
use Sis_medico\Proveedor;
use Sis_medico\Bodega;
use Sis_medico\Pais;
use Sis_medico\User;
use Sis_medico\Empresa;
use Sis_medico\Marca;
use Sis_medico\Ct_Detalle_Anticipo_Proveedores;
use Sis_medico\Validate_Decimals;
use laravel\laravel;
use Carbon\Carbon;
use Sis_medico\Ct_Detalle_Credito_Acreedores;

class NotaCreditoAcreedoresController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    private function rol()
    {
        $rolUsuario = Auth::user()->id_tipo_usuario;
        $id_auth    = Auth::user()->id;
        if (in_array($rolUsuario, array(1, 4, 5, 20,22)) == false) {
            return true;
        }
    }
    public function index(Request $request){
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $id_empresa = $request->session()->get('id_empresa');
        $empresa= Empresa::where('id',$id_empresa)->first();
        $proveedor= Ct_Acreedores::where('id_empresa',$id_empresa)->get();
        $anticipo=Ct_Credito_Acreedores::where('id_empresa',$id_empresa)->paginate(20);
        return view('contable/credito_acreedores/index',['nota_credito'=>$anticipo,'proveedor'=>$proveedor,'empresa'=>$empresa]);
    }
    public function search(Request $request)
    {
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $id_empresa = $request->session()->get('id_empresa');
        $empresa= Empresa::where('id',$id_empresa)->first();
        $tipo_comprobante= ct_master_tipos::where('estado', '1')->where('tipo', '1')->get();
        $constraints = [
            'id'                => $request['id'],
            'id_proveedor'           => $request['nombre_proveedor'],
            'concepto'                 =>$request['nombre_concepto'],
            'secuencia'                 =>$request['secuencia_nombre'],
            'fecha'                 =>$request['fecha_credito'],
            'autorizacion'                 =>$request['autorizacion_credito'],
        ];  
        $compras = $this->doSearchingQuery($constraints,$request);
        $proveedor= Ct_Acreedores::where('id_empresa',$id_empresa)->get();
        //dd($constraints);
        return view('contable/credito_acreedores/index', ['proveedor'=>$proveedor,'nota_credito' => $compras, 'searchingVals' => $constraints,'tipo_comprobante' =>$tipo_comprobante,'empresa'=>$empresa]);
    }
    public function edit($id,Request $request){
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $tipo_pago = Ct_Tipo_Pago::where('estado', '1')->get();
        $id_empresa = $request->session()->get('id_empresa');
        $empresa= Empresa::where('id',$id_empresa)->first();
        $bodega = bodega::where('estado', '1')->get();
        $iva_param = Ct_Configuraciones::where('id_plan', '4.1.01.02')->first();
        $c_tributario = ct_master_tipos::where('estado', '1')->where('tipo', '2')->get();
        $t_comprobante = ct_master_tipos::where('estado', '1')->where('tipo', '1')->get();
        $empresa_sucurs  = Empresa::findorfail($id_empresa);
        $empresa_general = Empresa::all();
        $comprobante= Ct_Credito_Acreedores::where('id_empresa',$id_empresa)->where('id_empresa',$id_empresa)->where('id',$id)->first();
        $detalles_comprobante= Ct_Detalle_Credito_Acreedores::where('id_debito',$comprobante->id)->get();
        //dd($tipo_pago);
        return view('contable/credito_acreedores/edit',['tipo_pago'=>$tipo_pago,'comprobante'=>$comprobante,'detalles'=>$detalles_comprobante,'iva_param'=>$iva_param,'t_comprobante' => $t_comprobante, 'c_tributario' => $c_tributario,'bodega'=>$bodega,'empresa_sucurs'=>$empresa_sucurs,'empresa_general'=>$empresa_general,'empresa'=>$empresa]);
    }

    private function doSearchingQuery($constraints,Request  $request)
    {
        $id_empresa = $request->session()->get('id_empresa');
        $query = Ct_Credito_Acreedores::where('id_empresa',$id_empresa)->where('estado','1');
                        //dd($query->get());
        //dd($constraints);
        $fields = array_keys($constraints);
        $index = 0;
        if($request->id!=null){
            foreach ($constraints as $constraint) {
                if ($constraint != null) {
                    $query = $query->where($fields[$index], $constraint);
                }
                $index++;
            }
        }else{
            foreach ($constraints as $constraint) {
                if ($constraint != null) {
                    $query = $query->where($fields[$index], 'like', '%' . $constraint . '%');
                }
                $index++;
            }
        }
       // dd($query->get());
        return $query->paginate(10);
    }
    public function create(Request $request){
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $tipo_pago = Ct_Tipo_Pago::where('estado', '1')->get();
        $id_empresa = $request->session()->get('id_empresa');
        $empresa= Empresa::where('id',$id_empresa)->first();
        $bodega = bodega::where('estado', '1')->get();
        $iva_param = Ct_Configuraciones::where('id_plan', '4.1.01.02')->first();
        $c_tributario = ct_master_tipos::where('estado', '1')->where('tipo', '2')->get();
        $t_comprobante = ct_master_tipos::where('estado', '1')->where('tipo', '1')->get();
        $empresa_sucurs  = Empresa::findorfail($id_empresa);
        $compraid= Ct_compras::where('id_empresa',$id_empresa)->where('valor_contable','>','0')->get();
        $empresa_general = Empresa::all();
        //dd($tipo_pago);
        
        return view('contable/credito_acreedores/create',['tipo_pago'=>$tipo_pago,'iva_param'=>$iva_param,'t_comprobante' => $t_comprobante,'compraid'=>$compraid, 'c_tributario' => $c_tributario,'bodega'=>$bodega,'empresa_sucurs'=>$empresa_sucurs,'empresa_general'=>$empresa_general,'empresa'=>$empresa]);
    }
    public function bancos(Request $request){
        
        if($request['opciones']!='1'){
            $banco= DB::table('plan_cuentas')->where('estado','!=','0')->where('id_padre','1.01.01.2')->get();
            return $banco; 
        }else{
            $caja= DB::table('plan_cuentas')->where('id_padre','1.01.01.1')->get();
            return $caja;
        }
        return ['value'=>'error'];
    }
    public function store(Request $request){
        $ip_cliente = $_SERVER["REMOTE_ADDR"];
        $idusuario  = Auth::user()->id;
        $id_empresa = $request->session()->get('id_empresa');
        $consulta_anticipo=null;
        $saldo_redondeado=0;
        $objeto_validar= new Validate_Decimals(); 
        $consulta_facturas=0;
        $total=0;
        $input_actualiza=null;
        $contador_ctv = DB::table('ct_credito_acreedores')->get()->count();
        $numero_factura=0;
        DB::beginTransaction();

        try {

           
            if($contador_ctv == 0){
       
                //return 'No Retorno nada';
                $num = '1';
                $numero_factura = str_pad($num, 10, "0", STR_PAD_LEFT);
               
    
    
            }else{
    
                //Obtener Ultimo Registro de la Tabla ct_compras
                $max_id = DB::table('ct_credito_acreedores')->max('id');
    
                if(($max_id>=1)&&($max_id<10)){
                   $nu = $max_id+1;
                   $numero_factura = str_pad($nu, 10, "0", STR_PAD_LEFT);
                  
                }
    
                if(($max_id>=10)&&($max_id<100)){
                   $nu = $max_id+1;
                   $numero_factura = str_pad($nu, 10, "0", STR_PAD_LEFT);
                  
                }
    
                if(($max_id>=100)&&($max_id<1000)){
                   $nu = $max_id+1;
                   $numero_factura = str_pad($nu, 10, "0", STR_PAD_LEFT);
                  
                }
    
                if($max_id == 1000){
                   $numero_factura = $max_id;
                  
                }
            
            }
            $cabeceraa = [
                'observacion'                   => 'NOTA DE CRÉDITO : '.$request['concepto'].'A:'.$request['id_proveedor'],
                'fecha_asiento'                 => $request['fecha_hoy'],
                'fact_numero'                   => $numero_factura,
                'valor'                         => $request['total'],
                'id_empresa'                    => $id_empresa,
                'estado'                        => '1',
                'ip_creacion'                   => $ip_cliente,
                'ip_modificacion'               => $ip_cliente,
                'id_usuariocrea'                => $idusuario,
                'id_usuariomod'                 => $idusuario,
            ];
            $consulta_compra= Ct_compras::where('id',$request['nro_factura'])
            ->where('id_empresa',$id_empresa)
            ->first();
            $id_asiento_cabecera = Ct_Asientos_Cabecera::insertGetId($cabeceraa);
            //dd($id_asiento_cabecera);
            $input=[
                'asiento'                       => $request['asiento'],
                'id_asiento_cabecera'           => $id_asiento_cabecera,
                'id_empresa'                    => $id_empresa,
                'id_compra'                     => $request['id_comp'],
                'fecha'                         => $request['fecha_hoy'],
                'fecha_caducidad'               => $request['fecha_caducidad'],
                'id_proveedor'                  => $request['id_proveedor'],
                'autorizacion'                  => $request['autorizacion'],
                'serie'                         => $request['serie'],
                'secuencia'                     => $request['secuencia'],
                'nro_comprobante'               => $consulta_compra->numero,
                'id_rubro'                      => $request['id_codigo'],
                'fechand'                       => $request['fechand'],
                'concepto'                      => $request['concepto'],
                'id_credito_tributario'         => $request['credito_tributario'],
                'id_tipo_comprobante'           => $request['tipo_comprobante'],
                'fecha_factura'                 => $request['fecha_factura'],
                'serie_factura'                 => $request['serie_factura'],
                'autorizacion_factura'          => $request['autorizacion_factura'],
                'subtotal'                      => $request['subtotal'],
                'impuesto'                      => $request['impuesto'],
                'valor_contable'                => $request['total'],
                'id_usuariocrea'                => $idusuario,
                'id_usuariomod'                 => $idusuario,
                'ip_creacion'                   => $ip_cliente,
                'ip_modificacion'               => $ip_cliente,
    
            ];
            $id_debito= Ct_Credito_Acreedores::insertGetId($input);
            $valr=0;
            if($request['contador']!=null){
                $primerarray = array();
                for($i=0; $i<$request['contador']; $i++){
                    if($request['visibilidad'.$i]==1){
                        $valr+= $request['valor'.$i];
                        $consulta_rubro= Ct_rubros::where('codigo',$request['id_codigo'.$i])->first();
                        if($consulta_rubro!='[]' || $consulta_rubro!=null){
                            $segundoarray = [$consulta_rubro->haber,$request['valor'.$i]];
                            $key = array_search($consulta_rubro->haber, array_column($primerarray, '0'));
                            
                            if($key!== false){
                                $valor2 =  $primerarray[$key][1];  
                                $valor2= $valor2+$request['valor'.$i];
                                $primerarray [$key][0] = $consulta_rubro->haber;
                                $primerarray [$key][1] = $valor2;
                                
                            }else{
                                array_push($primerarray,$segundoarray);
                            } 
                            /*    
                          
                            Ct_Asientos_Detalle::create([
                                           
                                'id_asiento_cabecera'           => $id_asiento_cabecera,
                                'id_plan_cuenta'                => $consulta_rubro->debe,
                                'descripcion'                   => $consulta_rubro->nombre,
                                'fecha'                         => $request['fecha_hoy'],
                                'debe'                          => $request['valor'.$i],
                                'haber'                         => '0',
                                'estado'                        => '1',
                                'id_usuariocrea'                => $idusuario,
                                'id_usuariomod'                 => $idusuario,
                                'ip_creacion'                   => $ip_cliente,
                                'ip_modificacion'               => $ip_cliente,
                            ]); */
                            Ct_Detalle_Credito_Acreedores::create([
                                'id_debito'                     =>$id_debito,
                                'codigo'                        =>$request['rubro'.$i],
                                'nombre'                        =>$request['detalle_rubro'.$i],
                                'concepto'                      =>$request['detalle_rubro'.$i],
                                'fecha'                         => $request['fecha'.$i],
                                'vencimiento'                   =>$request['vencimiento'.$i],
                                'valor'                         =>$request['valor'.$i],
                                'id_usuariocrea'                => $idusuario,
                                'id_usuariomod'                 => $idusuario,
                                'ip_creacion'                   => $ip_cliente,
                                'ip_modificacion'               => $ip_cliente,
                            ]);
                           
                        }
                        
                    }
    
                }
                $pros= Proveedor::find($consulta_compra->proveedor);
                $cuenta_proveedor= $pros->id_cuentas;

                $plan_cuenta= Plan_Cuentas::find($cuenta_proveedor);
                Ct_Asientos_Detalle::create([
                               
                    'id_asiento_cabecera'           => $id_asiento_cabecera,
                    'id_plan_cuenta'                => $cuenta_proveedor,
                    'descripcion'                   => $plan_cuenta->nombre,
                    'fecha'                         => $request['fecha_hoy'],
                    'debe'                           => $request['total'],
                    'haber'                          => '0',
                    'estado'                        => '1',
                    'id_usuariocrea'                => $idusuario,
                    'id_usuariomod'                 => $idusuario,
                    'ip_creacion'                   => $ip_cliente,
                    'ip_modificacion'               => $ip_cliente,
                ]); 
                //descuentos en compras cambio febrero 2021
                $plan_cuentas2= Plan_Cuentas::where('id','4.1.08')->first();
                //dd($plan_cuentas2);
                Ct_Asientos_Detalle::create([
                               
                    'id_asiento_cabecera'           => $id_asiento_cabecera,
                    'id_plan_cuenta'                => '4.1.08',
                    'descripcion'                   => $plan_cuentas2->nombre,
                    'fecha'                         => $request['fecha_hoy'],
                    'haber'                         => $request['total'],
                    'debe'                          => '0',
                    'estado'                        => '1',
                    'id_usuariocrea'                => $idusuario,
                    'id_usuariomod'                 => $idusuario,
                    'ip_creacion'                   => $ip_cliente,
                    'ip_modificacion'               => $ip_cliente,
                ]);                 
                if($request['total']>0){
                    if($request['total']>($consulta_compra->valor_contable)){
                        $nuevo_saldo= $request['total']-$consulta_compra->valor_contable;
                    }else{
                        $nuevo_saldo= $consulta_compra->valor_contable-$request['total'];
                    }
                    
                    $nuevo_saldof= $objeto_validar->set_round($nuevo_saldo);
                    $input_actualiza=null;
                    if($nuevo_saldof!=0){
                        $input_actualiza=[
                            'estado'                        => '2',//poner otro estado para que no salga en las consultas
                            'valor_contable'                => $nuevo_saldof,
                            'ip_creacion'                   => $ip_cliente,
                            'ip_modificacion'               => $ip_cliente,
                            'id_usuariocrea'                => $idusuario,
                            'id_usuariomod'                 => $idusuario,          
                        ];
                    }else{
                        $input_actualiza=[
                            'estado'                        => '3',//poner otro estado para que no salga en las consultas
                            'valor_contable'                => $nuevo_saldof,
                            'ip_creacion'                   => $ip_cliente,
                            'ip_modificacion'               => $ip_cliente,
                            'id_usuariocrea'                => $idusuario,
                            'id_usuariomod'                 => $idusuario,          
                        ];
                    }
                    $consulta_compra->update($input_actualiza);
                }
    
                DB::commit();
                return $id_debito;
            }else{
                return 'error vacios';
            }
            
        } catch (\Exception $e) {
            //if there is an error/exception in the above code before commit, it'll rollback
            DB::rollBack();
            return $e->getMessage();
        }
        


        return 'error no guardo nada';
        
    }
    public function anular($id, Request $request){
        if (!is_null($id)) {
            $comp_ingreso = Ct_Credito_Acreedores::where('estado', '1')->where('id', $id)->first();
            $ip_cliente = $_SERVER["REMOTE_ADDR"];
            $id_empresa = $request->session()->get('id_empresa');
            $idusuario  = Auth::user()->id;
            $fact_compra= Ct_compras::find($comp_ingreso->id_compra);
            if(!is_null($fact_compra)){
                $valor= $fact_compra->valor_contable;
                $fact_compra->estado=1;
                $fact_compra->id_usuariomod=$idusuario;
                $fact_compra->valor_contable=  $valor+$comp_ingreso->valor_contable;
                $fact_compra->save();
            }
            if (!is_null($comp_ingreso)) {
                $input = [
                    'estado' => '0',
                    'ip_creacion'                   => $ip_cliente,
                    'ip_modificacion'               => $ip_cliente,
                    'id_usuariomod'                 => $idusuario,
                ];
                $comp_ingreso->update($input);
                // ahora actualizo el valor y le sumo lo que ya le había restado
                $asiento= Ct_Asientos_Cabecera::findorfail($comp_ingreso->id_asiento_cabecera);
                $asiento->estado = 1;
                $asiento->save();
                $detalles = $asiento->detalles;
                $id_asiento = Ct_Asientos_Cabecera::insertGetId([
                    'observacion'     => 'ANULACIÓN ' . $asiento->observacion,
                    'fecha_asiento'   => $asiento->fecha_asiento,
                    'id_empresa'      => $id_empresa,
                    'fact_numero'     => $comp_ingreso->secuencia,
                    'valor'           => $asiento->valor,
                    'ip_creacion'     => $ip_cliente,
                    'ip_modificacion' => $ip_cliente,
                    'id_usuariocrea'  => $idusuario,
                    'id_usuariomod'   => $idusuario,
                ]);
                foreach ($detalles as $value) {
                    Ct_Asientos_Detalle::create([
                        'id_asiento_cabecera' => $id_asiento,
                        'id_plan_cuenta'      => $value->id_plan_cuenta,
                        'debe'                => $value->haber,
                        'haber'               => $value->debe,
                        'descripcion'         => $value->descripcion,
                        'fecha'               => $asiento->fecha_asiento,
                        'ip_creacion'         => $ip_cliente,
                        'ip_modificacion'     => $ip_cliente,
                        'id_usuariocrea'      => $idusuario,
                        'id_usuariomod'       => $idusuario,
                    ]);
                }
                return redirect()->route('creditoacreedores.index');
            }
        } else {
            return 'error';
        }
    }
    public function pdf_comprobante($id){
        if ($this->rol()) {
            return response()->view('errors.404');
        }
        $anticipo    = Ct_Cruce_Valores::find($id);
        $tipo_pago = Ct_Tipo_Pago::where('id', $anticipo->id_tipo_pago)->first();
        $empresa= Empresa::where('id',$anticipo->id_empresa)->first();
        $proveedor= Proveedor::where('id',$anticipo->id_proveedor)->first();
        $vistaurl = "contable.anticipos.pdf_comprobante_anticipo";
        $usuario_crea=DB::table('users')->where('id',$anticipo->id_usuariocrea)->first();
        $view     = \View::make($vistaurl, compact('emp','proveedor','empresa','anticipo','tipo_pago','usuario_crea'))->render();
        $pdf      = \App::make('dompdf.wrapper');
        $pdf->loadHTML($view);
        $pdf->setOptions(['dpi' => 150, 'isPhpEnabled' => true]);
        $pdf->setPaper('A4', 'portrait');

        return $pdf->stream('resultado-' . $id . '.pdf');
    }


    public function template(){
  
        if ($this->rol()) {
            return response()->view('errors.404');
        }

        return view('contable.plantilla.app-template');
    }

    /************************************************************/
    /****************BUZQUEDA DE FACTURAS DE COMPRA**************
    /***********************************************************/
    public function obtener_num_fact(Request $request)
    {

        $num = $request['term'];
        $data      = array();

        $id_empresa = $request->session()->get('id_empresa');

        $fact_compra = Ct_compras::where('id',$num)
                                 ->whereRaw('(estado = 1 OR estado = 2)')
                                 ->where('valor_contable','>','0')
                                 ->where('id_empresa',$id_empresa)
                                 ->get();

       
        foreach ($fact_compra as $fact_compra) {
            
            $num_comprobante = $fact_compra->numero;
            $variable = explode("-",$num_comprobante);
            $sucursal = 0;
            $punto_emision = 0;
            $serie = 0;
            $secuencia = 0;
            $nombre_proveedor ='';

            if(!is_null($fact_compra->proveedorf)){
              $nombre_proveedor = $fact_compra->proveedorf->nombrecomercial;
            }
            
            if(count($variable)>0){

                $sucursal = $variable[0];
                $punto_emision = $variable[1];
                $serie = $variable[0].'-'.$variable[1];
                $secuencia = $variable[2];

            }
            
            $data[] = array('value' => $fact_compra->id,'num_asiento' => $fact_compra->id_asiento_cabecera,'id_compra' => $num,'serie' => $serie,'autorizacion' => $fact_compra->autorizacion,'secuencia' => $secuencia,'nomb_proveedor' => $nombre_proveedor,'id_proveedor' =>  $fact_compra->proveedorf->id,'val_contable' =>  $fact_compra->valor_contable);
        }

        //dd($fact_venta);

        if (count($data)>0) {
            return $data;
        } else {
            return ['value' => 'No se encontraron resultados', 'id' => ''];
        }
    }


    
    


}